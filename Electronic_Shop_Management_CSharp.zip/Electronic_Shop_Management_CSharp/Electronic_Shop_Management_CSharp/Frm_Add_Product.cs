﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;


namespace Electronic_Shop_Management_CSharp
{
    public partial class Frm_Add_Product : Form
    {
        SqlConnection Con = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=Electronic_Shop_Management_DB;Integrated Security=True");
        SqlCommand Cmd = new SqlCommand();
        SqlCommand Cmd1 = new SqlCommand();
        SqlDataReader dr;
        String str,str1;

        public void Connection_Open()
        {
            if (Con.State == ConnectionState.Closed)
            {
                Con.Open();
            }
        }

        public void Connection_Close()
        {
            if (Con.State == ConnectionState.Open)
            {
                Con.Close();
            }
        }

        public int Autoincreament(string str)
        {
            Connection_Open();
            Cmd.CommandText = str;
            Cmd.Connection = Con;
            int a = Convert.ToInt32(Cmd.ExecuteScalar());

            if (a > 0)
            {
                a = a + 1;
            }
            else
            {
                a = 1;
            }

            Connection_Close();
            return a;
        }

        public void Clear_Controls()
        {
            Product_Name_TB.Text = "";
            Brand_CMB.Text = "Select brand";
            Description_TB.Text = "";
            Dealer_Rate_TB.Text = "";
            Dealer_Name_CMB.Text = "Select dealer name";
            CGST_TB.Text = "";
            SGST_TB.Text = "";
            Sale_Rate_TB.Text = "";
            Product_Quantity_TB.Text = "";
        }

        public Frm_Add_Product()
        {
            InitializeComponent();
        }

        private void Frm_Add_Product_Load(object sender, EventArgs e)
        {
            Product_ID_TB.Text = Convert.ToString(Autoincreament("SELECT COUNT(Product_ID) FROM Product_Detail_Table"));
            Connection_Open();

            Cmd.Connection = Con;
            Cmd.CommandText = "SELECT Dealer_Name FROM Dealer_Detail_Table";
            
            dr = Cmd.ExecuteReader();
            while (dr.Read())
            {
                Dealer_Name_CMB.Items.Add(dr["Dealer_Name"].ToString());
            }
            dr.Close();
            Connection_Close();


        }

        private void Btn_save_Click(object sender, EventArgs e)
        {
            string date = System.DateTime.Now.ToString();
            Connection_Open();
            if (Product_ID_TB.Text != "" && Product_Name_TB.Text != "" && Brand_CMB.Text != "" && Description_TB.Text != "" && Dealer_Name_CMB.Text != "" && CGST_TB.Text != "" && SGST_TB.Text != "" && Dealer_Rate_TB.Text != "" && Sale_Rate_TB.Text != "" && Product_Quantity_TB.Text != "")
            {
                Cmd.CommandText = "INSERT INTO Product_Detail_Table VALUES(" + Product_ID_TB.Text + ",'" + Product_Name_TB.Text + "','" + Brand_CMB.Text + "','" + Description_TB.Text + "','" + Dealer_Name_CMB.Text + "'," + CGST_TB.Text + "," + SGST_TB.Text + "," + Dealer_Rate_TB.Text + "," + Sale_Rate_TB.Text + "," + Product_Quantity_TB.Text + ",'" + date + "')";
                Cmd.Connection = Con;

                Cmd1.CommandText = "INSERT INTO Stock_Detail_Table VALUES(" + Product_ID_TB.Text + ",'" + Product_Name_TB.Text + "','" + Brand_CMB.Text + "','" + Dealer_Name_CMB.Text + "'," + Product_Quantity_TB.Text + ",'" + date + "')";
                Cmd1.Connection = Con;

                str = Convert.ToString(Cmd.ExecuteNonQuery());
                str1 = Convert.ToString(Cmd1.ExecuteNonQuery());
                if ((str != null) && (str1 != null))
                {
                    MessageBox.Show("Record saved successfully!!");
                    Clear_Controls();
                    Product_ID_TB.Text = Convert.ToString(Autoincreament("SELECT COUNT(Product_ID) FROM Product_Detail_Table"));
                }
                else
                {
                    MessageBox.Show("Record not saved!!");
                }
            }
            else
            {
                MessageBox.Show("Please first fill all the fields!!");
            }
           
        }

        private void Btn_clear_Click(object sender, EventArgs e)
        {
            Clear_Controls();
        }

        private void btn_exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Frm_Add_Product_Leave(object sender, EventArgs e)
        {
            Clear_Controls();
        }

    }
}
