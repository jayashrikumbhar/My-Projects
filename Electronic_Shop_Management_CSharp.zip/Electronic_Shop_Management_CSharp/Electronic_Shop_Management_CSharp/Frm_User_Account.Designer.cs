﻿namespace Electronic_Shop_Management_CSharp
{
    partial class Frm_User_Account
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TabControl1 = new System.Windows.Forms.TabControl();
            this.TabPage1 = new System.Windows.Forms.TabPage();
            this.AddUser_Btn = new System.Windows.Forms.Button();
            this.ConfirmPass_TB = new System.Windows.Forms.TextBox();
            this.Password_TB = new System.Windows.Forms.TextBox();
            this.Username_TB = new System.Windows.Forms.TextBox();
            this.Label4 = new System.Windows.Forms.Label();
            this.Label5 = new System.Windows.Forms.Label();
            this.Label6 = new System.Windows.Forms.Label();
            this.TabPage2 = new System.Windows.Forms.TabPage();
            this.Change_Btn = new System.Windows.Forms.Button();
            this.Confirm_Pass_TB = new System.Windows.Forms.TextBox();
            this.New_Pass_TB = new System.Windows.Forms.TextBox();
            this.UN_TB = new System.Windows.Forms.TextBox();
            this.Label8 = new System.Windows.Forms.Label();
            this.Label9 = new System.Windows.Forms.Label();
            this.Label11 = new System.Windows.Forms.Label();
            this.TabPage3 = new System.Windows.Forms.TabPage();
            this.UserNm_TB = new System.Windows.Forms.TextBox();
            this.Label12 = new System.Windows.Forms.Label();
            this.Delete_Btn = new System.Windows.Forms.Button();
            this.Pass_TB = new System.Windows.Forms.TextBox();
            this.Label13 = new System.Windows.Forms.Label();
            this.Lable1 = new System.Windows.Forms.Label();
            this.TabControl1.SuspendLayout();
            this.TabPage1.SuspendLayout();
            this.TabPage2.SuspendLayout();
            this.TabPage3.SuspendLayout();
            this.SuspendLayout();
            // 
            // TabControl1
            // 
            this.TabControl1.Controls.Add(this.TabPage1);
            this.TabControl1.Controls.Add(this.TabPage2);
            this.TabControl1.Controls.Add(this.TabPage3);
            this.TabControl1.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TabControl1.Location = new System.Drawing.Point(1, 96);
            this.TabControl1.Name = "TabControl1";
            this.TabControl1.SelectedIndex = 0;
            this.TabControl1.Size = new System.Drawing.Size(986, 434);
            this.TabControl1.TabIndex = 105;
            // 
            // TabPage1
            // 
            this.TabPage1.BackColor = System.Drawing.Color.White;
            this.TabPage1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TabPage1.Controls.Add(this.AddUser_Btn);
            this.TabPage1.Controls.Add(this.ConfirmPass_TB);
            this.TabPage1.Controls.Add(this.Password_TB);
            this.TabPage1.Controls.Add(this.Username_TB);
            this.TabPage1.Controls.Add(this.Label4);
            this.TabPage1.Controls.Add(this.Label5);
            this.TabPage1.Controls.Add(this.Label6);
            this.TabPage1.Location = new System.Drawing.Point(4, 27);
            this.TabPage1.Name = "TabPage1";
            this.TabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.TabPage1.Size = new System.Drawing.Size(978, 403);
            this.TabPage1.TabIndex = 0;
            this.TabPage1.Text = "Add User";
            // 
            // AddUser_Btn
            // 
            this.AddUser_Btn.BackColor = System.Drawing.Color.Snow;
            this.AddUser_Btn.Enabled = false;
            this.AddUser_Btn.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddUser_Btn.Location = new System.Drawing.Point(411, 305);
            this.AddUser_Btn.Name = "AddUser_Btn";
            this.AddUser_Btn.Size = new System.Drawing.Size(169, 54);
            this.AddUser_Btn.TabIndex = 5;
            this.AddUser_Btn.Text = "Add User";
            this.AddUser_Btn.UseVisualStyleBackColor = false;
            this.AddUser_Btn.Click += new System.EventHandler(this.AddUser_Btn_Click);
            // 
            // ConfirmPass_TB
            // 
            this.ConfirmPass_TB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ConfirmPass_TB.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ConfirmPass_TB.Location = new System.Drawing.Point(456, 202);
            this.ConfirmPass_TB.MaxLength = 10;
            this.ConfirmPass_TB.Name = "ConfirmPass_TB";
            this.ConfirmPass_TB.PasswordChar = '*';
            this.ConfirmPass_TB.Size = new System.Drawing.Size(298, 31);
            this.ConfirmPass_TB.TabIndex = 4;
            this.ConfirmPass_TB.TextChanged += new System.EventHandler(this.ConfirmPass_TB_TextChanged);
            // 
            // Password_TB
            // 
            this.Password_TB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Password_TB.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Password_TB.Location = new System.Drawing.Point(456, 145);
            this.Password_TB.MaxLength = 10;
            this.Password_TB.Name = "Password_TB";
            this.Password_TB.PasswordChar = '*';
            this.Password_TB.Size = new System.Drawing.Size(298, 31);
            this.Password_TB.TabIndex = 3;
            // 
            // Username_TB
            // 
            this.Username_TB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Username_TB.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Username_TB.Location = new System.Drawing.Point(456, 87);
            this.Username_TB.MaxLength = 20;
            this.Username_TB.Name = "Username_TB";
            this.Username_TB.Size = new System.Drawing.Size(298, 31);
            this.Username_TB.TabIndex = 2;
            // 
            // Label4
            // 
            this.Label4.AutoSize = true;
            this.Label4.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label4.Location = new System.Drawing.Point(237, 202);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(154, 18);
            this.Label4.TabIndex = 95;
            this.Label4.Text = "Confirm Password";
            // 
            // Label5
            // 
            this.Label5.AutoSize = true;
            this.Label5.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label5.Location = new System.Drawing.Point(317, 145);
            this.Label5.Name = "Label5";
            this.Label5.Size = new System.Drawing.Size(85, 18);
            this.Label5.TabIndex = 94;
            this.Label5.Text = "Password";
            // 
            // Label6
            // 
            this.Label6.AutoSize = true;
            this.Label6.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label6.Location = new System.Drawing.Point(311, 87);
            this.Label6.Name = "Label6";
            this.Label6.Size = new System.Drawing.Size(90, 18);
            this.Label6.TabIndex = 93;
            this.Label6.Text = "Username";
            // 
            // TabPage2
            // 
            this.TabPage2.BackColor = System.Drawing.Color.White;
            this.TabPage2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TabPage2.Controls.Add(this.Change_Btn);
            this.TabPage2.Controls.Add(this.Confirm_Pass_TB);
            this.TabPage2.Controls.Add(this.New_Pass_TB);
            this.TabPage2.Controls.Add(this.UN_TB);
            this.TabPage2.Controls.Add(this.Label8);
            this.TabPage2.Controls.Add(this.Label9);
            this.TabPage2.Controls.Add(this.Label11);
            this.TabPage2.Location = new System.Drawing.Point(4, 27);
            this.TabPage2.Name = "TabPage2";
            this.TabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.TabPage2.Size = new System.Drawing.Size(978, 403);
            this.TabPage2.TabIndex = 1;
            this.TabPage2.Text = "Change Password";
            // 
            // Change_Btn
            // 
            this.Change_Btn.BackColor = System.Drawing.Color.Snow;
            this.Change_Btn.Enabled = false;
            this.Change_Btn.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Change_Btn.Location = new System.Drawing.Point(416, 289);
            this.Change_Btn.Name = "Change_Btn";
            this.Change_Btn.Size = new System.Drawing.Size(169, 54);
            this.Change_Btn.TabIndex = 5;
            this.Change_Btn.Text = "Change";
            this.Change_Btn.UseVisualStyleBackColor = false;
            this.Change_Btn.Click += new System.EventHandler(this.Change_Btn_Click);
            // 
            // Confirm_Pass_TB
            // 
            this.Confirm_Pass_TB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Confirm_Pass_TB.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Confirm_Pass_TB.Location = new System.Drawing.Point(458, 200);
            this.Confirm_Pass_TB.MaxLength = 10;
            this.Confirm_Pass_TB.Name = "Confirm_Pass_TB";
            this.Confirm_Pass_TB.PasswordChar = '*';
            this.Confirm_Pass_TB.Size = new System.Drawing.Size(295, 31);
            this.Confirm_Pass_TB.TabIndex = 4;
            this.Confirm_Pass_TB.TextChanged += new System.EventHandler(this.Confirm_Pass_TB_TextChanged);
            // 
            // New_Pass_TB
            // 
            this.New_Pass_TB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.New_Pass_TB.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.New_Pass_TB.Location = new System.Drawing.Point(458, 143);
            this.New_Pass_TB.MaxLength = 10;
            this.New_Pass_TB.Name = "New_Pass_TB";
            this.New_Pass_TB.PasswordChar = '*';
            this.New_Pass_TB.Size = new System.Drawing.Size(295, 31);
            this.New_Pass_TB.TabIndex = 3;
            // 
            // UN_TB
            // 
            this.UN_TB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.UN_TB.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UN_TB.Location = new System.Drawing.Point(458, 85);
            this.UN_TB.MaxLength = 20;
            this.UN_TB.Name = "UN_TB";
            this.UN_TB.Size = new System.Drawing.Size(295, 31);
            this.UN_TB.TabIndex = 2;
            // 
            // Label8
            // 
            this.Label8.AutoSize = true;
            this.Label8.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label8.Location = new System.Drawing.Point(238, 206);
            this.Label8.Name = "Label8";
            this.Label8.Size = new System.Drawing.Size(154, 18);
            this.Label8.TabIndex = 95;
            this.Label8.Text = "Confirm Password";
            // 
            // Label9
            // 
            this.Label9.AutoSize = true;
            this.Label9.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label9.Location = new System.Drawing.Point(271, 149);
            this.Label9.Name = "Label9";
            this.Label9.Size = new System.Drawing.Size(126, 18);
            this.Label9.TabIndex = 94;
            this.Label9.Text = "New Password";
            // 
            // Label11
            // 
            this.Label11.AutoSize = true;
            this.Label11.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label11.Location = new System.Drawing.Point(313, 91);
            this.Label11.Name = "Label11";
            this.Label11.Size = new System.Drawing.Size(90, 18);
            this.Label11.TabIndex = 93;
            this.Label11.Text = "Username";
            // 
            // TabPage3
            // 
            this.TabPage3.BackColor = System.Drawing.Color.White;
            this.TabPage3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TabPage3.Controls.Add(this.UserNm_TB);
            this.TabPage3.Controls.Add(this.Label12);
            this.TabPage3.Controls.Add(this.Delete_Btn);
            this.TabPage3.Controls.Add(this.Pass_TB);
            this.TabPage3.Controls.Add(this.Label13);
            this.TabPage3.Location = new System.Drawing.Point(4, 27);
            this.TabPage3.Name = "TabPage3";
            this.TabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.TabPage3.Size = new System.Drawing.Size(978, 403);
            this.TabPage3.TabIndex = 2;
            this.TabPage3.Text = "Remove User";
            // 
            // UserNm_TB
            // 
            this.UserNm_TB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.UserNm_TB.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UserNm_TB.Location = new System.Drawing.Point(460, 114);
            this.UserNm_TB.MaxLength = 20;
            this.UserNm_TB.Name = "UserNm_TB";
            this.UserNm_TB.Size = new System.Drawing.Size(295, 31);
            this.UserNm_TB.TabIndex = 2;
            // 
            // Label12
            // 
            this.Label12.AutoSize = true;
            this.Label12.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label12.Location = new System.Drawing.Point(269, 114);
            this.Label12.Name = "Label12";
            this.Label12.Size = new System.Drawing.Size(90, 18);
            this.Label12.TabIndex = 104;
            this.Label12.Text = "Username";
            // 
            // Delete_Btn
            // 
            this.Delete_Btn.BackColor = System.Drawing.Color.Snow;
            this.Delete_Btn.Enabled = false;
            this.Delete_Btn.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Delete_Btn.Location = new System.Drawing.Point(412, 287);
            this.Delete_Btn.Name = "Delete_Btn";
            this.Delete_Btn.Size = new System.Drawing.Size(169, 54);
            this.Delete_Btn.TabIndex = 4;
            this.Delete_Btn.Text = "Delete";
            this.Delete_Btn.UseVisualStyleBackColor = false;
            this.Delete_Btn.Click += new System.EventHandler(this.Delete_Btn_Click);
            // 
            // Pass_TB
            // 
            this.Pass_TB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Pass_TB.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Pass_TB.Location = new System.Drawing.Point(460, 181);
            this.Pass_TB.MaxLength = 10;
            this.Pass_TB.Name = "Pass_TB";
            this.Pass_TB.PasswordChar = '*';
            this.Pass_TB.Size = new System.Drawing.Size(295, 31);
            this.Pass_TB.TabIndex = 97;
            this.Pass_TB.TextChanged += new System.EventHandler(this.Pass_TB_TextChanged);
            // 
            // Label13
            // 
            this.Label13.AutoSize = true;
            this.Label13.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label13.Location = new System.Drawing.Point(269, 183);
            this.Label13.Name = "Label13";
            this.Label13.Size = new System.Drawing.Size(85, 18);
            this.Label13.TabIndex = 94;
            this.Label13.Text = "Password";
            // 
            // Lable1
            // 
            this.Lable1.AutoSize = true;
            this.Lable1.Font = new System.Drawing.Font("Verdana", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lable1.ForeColor = System.Drawing.Color.Black;
            this.Lable1.Location = new System.Drawing.Point(306, 25);
            this.Lable1.Name = "Lable1";
            this.Lable1.Size = new System.Drawing.Size(371, 42);
            this.Lable1.TabIndex = 106;
            this.Lable1.Text = "User Management";
            // 
            // Frm_User_Account
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(983, 531);
            this.Controls.Add(this.Lable1);
            this.Controls.Add(this.TabControl1);
            this.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "Frm_User_Account";
            this.Text = "Frm_User_Account";
            this.TabControl1.ResumeLayout(false);
            this.TabPage1.ResumeLayout(false);
            this.TabPage1.PerformLayout();
            this.TabPage2.ResumeLayout(false);
            this.TabPage2.PerformLayout();
            this.TabPage3.ResumeLayout(false);
            this.TabPage3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.TabControl TabControl1;
        internal System.Windows.Forms.TabPage TabPage1;
        internal System.Windows.Forms.Button AddUser_Btn;
        internal System.Windows.Forms.TextBox ConfirmPass_TB;
        internal System.Windows.Forms.TextBox Password_TB;
        internal System.Windows.Forms.TextBox Username_TB;
        internal System.Windows.Forms.Label Label4;
        internal System.Windows.Forms.Label Label5;
        internal System.Windows.Forms.Label Label6;
        internal System.Windows.Forms.TabPage TabPage2;
        internal System.Windows.Forms.Button Change_Btn;
        internal System.Windows.Forms.TextBox Confirm_Pass_TB;
        internal System.Windows.Forms.TextBox New_Pass_TB;
        internal System.Windows.Forms.TextBox UN_TB;
        internal System.Windows.Forms.Label Label8;
        internal System.Windows.Forms.Label Label9;
        internal System.Windows.Forms.Label Label11;
        internal System.Windows.Forms.TabPage TabPage3;
        internal System.Windows.Forms.TextBox UserNm_TB;
        internal System.Windows.Forms.Label Label12;
        internal System.Windows.Forms.Button Delete_Btn;
        internal System.Windows.Forms.TextBox Pass_TB;
        internal System.Windows.Forms.Label Label13;
        internal System.Windows.Forms.Label Lable1;
    }
}