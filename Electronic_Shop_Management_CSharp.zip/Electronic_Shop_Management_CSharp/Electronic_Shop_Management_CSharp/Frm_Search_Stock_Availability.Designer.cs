﻿namespace Electronic_Shop_Management_CSharp
{
    partial class Frm_Search_Stock_Availability
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Btn_Refresh = new System.Windows.Forms.Button();
            this.Search_CMB = new System.Windows.Forms.ComboBox();
            this.Panel1 = new System.Windows.Forms.Panel();
            this.Lable1 = new System.Windows.Forms.Label();
            this.Btn_search = new System.Windows.Forms.Button();
            this.Value_TB = new System.Windows.Forms.TextBox();
            this.Label2 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // Btn_Refresh
            // 
            this.Btn_Refresh.BackColor = System.Drawing.Color.DimGray;
            this.Btn_Refresh.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn_Refresh.Enabled = false;
            this.Btn_Refresh.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.Btn_Refresh.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_Refresh.ForeColor = System.Drawing.Color.White;
            this.Btn_Refresh.Location = new System.Drawing.Point(826, 121);
            this.Btn_Refresh.Name = "Btn_Refresh";
            this.Btn_Refresh.Size = new System.Drawing.Size(143, 42);
            this.Btn_Refresh.TabIndex = 94;
            this.Btn_Refresh.Text = "Refresh";
            this.Btn_Refresh.UseVisualStyleBackColor = false;
            this.Btn_Refresh.Click += new System.EventHandler(this.Btn_Refresh_Click);
            // 
            // Search_CMB
            // 
            this.Search_CMB.BackColor = System.Drawing.Color.White;
            this.Search_CMB.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Search_CMB.FormattingEnabled = true;
            this.Search_CMB.Items.AddRange(new object[] {
            "Product Id",
            "Product Name",
            "Dealer Name"});
            this.Search_CMB.Location = new System.Drawing.Point(171, 132);
            this.Search_CMB.Name = "Search_CMB";
            this.Search_CMB.Size = new System.Drawing.Size(194, 33);
            this.Search_CMB.TabIndex = 93;
            this.Search_CMB.SelectedIndexChanged += new System.EventHandler(this.Search_CMB_SelectedIndexChanged);
            // 
            // Panel1
            // 
            this.Panel1.BackColor = System.Drawing.Color.Transparent;
            this.Panel1.Controls.Add(this.Lable1);
            this.Panel1.Location = new System.Drawing.Point(0, 0);
            this.Panel1.Name = "Panel1";
            this.Panel1.Size = new System.Drawing.Size(1064, 100);
            this.Panel1.TabIndex = 92;
            // 
            // Lable1
            // 
            this.Lable1.AutoSize = true;
            this.Lable1.Font = new System.Drawing.Font("Verdana", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lable1.Location = new System.Drawing.Point(347, 27);
            this.Lable1.Name = "Lable1";
            this.Lable1.Size = new System.Drawing.Size(371, 45);
            this.Lable1.TabIndex = 28;
            this.Lable1.Text = "Stock Availibility";
            // 
            // Btn_search
            // 
            this.Btn_search.BackColor = System.Drawing.Color.DimGray;
            this.Btn_search.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn_search.Enabled = false;
            this.Btn_search.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.Btn_search.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_search.ForeColor = System.Drawing.Color.White;
            this.Btn_search.Location = new System.Drawing.Point(663, 124);
            this.Btn_search.Name = "Btn_search";
            this.Btn_search.Size = new System.Drawing.Size(143, 42);
            this.Btn_search.TabIndex = 90;
            this.Btn_search.Text = "Search";
            this.Btn_search.UseVisualStyleBackColor = false;
            this.Btn_search.Click += new System.EventHandler(this.Btn_search_Click);
            // 
            // Value_TB
            // 
            this.Value_TB.BackColor = System.Drawing.Color.White;
            this.Value_TB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Value_TB.Enabled = false;
            this.Value_TB.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Value_TB.Location = new System.Drawing.Point(389, 131);
            this.Value_TB.Name = "Value_TB";
            this.Value_TB.Size = new System.Drawing.Size(179, 33);
            this.Value_TB.TabIndex = 89;
            this.Value_TB.TextChanged += new System.EventHandler(this.Value_TB_TextChanged);
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.BackColor = System.Drawing.Color.Transparent;
            this.Label2.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label2.ForeColor = System.Drawing.Color.Black;
            this.Label2.Location = new System.Drawing.Point(25, 130);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(118, 25);
            this.Label2.TabIndex = 91;
            this.Label2.Text = "Search By";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(0, 200);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(1064, 383);
            this.dataGridView1.TabIndex = 95;
            // 
            // Frm_Search_Stock_Availability
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1065, 583);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.Btn_Refresh);
            this.Controls.Add(this.Search_CMB);
            this.Controls.Add(this.Panel1);
            this.Controls.Add(this.Btn_search);
            this.Controls.Add(this.Value_TB);
            this.Controls.Add(this.Label2);
            this.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "Frm_Search_Stock_Availability";
            this.Text = "Frm_Search_Stock_Availability";
            this.Load += new System.EventHandler(this.Frm_Search_Stock_Availability_Load);
            this.Panel1.ResumeLayout(false);
            this.Panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.Button Btn_Refresh;
        internal System.Windows.Forms.ComboBox Search_CMB;
        internal System.Windows.Forms.Panel Panel1;
        internal System.Windows.Forms.Label Lable1;
        internal System.Windows.Forms.Button Btn_search;
        internal System.Windows.Forms.TextBox Value_TB;
        internal System.Windows.Forms.Label Label2;
        private System.Windows.Forms.DataGridView dataGridView1;
    }
}