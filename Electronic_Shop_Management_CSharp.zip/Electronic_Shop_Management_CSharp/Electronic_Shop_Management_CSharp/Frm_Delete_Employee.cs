﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;

namespace Electronic_Shop_Management_CSharp
{
    public partial class Frm_Delete_Employee : Form
    {
        SqlConnection Con = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=Electronic_Shop_Management_DB;Integrated Security=True");
        SqlCommand Cmd = new SqlCommand();
        SqlDataReader dr;
        String str;

        public void Connection_Open()
        {
            if (Con.State == ConnectionState.Closed)
            {
                Con.Open();
            }
        }

        public void Connection_Close()
        {
            if (Con.State == ConnectionState.Open)
            {
                Con.Close();
            }
        }

        public void Clear_Controls()
        {
            Emp_ID_TB.Text = "";
            Emp_Name_TB.Text = "";
            Address_TB.Text = "";
            Emp_Salary_TB.Text = "";
            Mob_No_TB.Text = "";
            Adhar_No_TB.Text = "";
            PAN_No_TB.Text = "";
            Email_ID_TB.Text = "";
        }

        public Frm_Delete_Employee()
        {
            InitializeComponent();
        }

        private void Btn_fetch_Click(object sender, EventArgs e)
        {
            Connection_Open();
            if (Emp_ID_TB.Text != "")
            {
                Cmd.CommandText = "SELECT * FROM Employee_Detail_Table WHERE Emp_ID=" + Emp_ID_TB.Text + "";
                Cmd.Connection = Con;
                dr = Cmd.ExecuteReader();
                if (dr.Read())
                {
                    Emp_Name_TB.Text = dr["Emp_Name"].ToString();
                    Address_TB.Text = dr["Address"].ToString();
                    Emp_Salary_TB.Text = dr["Emp_Salary"].ToString();
                    Mob_No_TB.Text = dr["Mob_No"].ToString();
                    Adhar_No_TB.Text = dr["Adhar_No"].ToString();
                    PAN_No_TB.Text = dr["Pancard_No"].ToString();
                    Email_ID_TB.Text = dr["Email_ID"].ToString();
                }
                else
                {
                    MessageBox.Show("There is error while retriving information!!");
                    Clear_Controls();
                }
            }
            else
            {
                MessageBox.Show("First enter Employee ID");
            }
            Connection_Close();
            Btn_update.Enabled = true;
            Btn_delete.Enabled = true;
            Btn_clear.Enabled = true;
        }

        private void Btn_update_Click(object sender, EventArgs e)
        {
            Connection_Open();
            if (Emp_ID_TB.Text != "" && Emp_Name_TB.Text != "" && Address_TB.Text != "" && Mob_No_TB.Text != "" && Adhar_No_TB.Text != "" && PAN_No_TB.Text != "" && Email_ID_TB.Text != "" && Emp_Salary_TB.Text != "")
            {
                if (Emp_Name_TB.Modified == true || Address_TB.Modified == true || Mob_No_TB.Modified == true || Adhar_No_TB.Modified == true || PAN_No_TB.Modified == true || Email_ID_TB.Modified == true || Emp_Salary_TB.Modified == true)
                {
                    Cmd.CommandText = "UPDATE Employee_Detail_Table SET Emp_Name='" + Emp_Name_TB.Text + "',Address='" + Address_TB.Text + "',Mob_No=" + Mob_No_TB.Text + ",Emp_Salary=" + Emp_Salary_TB.Text + " WHERE Emp_ID=" + Emp_ID_TB.Text + "";
                    Cmd.Connection = Con;
                    str = Convert.ToString(Cmd.ExecuteNonQuery());
                    if (str != null)
                    {
                        MessageBox.Show("Record updated successfully!!");
                        Clear_Controls();
                    }
                    else
                    {
                        MessageBox.Show("There is error while updating record!!");
                    }
                }
                else
                {
                    MessageBox.Show("Please update at least one record!!");
                }
            }
            else
            {
                MessageBox.Show("You can't leave any field empty!");
            }
            Connection_Close();
            Btn_update.Enabled = false;
            Btn_delete.Enabled = false;
            Btn_clear.Enabled = false;
        }

        private void Btn_delete_Click(object sender, EventArgs e)
        {
            Connection_Open();
            if (Emp_ID_TB.Text != "" && Emp_Name_TB.Text != "" && Address_TB.Text != "" && Mob_No_TB.Text != "" && Adhar_No_TB.Text != "" && PAN_No_TB.Text != "" && Email_ID_TB.Text != "" && Emp_Salary_TB.Text != "")
            {
                Cmd.CommandText = "DELETE FROM Employee_Detail_Table WHERE Emp_ID=" + Emp_ID_TB.Text + "";
                Cmd.Connection = Con;
                str = Convert.ToString(Cmd.ExecuteNonQuery());
                if (str != null)
                {
                    MessageBox.Show("Record deleted successfully!!!");
                    Clear_Controls();
                }
                else
                {
                    MessageBox.Show("There is error while deleting record!!");
                }
            }
            else
            {
                MessageBox.Show("You can't leave any field empty!");
            }
            Connection_Close();
            Btn_update.Enabled = false;
            Btn_delete.Enabled = false;
            Btn_clear.Enabled = false;
        }

        private void Btn_clear_Click(object sender, EventArgs e)
        {
            Clear_Controls();
            Btn_update.Enabled = false;
            Btn_delete.Enabled = false;
            Btn_clear.Enabled = false;
            Btn_fetch.Enabled = false;
        }

        private void Btn_exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Frm_Delete_Employee_Leave(object sender, EventArgs e)
        {
            Clear_Controls();
        }

        private void Emp_ID_TB_TextChanged(object sender, EventArgs e)
        {
            Btn_fetch.Enabled = true;
        }
    }
}
