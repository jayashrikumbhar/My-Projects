﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Electronic_Shop_Management_CSharp
{
    public partial class Frm_Stock_Added_Detail : Form
    {
        SqlConnection Con = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=Electronic_Shop_Management_DB;Integrated Security=True");
        SqlCommand Cmd = new SqlCommand();

        public void Connection_Open()
        {
            if (Con.State == ConnectionState.Closed)
            {
                Con.Open();
            }
        }

        public void Connection_Close()
        {
            if (Con.State == ConnectionState.Open)
            {
                Con.Close();
            }
        }

        public Frm_Stock_Added_Detail()
        {
            InitializeComponent();
        }

        private void Btn_search_Click(object sender, EventArgs e)
        {
            Connection_Open();

            Cmd.CommandText = "SELECT * FROM Stock_Detail_Table WHERE System_Date='" + System_Date_DTP.Text + "'";
            Cmd.Connection = Con;

            SqlDataAdapter da = new SqlDataAdapter(Cmd);
            DataTable dt = new DataTable();

            da.Fill(dt);
            dataGridView1.DataSource = dt;
            Connection_Close();
        }

        private void Frm_Stock_Added_Detail_Load(object sender, EventArgs e)
        {
            Connection_Open();

            Cmd.CommandText = "SELECT * FROM Stock_Detail_Table";
            Cmd.Connection = Con;

            SqlDataAdapter da = new SqlDataAdapter(Cmd);
            DataTable dt = new DataTable();

            da.Fill(dt);
            dataGridView1.DataSource = dt;
            Connection_Close();
        }

        private void Btn_refresh_Click(object sender, EventArgs e)
        {
            Connection_Open();

            Cmd.CommandText = "SELECT * FROM Stock_Detail_Table";
            Cmd.Connection = Con;

            SqlDataAdapter da = new SqlDataAdapter(Cmd);
            DataTable dt = new DataTable();

            da.Fill(dt);
            dataGridView1.DataSource = dt;
            Connection_Close();

            Btn_search.Enabled = false;
            Btn_refresh.Enabled = false;
        }

        private void System_Date_DTP_ValueChanged(object sender, EventArgs e)
        {
            Btn_search.Enabled = true;
            Btn_refresh.Enabled = true;
        }

    }
}
