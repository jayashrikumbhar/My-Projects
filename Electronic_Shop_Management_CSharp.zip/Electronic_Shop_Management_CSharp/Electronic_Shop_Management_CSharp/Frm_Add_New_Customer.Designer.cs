﻿namespace Electronic_Shop_Management_CSharp
{
    partial class Frm_Add_New_Customer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.Label9 = new System.Windows.Forms.Label();
            this.Btn_Add = new System.Windows.Forms.Button();
            this.product_grid = new System.Windows.Forms.DataGridView();
            this.Label12 = new System.Windows.Forms.Label();
            this.CGST_TB = new System.Windows.Forms.TextBox();
            this.Label11 = new System.Windows.Forms.Label();
            this.Sale_Rate_TB = new System.Windows.Forms.TextBox();
            this.Label10 = new System.Windows.Forms.Label();
            this.Total_Amount_TB = new System.Windows.Forms.TextBox();
            this.Price_TB = new System.Windows.Forms.TextBox();
            this.Electronic_Product_GrpBox = new System.Windows.Forms.GroupBox();
            this.Btn_Confirm = new System.Windows.Forms.Button();
            this.SGST_TB = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.Btn_Remove = new System.Windows.Forms.Button();
            this.Discount_TB = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Label24 = new System.Windows.Forms.Label();
            this.Brand_CMB = new System.Windows.Forms.ComboBox();
            this.Quantity_TB = new System.Windows.Forms.TextBox();
            this.Label20 = new System.Windows.Forms.Label();
            this.Label13 = new System.Windows.Forms.Label();
            this.Product_Name_CMB = new System.Windows.Forms.ComboBox();
            this.Btn_save = new System.Windows.Forms.Button();
            this.Address_TB = new System.Windows.Forms.TextBox();
            this.Mob_No_TB = new System.Windows.Forms.TextBox();
            this.GroupBox1 = new System.Windows.Forms.GroupBox();
            this.Cust_Name_TB = new System.Windows.Forms.TextBox();
            this.Cust_ID_TB = new System.Windows.Forms.TextBox();
            this.Label2 = new System.Windows.Forms.Label();
            this.Label5 = new System.Windows.Forms.Label();
            this.Label4 = new System.Windows.Forms.Label();
            this.Label3 = new System.Windows.Forms.Label();
            this.Lable1 = new System.Windows.Forms.Label();
            this.System_Date_DTP = new System.Windows.Forms.DateTimePicker();
            this.Label40 = new System.Windows.Forms.Label();
            this.Panel1 = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.product_grid)).BeginInit();
            this.Electronic_Product_GrpBox.SuspendLayout();
            this.GroupBox1.SuspendLayout();
            this.Panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // Label9
            // 
            this.Label9.AutoSize = true;
            this.Label9.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label9.ForeColor = System.Drawing.Color.Black;
            this.Label9.Location = new System.Drawing.Point(223, 30);
            this.Label9.Name = "Label9";
            this.Label9.Size = new System.Drawing.Size(133, 18);
            this.Label9.TabIndex = 116;
            this.Label9.Text = "Product Name";
            // 
            // Btn_Add
            // 
            this.Btn_Add.BackColor = System.Drawing.Color.DimGray;
            this.Btn_Add.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn_Add.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.Btn_Add.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_Add.Location = new System.Drawing.Point(1080, 58);
            this.Btn_Add.Name = "Btn_Add";
            this.Btn_Add.Size = new System.Drawing.Size(79, 44);
            this.Btn_Add.TabIndex = 7;
            this.Btn_Add.Text = "Add";
            this.Btn_Add.UseVisualStyleBackColor = false;
            this.Btn_Add.Click += new System.EventHandler(this.Btn_Add_Click);
            // 
            // product_grid
            // 
            this.product_grid.AllowUserToAddRows = false;
            this.product_grid.AllowUserToDeleteRows = false;
            this.product_grid.AllowUserToResizeColumns = false;
            this.product_grid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.product_grid.BackgroundColor = System.Drawing.SystemColors.ControlDark;
            this.product_grid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.product_grid.Location = new System.Drawing.Point(0, 113);
            this.product_grid.Name = "product_grid";
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            this.product_grid.RowsDefaultCellStyle = dataGridViewCellStyle3;
            this.product_grid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.product_grid.Size = new System.Drawing.Size(1366, 128);
            this.product_grid.TabIndex = 113;
            this.product_grid.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.product_grid_CellContentClick);
            // 
            // Label12
            // 
            this.Label12.AutoSize = true;
            this.Label12.Font = new System.Drawing.Font("Palatino Linotype", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label12.ForeColor = System.Drawing.Color.Black;
            this.Label12.Location = new System.Drawing.Point(1023, 257);
            this.Label12.Name = "Label12";
            this.Label12.Size = new System.Drawing.Size(149, 28);
            this.Label12.TabIndex = 112;
            this.Label12.Text = "Total Amount";
            // 
            // CGST_TB
            // 
            this.CGST_TB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.CGST_TB.Enabled = false;
            this.CGST_TB.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CGST_TB.Location = new System.Drawing.Point(561, 72);
            this.CGST_TB.Name = "CGST_TB";
            this.CGST_TB.Size = new System.Drawing.Size(94, 27);
            this.CGST_TB.TabIndex = 12;
            // 
            // Label11
            // 
            this.Label11.AutoSize = true;
            this.Label11.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label11.ForeColor = System.Drawing.Color.Black;
            this.Label11.Location = new System.Drawing.Point(564, 29);
            this.Label11.Name = "Label11";
            this.Label11.Size = new System.Drawing.Size(81, 18);
            this.Label11.TabIndex = 107;
            this.Label11.Text = "CGST %";
            // 
            // Sale_Rate_TB
            // 
            this.Sale_Rate_TB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Sale_Rate_TB.Enabled = false;
            this.Sale_Rate_TB.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Sale_Rate_TB.ForeColor = System.Drawing.Color.Black;
            this.Sale_Rate_TB.Location = new System.Drawing.Point(426, 72);
            this.Sale_Rate_TB.Name = "Sale_Rate_TB";
            this.Sale_Rate_TB.Size = new System.Drawing.Size(101, 27);
            this.Sale_Rate_TB.TabIndex = 11;
            // 
            // Label10
            // 
            this.Label10.AutoSize = true;
            this.Label10.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label10.ForeColor = System.Drawing.Color.Black;
            this.Label10.Location = new System.Drawing.Point(429, 30);
            this.Label10.Name = "Label10";
            this.Label10.Size = new System.Drawing.Size(92, 18);
            this.Label10.TabIndex = 102;
            this.Label10.Text = "Sale Rate";
            // 
            // Total_Amount_TB
            // 
            this.Total_Amount_TB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Total_Amount_TB.Enabled = false;
            this.Total_Amount_TB.Font = new System.Drawing.Font("Palatino Linotype", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Total_Amount_TB.Location = new System.Drawing.Point(1210, 247);
            this.Total_Amount_TB.Name = "Total_Amount_TB";
            this.Total_Amount_TB.ReadOnly = true;
            this.Total_Amount_TB.Size = new System.Drawing.Size(116, 40);
            this.Total_Amount_TB.TabIndex = 32;
            this.Total_Amount_TB.Text = "0";
            // 
            // Price_TB
            // 
            this.Price_TB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Price_TB.Enabled = false;
            this.Price_TB.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Price_TB.Location = new System.Drawing.Point(947, 72);
            this.Price_TB.Name = "Price_TB";
            this.Price_TB.ReadOnly = true;
            this.Price_TB.Size = new System.Drawing.Size(116, 27);
            this.Price_TB.TabIndex = 6;
            // 
            // Electronic_Product_GrpBox
            // 
            this.Electronic_Product_GrpBox.BackColor = System.Drawing.Color.Transparent;
            this.Electronic_Product_GrpBox.Controls.Add(this.Btn_Confirm);
            this.Electronic_Product_GrpBox.Controls.Add(this.SGST_TB);
            this.Electronic_Product_GrpBox.Controls.Add(this.label6);
            this.Electronic_Product_GrpBox.Controls.Add(this.Btn_Remove);
            this.Electronic_Product_GrpBox.Controls.Add(this.Discount_TB);
            this.Electronic_Product_GrpBox.Controls.Add(this.label1);
            this.Electronic_Product_GrpBox.Controls.Add(this.Label9);
            this.Electronic_Product_GrpBox.Controls.Add(this.Btn_Add);
            this.Electronic_Product_GrpBox.Controls.Add(this.product_grid);
            this.Electronic_Product_GrpBox.Controls.Add(this.Label12);
            this.Electronic_Product_GrpBox.Controls.Add(this.CGST_TB);
            this.Electronic_Product_GrpBox.Controls.Add(this.Label11);
            this.Electronic_Product_GrpBox.Controls.Add(this.Sale_Rate_TB);
            this.Electronic_Product_GrpBox.Controls.Add(this.Label10);
            this.Electronic_Product_GrpBox.Controls.Add(this.Total_Amount_TB);
            this.Electronic_Product_GrpBox.Controls.Add(this.Price_TB);
            this.Electronic_Product_GrpBox.Controls.Add(this.Label24);
            this.Electronic_Product_GrpBox.Controls.Add(this.Brand_CMB);
            this.Electronic_Product_GrpBox.Controls.Add(this.Quantity_TB);
            this.Electronic_Product_GrpBox.Controls.Add(this.Label20);
            this.Electronic_Product_GrpBox.Controls.Add(this.Label13);
            this.Electronic_Product_GrpBox.Controls.Add(this.Product_Name_CMB);
            this.Electronic_Product_GrpBox.Enabled = false;
            this.Electronic_Product_GrpBox.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Electronic_Product_GrpBox.Location = new System.Drawing.Point(1, 299);
            this.Electronic_Product_GrpBox.Name = "Electronic_Product_GrpBox";
            this.Electronic_Product_GrpBox.Size = new System.Drawing.Size(1372, 302);
            this.Electronic_Product_GrpBox.TabIndex = 89;
            this.Electronic_Product_GrpBox.TabStop = false;
            this.Electronic_Product_GrpBox.Text = "Electronic Product";
            // 
            // Btn_Confirm
            // 
            this.Btn_Confirm.BackColor = System.Drawing.Color.DimGray;
            this.Btn_Confirm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn_Confirm.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.Btn_Confirm.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_Confirm.Location = new System.Drawing.Point(1276, 58);
            this.Btn_Confirm.Name = "Btn_Confirm";
            this.Btn_Confirm.Size = new System.Drawing.Size(90, 44);
            this.Btn_Confirm.TabIndex = 9;
            this.Btn_Confirm.Text = "Confirm";
            this.Btn_Confirm.UseVisualStyleBackColor = false;
            this.Btn_Confirm.Click += new System.EventHandler(this.Btn_Confirm_Click);
            // 
            // SGST_TB
            // 
            this.SGST_TB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.SGST_TB.Enabled = false;
            this.SGST_TB.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SGST_TB.Location = new System.Drawing.Point(690, 72);
            this.SGST_TB.Name = "SGST_TB";
            this.SGST_TB.Size = new System.Drawing.Size(94, 27);
            this.SGST_TB.TabIndex = 120;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(692, 29);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(80, 18);
            this.label6.TabIndex = 121;
            this.label6.Text = "SGST %";
            // 
            // Btn_Remove
            // 
            this.Btn_Remove.BackColor = System.Drawing.Color.DimGray;
            this.Btn_Remove.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn_Remove.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.Btn_Remove.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_Remove.Location = new System.Drawing.Point(1165, 58);
            this.Btn_Remove.Name = "Btn_Remove";
            this.Btn_Remove.Size = new System.Drawing.Size(105, 44);
            this.Btn_Remove.TabIndex = 8;
            this.Btn_Remove.Text = "Remove";
            this.Btn_Remove.UseVisualStyleBackColor = false;
            this.Btn_Remove.Click += new System.EventHandler(this.Btn_Remove_Click);
            // 
            // Discount_TB
            // 
            this.Discount_TB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Discount_TB.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Discount_TB.Location = new System.Drawing.Point(853, 261);
            this.Discount_TB.Name = "Discount_TB";
            this.Discount_TB.Size = new System.Drawing.Size(145, 27);
            this.Discount_TB.TabIndex = 10;
            //this.Discount_TB.TextChanged += new System.EventHandler(this.Discount_TB_TextChanged);
            this.Discount_TB.Leave += new System.EventHandler(this.Discount_TB_Leave);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(741, 262);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(94, 23);
            this.label1.TabIndex = 118;
            this.label1.Text = "Discount";
            // 
            // Label24
            // 
            this.Label24.AutoSize = true;
            this.Label24.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label24.ForeColor = System.Drawing.Color.Black;
            this.Label24.Location = new System.Drawing.Point(969, 32);
            this.Label24.Name = "Label24";
            this.Label24.Size = new System.Drawing.Size(52, 18);
            this.Label24.TabIndex = 91;
            this.Label24.Text = "Price";
            // 
            // Brand_CMB
            // 
            this.Brand_CMB.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Brand_CMB.ForeColor = System.Drawing.Color.Black;
            this.Brand_CMB.FormattingEnabled = true;
            this.Brand_CMB.Location = new System.Drawing.Point(6, 74);
            this.Brand_CMB.Name = "Brand_CMB";
            this.Brand_CMB.Size = new System.Drawing.Size(173, 26);
            this.Brand_CMB.TabIndex = 4;
            this.Brand_CMB.Text = "Select Brand";
            this.Brand_CMB.SelectedIndexChanged += new System.EventHandler(this.Brand_CMB_SelectedIndexChanged);
            // 
            // Quantity_TB
            // 
            this.Quantity_TB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Quantity_TB.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Quantity_TB.Location = new System.Drawing.Point(810, 72);
            this.Quantity_TB.Name = "Quantity_TB";
            this.Quantity_TB.Size = new System.Drawing.Size(116, 27);
            this.Quantity_TB.TabIndex = 6;
            this.Quantity_TB.TextChanged += new System.EventHandler(this.Quantity_TB_TextChanged);
            this.Quantity_TB.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Quantity_TB_KeyPress);
            // 
            // Label20
            // 
            this.Label20.AutoSize = true;
            this.Label20.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label20.ForeColor = System.Drawing.Color.Black;
            this.Label20.Location = new System.Drawing.Point(818, 29);
            this.Label20.Name = "Label20";
            this.Label20.Size = new System.Drawing.Size(83, 18);
            this.Label20.TabIndex = 79;
            this.Label20.Text = "Quantity";
            // 
            // Label13
            // 
            this.Label13.AutoSize = true;
            this.Label13.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label13.ForeColor = System.Drawing.Color.Black;
            this.Label13.Location = new System.Drawing.Point(46, 32);
            this.Label13.Name = "Label13";
            this.Label13.Size = new System.Drawing.Size(61, 18);
            this.Label13.TabIndex = 71;
            this.Label13.Text = "Brand";
            // 
            // Product_Name_CMB
            // 
            this.Product_Name_CMB.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Product_Name_CMB.FormattingEnabled = true;
            this.Product_Name_CMB.Location = new System.Drawing.Point(195, 74);
            this.Product_Name_CMB.Name = "Product_Name_CMB";
            this.Product_Name_CMB.Size = new System.Drawing.Size(195, 26);
            this.Product_Name_CMB.TabIndex = 5;
            this.Product_Name_CMB.Text = "Select Product";
            this.Product_Name_CMB.SelectedIndexChanged += new System.EventHandler(this.Product_Name_CMB_SelectedIndexChanged);
            // 
            // Btn_save
            // 
            this.Btn_save.BackColor = System.Drawing.Color.DimGray;
            this.Btn_save.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn_save.Enabled = false;
            this.Btn_save.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.Btn_save.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_save.Location = new System.Drawing.Point(535, 615);
            this.Btn_save.Name = "Btn_save";
            this.Btn_save.Size = new System.Drawing.Size(224, 46);
            this.Btn_save.TabIndex = 11;
            this.Btn_save.Text = "Save And Print";
            this.Btn_save.UseVisualStyleBackColor = false;
            this.Btn_save.Click += new System.EventHandler(this.Btn_save_Click);
            // 
            // Address_TB
            // 
            this.Address_TB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Address_TB.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Address_TB.Location = new System.Drawing.Point(903, 24);
            this.Address_TB.Name = "Address_TB";
            this.Address_TB.Size = new System.Drawing.Size(265, 27);
            this.Address_TB.TabIndex = 2;
            // 
            // Mob_No_TB
            // 
            this.Mob_No_TB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Mob_No_TB.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Mob_No_TB.Location = new System.Drawing.Point(903, 64);
            this.Mob_No_TB.MaxLength = 10;
            this.Mob_No_TB.Name = "Mob_No_TB";
            this.Mob_No_TB.Size = new System.Drawing.Size(265, 27);
            this.Mob_No_TB.TabIndex = 3;
            this.Mob_No_TB.TextChanged += new System.EventHandler(this.Mob_No_TB_TextChanged);
            this.Mob_No_TB.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Mob_No_TB_KeyPress);
            // 
            // GroupBox1
            // 
            this.GroupBox1.BackColor = System.Drawing.Color.Transparent;
            this.GroupBox1.Controls.Add(this.Address_TB);
            this.GroupBox1.Controls.Add(this.Mob_No_TB);
            this.GroupBox1.Controls.Add(this.Cust_Name_TB);
            this.GroupBox1.Controls.Add(this.Cust_ID_TB);
            this.GroupBox1.Controls.Add(this.Label2);
            this.GroupBox1.Controls.Add(this.Label5);
            this.GroupBox1.Controls.Add(this.Label4);
            this.GroupBox1.Controls.Add(this.Label3);
            this.GroupBox1.ForeColor = System.Drawing.Color.Black;
            this.GroupBox1.Location = new System.Drawing.Point(1, 160);
            this.GroupBox1.Name = "GroupBox1";
            this.GroupBox1.Size = new System.Drawing.Size(1372, 133);
            this.GroupBox1.TabIndex = 91;
            this.GroupBox1.TabStop = false;
            // 
            // Cust_Name_TB
            // 
            this.Cust_Name_TB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Cust_Name_TB.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Cust_Name_TB.Location = new System.Drawing.Point(344, 71);
            this.Cust_Name_TB.Name = "Cust_Name_TB";
            this.Cust_Name_TB.Size = new System.Drawing.Size(265, 27);
            this.Cust_Name_TB.TabIndex = 1;
            // 
            // Cust_ID_TB
            // 
            this.Cust_ID_TB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Cust_ID_TB.Enabled = false;
            this.Cust_ID_TB.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Cust_ID_TB.Location = new System.Drawing.Point(344, 27);
            this.Cust_ID_TB.Name = "Cust_ID_TB";
            this.Cust_ID_TB.Size = new System.Drawing.Size(265, 27);
            this.Cust_ID_TB.TabIndex = 67;
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label2.ForeColor = System.Drawing.Color.Black;
            this.Label2.Location = new System.Drawing.Point(113, 30);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(117, 18);
            this.Label2.TabIndex = 69;
            this.Label2.Text = "Customer  ID";
            // 
            // Label5
            // 
            this.Label5.AutoSize = true;
            this.Label5.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label5.ForeColor = System.Drawing.Color.Black;
            this.Label5.Location = new System.Drawing.Point(113, 73);
            this.Label5.Name = "Label5";
            this.Label5.Size = new System.Drawing.Size(139, 18);
            this.Label5.TabIndex = 82;
            this.Label5.Text = "Customer Name";
            // 
            // Label4
            // 
            this.Label4.AutoSize = true;
            this.Label4.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label4.ForeColor = System.Drawing.Color.Black;
            this.Label4.Location = new System.Drawing.Point(724, 26);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(73, 18);
            this.Label4.TabIndex = 81;
            this.Label4.Text = "Address";
            // 
            // Label3
            // 
            this.Label3.AutoSize = true;
            this.Label3.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label3.ForeColor = System.Drawing.Color.Black;
            this.Label3.Location = new System.Drawing.Point(724, 66);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(130, 18);
            this.Label3.TabIndex = 80;
            this.Label3.Text = "Mobile Number";
            // 
            // Lable1
            // 
            this.Lable1.AutoSize = true;
            this.Lable1.Font = new System.Drawing.Font("Verdana", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lable1.ForeColor = System.Drawing.Color.Black;
            this.Lable1.Location = new System.Drawing.Point(438, 18);
            this.Lable1.Name = "Lable1";
            this.Lable1.Size = new System.Drawing.Size(496, 45);
            this.Lable1.TabIndex = 55;
            this.Lable1.Text = " New Customer Details";
            // 
            // System_Date_DTP
            // 
            this.System_Date_DTP.CalendarFont = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.System_Date_DTP.Enabled = false;
            this.System_Date_DTP.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.System_Date_DTP.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.System_Date_DTP.Location = new System.Drawing.Point(1109, 106);
            this.System_Date_DTP.Name = "System_Date_DTP";
            this.System_Date_DTP.Size = new System.Drawing.Size(249, 27);
            this.System_Date_DTP.TabIndex = 92;
            // 
            // Label40
            // 
            this.Label40.AutoSize = true;
            this.Label40.BackColor = System.Drawing.Color.Transparent;
            this.Label40.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label40.ForeColor = System.Drawing.Color.Black;
            this.Label40.Location = new System.Drawing.Point(1048, 112);
            this.Label40.Name = "Label40";
            this.Label40.Size = new System.Drawing.Size(55, 18);
            this.Label40.TabIndex = 93;
            this.Label40.Text = "Date ";
            // 
            // Panel1
            // 
            this.Panel1.BackColor = System.Drawing.Color.Transparent;
            this.Panel1.Controls.Add(this.Lable1);
            this.Panel1.Location = new System.Drawing.Point(1, 0);
            this.Panel1.Name = "Panel1";
            this.Panel1.Size = new System.Drawing.Size(1372, 87);
            this.Panel1.TabIndex = 90;
            // 
            // Frm_Add_New_Customer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1370, 682);
            this.Controls.Add(this.Electronic_Product_GrpBox);
            this.Controls.Add(this.Btn_save);
            this.Controls.Add(this.GroupBox1);
            this.Controls.Add(this.System_Date_DTP);
            this.Controls.Add(this.Label40);
            this.Controls.Add(this.Panel1);
            this.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "Frm_Add_New_Customer";
            this.Text = "Frm_Add_New_Customer";
            this.Load += new System.EventHandler(this.Frm_Add_New_Customer_Load);
            ((System.ComponentModel.ISupportInitialize)(this.product_grid)).EndInit();
            this.Electronic_Product_GrpBox.ResumeLayout(false);
            this.Electronic_Product_GrpBox.PerformLayout();
            this.GroupBox1.ResumeLayout(false);
            this.GroupBox1.PerformLayout();
            this.Panel1.ResumeLayout(false);
            this.Panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.Label Label9;
        internal System.Windows.Forms.Button Btn_Add;
        internal System.Windows.Forms.DataGridView product_grid;
        internal System.Windows.Forms.Label Label12;
        internal System.Windows.Forms.TextBox CGST_TB;
        internal System.Windows.Forms.Label Label11;
        internal System.Windows.Forms.TextBox Sale_Rate_TB;
        internal System.Windows.Forms.Label Label10;
        internal System.Windows.Forms.TextBox Total_Amount_TB;
        internal System.Windows.Forms.TextBox Price_TB;
        internal System.Windows.Forms.GroupBox Electronic_Product_GrpBox;
        internal System.Windows.Forms.Label Label24;
        internal System.Windows.Forms.ComboBox Brand_CMB;
        internal System.Windows.Forms.TextBox Quantity_TB;
        internal System.Windows.Forms.Label Label20;
        internal System.Windows.Forms.Label Label13;
        internal System.Windows.Forms.ComboBox Product_Name_CMB;
        internal System.Windows.Forms.Button Btn_save;
        internal System.Windows.Forms.TextBox Address_TB;
        internal System.Windows.Forms.TextBox Mob_No_TB;
        internal System.Windows.Forms.GroupBox GroupBox1;
        internal System.Windows.Forms.TextBox Cust_Name_TB;
        internal System.Windows.Forms.TextBox Cust_ID_TB;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.Label Label5;
        internal System.Windows.Forms.Label Label4;
        internal System.Windows.Forms.Label Label3;
        internal System.Windows.Forms.Label Lable1;
        internal System.Windows.Forms.DateTimePicker System_Date_DTP;
        internal System.Windows.Forms.Label Label40;
        internal System.Windows.Forms.Panel Panel1;
        internal System.Windows.Forms.Button Btn_Remove;
        internal System.Windows.Forms.TextBox Discount_TB;
        internal System.Windows.Forms.Label label1;
        internal System.Windows.Forms.TextBox SGST_TB;
        internal System.Windows.Forms.Label label6;
        internal System.Windows.Forms.Button Btn_Confirm;
    }
}