﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace Electronic_Shop_Management_CSharp
{
    class ConnectionCls
    {
        public static int User_Mgt = 0;

        SqlConnection Con = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=Electronic_Shop_Management_DB;Integrated Security=True");
        SqlCommand Cmd = new SqlCommand();


        public void Connection_Open()
        {
            if (Con.State == ConnectionState.Closed)
            {
                Con.Open();
            }

        }

        public void Connection_Close()
        {
            if (Con.State == ConnectionState.Open)
            {
                Con.Close();
            }
        }

        public int Autoincreament(string str)
        {
            Connection_Open();
            Cmd.CommandText = str;
            Cmd.Connection = Con;
            int a = Convert.ToInt32(Cmd.ExecuteScalar());

            if (a > 0)
            {
                a = a + 1001;
            }
            else
            {
                a = 1001;
            }

            Connection_Close();
            return a;
        }
    }
}
