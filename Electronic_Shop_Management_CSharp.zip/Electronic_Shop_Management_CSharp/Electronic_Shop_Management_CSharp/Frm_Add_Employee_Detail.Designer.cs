﻿namespace Electronic_Shop_Management_CSharp
{
    partial class Frm_Add_Employee_Detail
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Btn_exit = new System.Windows.Forms.Button();
            this.Emp_Salary_TB = new System.Windows.Forms.TextBox();
            this.Label8 = new System.Windows.Forms.Label();
            this.Email_ID_TB = new System.Windows.Forms.TextBox();
            this.Label7 = new System.Windows.Forms.Label();
            this.PAN_No_TB = new System.Windows.Forms.TextBox();
            this.Label1 = new System.Windows.Forms.Label();
            this.Adhar_TB = new System.Windows.Forms.TextBox();
            this.Label6 = new System.Windows.Forms.Label();
            this.Emp_Add_TB = new System.Windows.Forms.TextBox();
            this.Mob_No_TB = new System.Windows.Forms.TextBox();
            this.Emp_Name_TB = new System.Windows.Forms.TextBox();
            this.Label5 = new System.Windows.Forms.Label();
            this.Label4 = new System.Windows.Forms.Label();
            this.Label3 = new System.Windows.Forms.Label();
            this.Emp_Id_TB = new System.Windows.Forms.TextBox();
            this.Label2 = new System.Windows.Forms.Label();
            this.Panel1 = new System.Windows.Forms.Panel();
            this.Lable1 = new System.Windows.Forms.Label();
            this.Btn_clear = new System.Windows.Forms.Button();
            this.Btn_save = new System.Windows.Forms.Button();
            this.Panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // Btn_exit
            // 
            this.Btn_exit.BackColor = System.Drawing.Color.Lavender;
            this.Btn_exit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn_exit.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.Btn_exit.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_exit.ForeColor = System.Drawing.Color.Black;
            this.Btn_exit.Location = new System.Drawing.Point(808, 477);
            this.Btn_exit.Name = "Btn_exit";
            this.Btn_exit.Size = new System.Drawing.Size(143, 42);
            this.Btn_exit.TabIndex = 117;
            this.Btn_exit.Text = "Exit";
            this.Btn_exit.UseVisualStyleBackColor = false;
            this.Btn_exit.Click += new System.EventHandler(this.Btn_exit_Click);
            // 
            // Emp_Salary_TB
            // 
            this.Emp_Salary_TB.BackColor = System.Drawing.Color.White;
            this.Emp_Salary_TB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Emp_Salary_TB.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Emp_Salary_TB.Location = new System.Drawing.Point(822, 393);
            this.Emp_Salary_TB.MaxLength = 10;
            this.Emp_Salary_TB.Name = "Emp_Salary_TB";
            this.Emp_Salary_TB.Size = new System.Drawing.Size(299, 33);
            this.Emp_Salary_TB.TabIndex = 106;
            this.Emp_Salary_TB.TextChanged += new System.EventHandler(this.Emp_Salary_TB_TextChanged);
            //this.Emp_Salary_TB.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Emp_Salary_TB_KeyPress);
            // 
            // Label8
            // 
            this.Label8.AutoSize = true;
            this.Label8.BackColor = System.Drawing.Color.Transparent;
            this.Label8.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label8.ForeColor = System.Drawing.Color.Black;
            this.Label8.Location = new System.Drawing.Point(623, 400);
            this.Label8.Name = "Label8";
            this.Label8.Size = new System.Drawing.Size(143, 18);
            this.Label8.TabIndex = 116;
            this.Label8.Text = "Employee Salary";
            // 
            // Email_ID_TB
            // 
            this.Email_ID_TB.BackColor = System.Drawing.Color.White;
            this.Email_ID_TB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Email_ID_TB.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Email_ID_TB.Location = new System.Drawing.Point(822, 327);
            this.Email_ID_TB.MaxLength = 50;
            this.Email_ID_TB.Name = "Email_ID_TB";
            this.Email_ID_TB.Size = new System.Drawing.Size(299, 33);
            this.Email_ID_TB.TabIndex = 105;
            // 
            // Label7
            // 
            this.Label7.AutoSize = true;
            this.Label7.BackColor = System.Drawing.Color.Transparent;
            this.Label7.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label7.ForeColor = System.Drawing.Color.Black;
            this.Label7.Location = new System.Drawing.Point(623, 334);
            this.Label7.Name = "Label7";
            this.Label7.Size = new System.Drawing.Size(78, 18);
            this.Label7.TabIndex = 115;
            this.Label7.Text = "Email ID";
            // 
            // PAN_No_TB
            // 
            this.PAN_No_TB.BackColor = System.Drawing.Color.White;
            this.PAN_No_TB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PAN_No_TB.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PAN_No_TB.Location = new System.Drawing.Point(822, 259);
            this.PAN_No_TB.MaxLength = 10;
            this.PAN_No_TB.Name = "PAN_No_TB";
            this.PAN_No_TB.Size = new System.Drawing.Size(299, 33);
            this.PAN_No_TB.TabIndex = 104;
            this.PAN_No_TB.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.PAN_No_TB_KeyPress);
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.BackColor = System.Drawing.Color.Transparent;
            this.Label1.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label1.ForeColor = System.Drawing.Color.Black;
            this.Label1.Location = new System.Drawing.Point(623, 266);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(150, 18);
            this.Label1.TabIndex = 114;
            this.Label1.Text = "Pan Card Number";
            // 
            // Adhar_TB
            // 
            this.Adhar_TB.BackColor = System.Drawing.Color.White;
            this.Adhar_TB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Adhar_TB.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Adhar_TB.Location = new System.Drawing.Point(822, 189);
            this.Adhar_TB.MaxLength = 12;
            this.Adhar_TB.Name = "Adhar_TB";
            this.Adhar_TB.Size = new System.Drawing.Size(299, 33);
            this.Adhar_TB.TabIndex = 103;
            this.Adhar_TB.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Adhar_TB_KeyPress);
            // 
            // Label6
            // 
            this.Label6.AutoSize = true;
            this.Label6.BackColor = System.Drawing.Color.Transparent;
            this.Label6.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label6.ForeColor = System.Drawing.Color.Black;
            this.Label6.Location = new System.Drawing.Point(623, 199);
            this.Label6.Name = "Label6";
            this.Label6.Size = new System.Drawing.Size(124, 18);
            this.Label6.TabIndex = 113;
            this.Label6.Text = "Adhar Number";
            // 
            // Emp_Add_TB
            // 
            this.Emp_Add_TB.BackColor = System.Drawing.Color.White;
            this.Emp_Add_TB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Emp_Add_TB.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Emp_Add_TB.Location = new System.Drawing.Point(210, 335);
            this.Emp_Add_TB.Name = "Emp_Add_TB";
            this.Emp_Add_TB.Size = new System.Drawing.Size(299, 33);
            this.Emp_Add_TB.TabIndex = 101;
            // 
            // Mob_No_TB
            // 
            this.Mob_No_TB.BackColor = System.Drawing.Color.White;
            this.Mob_No_TB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Mob_No_TB.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Mob_No_TB.Location = new System.Drawing.Point(210, 401);
            this.Mob_No_TB.MaxLength = 10;
            this.Mob_No_TB.Name = "Mob_No_TB";
            this.Mob_No_TB.Size = new System.Drawing.Size(299, 33);
            this.Mob_No_TB.TabIndex = 102;
            this.Mob_No_TB.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Mob_No_TB_KeyPress);
            // 
            // Emp_Name_TB
            // 
            this.Emp_Name_TB.BackColor = System.Drawing.Color.White;
            this.Emp_Name_TB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Emp_Name_TB.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Emp_Name_TB.Location = new System.Drawing.Point(210, 267);
            this.Emp_Name_TB.Name = "Emp_Name_TB";
            this.Emp_Name_TB.Size = new System.Drawing.Size(299, 33);
            this.Emp_Name_TB.TabIndex = 100;
            // 
            // Label5
            // 
            this.Label5.AutoSize = true;
            this.Label5.BackColor = System.Drawing.Color.Transparent;
            this.Label5.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label5.ForeColor = System.Drawing.Color.Black;
            this.Label5.Location = new System.Drawing.Point(10, 267);
            this.Label5.Name = "Label5";
            this.Label5.Size = new System.Drawing.Size(140, 18);
            this.Label5.TabIndex = 112;
            this.Label5.Text = "Employee Name";
            // 
            // Label4
            // 
            this.Label4.AutoSize = true;
            this.Label4.BackColor = System.Drawing.Color.Transparent;
            this.Label4.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label4.ForeColor = System.Drawing.Color.Black;
            this.Label4.Location = new System.Drawing.Point(10, 335);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(73, 18);
            this.Label4.TabIndex = 111;
            this.Label4.Text = "Address";
            // 
            // Label3
            // 
            this.Label3.AutoSize = true;
            this.Label3.BackColor = System.Drawing.Color.Transparent;
            this.Label3.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label3.ForeColor = System.Drawing.Color.Black;
            this.Label3.Location = new System.Drawing.Point(10, 401);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(130, 18);
            this.Label3.TabIndex = 110;
            this.Label3.Text = "Mobile Number";
            // 
            // Emp_Id_TB
            // 
            this.Emp_Id_TB.BackColor = System.Drawing.Color.White;
            this.Emp_Id_TB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Emp_Id_TB.Enabled = false;
            this.Emp_Id_TB.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Emp_Id_TB.Location = new System.Drawing.Point(210, 200);
            this.Emp_Id_TB.Name = "Emp_Id_TB";
            this.Emp_Id_TB.Size = new System.Drawing.Size(299, 33);
            this.Emp_Id_TB.TabIndex = 99;
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.BackColor = System.Drawing.Color.Transparent;
            this.Label2.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label2.ForeColor = System.Drawing.Color.Black;
            this.Label2.Location = new System.Drawing.Point(10, 200);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(112, 18);
            this.Label2.TabIndex = 109;
            this.Label2.Text = "Employee ID";
            // 
            // Panel1
            // 
            this.Panel1.BackColor = System.Drawing.Color.Transparent;
            this.Panel1.Controls.Add(this.Lable1);
            this.Panel1.ForeColor = System.Drawing.Color.White;
            this.Panel1.Location = new System.Drawing.Point(1, 0);
            this.Panel1.Name = "Panel1";
            this.Panel1.Size = new System.Drawing.Size(1161, 100);
            this.Panel1.TabIndex = 98;
            // 
            // Lable1
            // 
            this.Lable1.AutoSize = true;
            this.Lable1.Font = new System.Drawing.Font("Verdana", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lable1.ForeColor = System.Drawing.Color.Black;
            this.Lable1.Location = new System.Drawing.Point(444, 28);
            this.Lable1.Name = "Lable1";
            this.Lable1.Size = new System.Drawing.Size(443, 42);
            this.Lable1.TabIndex = 17;
            this.Lable1.Text = "Add Employee Details";
            // 
            // Btn_clear
            // 
            this.Btn_clear.BackColor = System.Drawing.Color.Lavender;
            this.Btn_clear.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn_clear.Enabled = false;
            this.Btn_clear.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.Btn_clear.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_clear.ForeColor = System.Drawing.Color.Black;
            this.Btn_clear.Location = new System.Drawing.Point(532, 477);
            this.Btn_clear.Name = "Btn_clear";
            this.Btn_clear.Size = new System.Drawing.Size(143, 42);
            this.Btn_clear.TabIndex = 108;
            this.Btn_clear.Text = "Clear";
            this.Btn_clear.UseVisualStyleBackColor = false;
            this.Btn_clear.Click += new System.EventHandler(this.Btn_clear_Click);
            // 
            // Btn_save
            // 
            this.Btn_save.BackColor = System.Drawing.Color.Lavender;
            this.Btn_save.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn_save.Enabled = false;
            this.Btn_save.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.Btn_save.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_save.ForeColor = System.Drawing.Color.Black;
            this.Btn_save.Location = new System.Drawing.Point(229, 477);
            this.Btn_save.Name = "Btn_save";
            this.Btn_save.Size = new System.Drawing.Size(143, 42);
            this.Btn_save.TabIndex = 107;
            this.Btn_save.Text = "Save";
            this.Btn_save.UseVisualStyleBackColor = false;
            this.Btn_save.Click += new System.EventHandler(this.Btn_save_Click);
            // 
            // Frm_Add_Employee_Detail
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1163, 542);
            this.Controls.Add(this.Btn_exit);
            this.Controls.Add(this.Emp_Salary_TB);
            this.Controls.Add(this.Label8);
            this.Controls.Add(this.Email_ID_TB);
            this.Controls.Add(this.Label7);
            this.Controls.Add(this.PAN_No_TB);
            this.Controls.Add(this.Label1);
            this.Controls.Add(this.Adhar_TB);
            this.Controls.Add(this.Label6);
            this.Controls.Add(this.Emp_Add_TB);
            this.Controls.Add(this.Mob_No_TB);
            this.Controls.Add(this.Emp_Name_TB);
            this.Controls.Add(this.Label5);
            this.Controls.Add(this.Label4);
            this.Controls.Add(this.Label3);
            this.Controls.Add(this.Emp_Id_TB);
            this.Controls.Add(this.Label2);
            this.Controls.Add(this.Panel1);
            this.Controls.Add(this.Btn_clear);
            this.Controls.Add(this.Btn_save);
            this.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.Black;
            this.Name = "Frm_Add_Employee_Detail";
            this.Text = "Frm_Add_Employee_Detail";
            this.Load += new System.EventHandler(this.Frm_Add_Employee_Detail_Load);
            this.Leave += new System.EventHandler(this.Frm_Add_Employee_Detail_Leave);
            this.Panel1.ResumeLayout(false);
            this.Panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.Button Btn_exit;
        internal System.Windows.Forms.TextBox Emp_Salary_TB;
        internal System.Windows.Forms.Label Label8;
        internal System.Windows.Forms.TextBox Email_ID_TB;
        internal System.Windows.Forms.Label Label7;
        internal System.Windows.Forms.TextBox PAN_No_TB;
        internal System.Windows.Forms.Label Label1;
        internal System.Windows.Forms.TextBox Adhar_TB;
        internal System.Windows.Forms.Label Label6;
        internal System.Windows.Forms.TextBox Emp_Add_TB;
        internal System.Windows.Forms.TextBox Mob_No_TB;
        internal System.Windows.Forms.TextBox Emp_Name_TB;
        internal System.Windows.Forms.Label Label5;
        internal System.Windows.Forms.Label Label4;
        internal System.Windows.Forms.Label Label3;
        internal System.Windows.Forms.TextBox Emp_Id_TB;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.Panel Panel1;
        internal System.Windows.Forms.Label Lable1;
        internal System.Windows.Forms.Button Btn_clear;
        internal System.Windows.Forms.Button Btn_save;
    }
}