﻿namespace Electronic_Shop_Management_CSharp
{
    partial class Frm_Stock_Added_Detail
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Label2 = new System.Windows.Forms.Label();
            this.Btn_search = new System.Windows.Forms.Button();
            this.System_Date_DTP = new System.Windows.Forms.DateTimePicker();
            this.Panel1 = new System.Windows.Forms.Panel();
            this.Lable1 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Btn_refresh = new System.Windows.Forms.Button();
            this.Panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.BackColor = System.Drawing.Color.Transparent;
            this.Label2.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label2.Location = new System.Drawing.Point(22, 132);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(62, 25);
            this.Label2.TabIndex = 103;
            this.Label2.Text = "Date";
            // 
            // Btn_search
            // 
            this.Btn_search.BackColor = System.Drawing.Color.DimGray;
            this.Btn_search.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn_search.Enabled = false;
            this.Btn_search.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.Btn_search.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_search.ForeColor = System.Drawing.Color.White;
            this.Btn_search.Location = new System.Drawing.Point(428, 125);
            this.Btn_search.Name = "Btn_search";
            this.Btn_search.Size = new System.Drawing.Size(123, 39);
            this.Btn_search.TabIndex = 102;
            this.Btn_search.Text = "Search";
            this.Btn_search.UseVisualStyleBackColor = false;
            this.Btn_search.Click += new System.EventHandler(this.Btn_search_Click);
            // 
            // System_Date_DTP
            // 
            this.System_Date_DTP.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.System_Date_DTP.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.System_Date_DTP.Location = new System.Drawing.Point(135, 132);
            this.System_Date_DTP.Name = "System_Date_DTP";
            this.System_Date_DTP.Size = new System.Drawing.Size(212, 26);
            this.System_Date_DTP.TabIndex = 101;
            this.System_Date_DTP.ValueChanged += new System.EventHandler(this.System_Date_DTP_ValueChanged);
            // 
            // Panel1
            // 
            this.Panel1.BackColor = System.Drawing.Color.White;
            this.Panel1.Controls.Add(this.Lable1);
            this.Panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.Panel1.Location = new System.Drawing.Point(0, 0);
            this.Panel1.Name = "Panel1";
            this.Panel1.Size = new System.Drawing.Size(1351, 99);
            this.Panel1.TabIndex = 100;
            // 
            // Lable1
            // 
            this.Lable1.AutoSize = true;
            this.Lable1.Font = new System.Drawing.Font("Verdana", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lable1.Location = new System.Drawing.Point(456, 28);
            this.Lable1.Name = "Lable1";
            this.Lable1.Size = new System.Drawing.Size(439, 45);
            this.Lable1.TabIndex = 16;
            this.Lable1.Text = "Stock Added Details";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(0, 191);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(1351, 359);
            this.dataGridView1.TabIndex = 104;
            // 
            // Btn_refresh
            // 
            this.Btn_refresh.BackColor = System.Drawing.Color.DimGray;
            this.Btn_refresh.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn_refresh.Enabled = false;
            this.Btn_refresh.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.Btn_refresh.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_refresh.ForeColor = System.Drawing.Color.White;
            this.Btn_refresh.Location = new System.Drawing.Point(595, 125);
            this.Btn_refresh.Name = "Btn_refresh";
            this.Btn_refresh.Size = new System.Drawing.Size(123, 39);
            this.Btn_refresh.TabIndex = 105;
            this.Btn_refresh.Text = "Refresh";
            this.Btn_refresh.UseVisualStyleBackColor = false;
            this.Btn_refresh.Click += new System.EventHandler(this.Btn_refresh_Click);
            // 
            // Frm_Stock_Added_Detail
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1351, 551);
            this.Controls.Add(this.Btn_refresh);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.Label2);
            this.Controls.Add(this.Btn_search);
            this.Controls.Add(this.System_Date_DTP);
            this.Controls.Add(this.Panel1);
            this.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "Frm_Stock_Added_Detail";
            this.Text = "Frm_Stock_Added_Detail";
            this.Load += new System.EventHandler(this.Frm_Stock_Added_Detail_Load);
            this.Panel1.ResumeLayout(false);
            this.Panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.Button Btn_search;
        internal System.Windows.Forms.DateTimePicker System_Date_DTP;
        internal System.Windows.Forms.Label Lable1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Panel Panel1;
        internal System.Windows.Forms.Button Btn_refresh;
    }
}