﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Electronic_Shop_Management_CSharp
{
    public partial class Frm_Update_Dealer : Form
    {
        SqlConnection Con = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=Electronic_Shop_Management_DB;Integrated Security=True");
        SqlCommand Cmd = new SqlCommand();
        SqlDataReader dr;
        string str;

        public void Connection_Open()
        {
            if (Con.State == ConnectionState.Closed)
            {
                Con.Open();
            }
        }

        public void Connection_Close()
        {
            if (Con.State == ConnectionState.Open)
            {
                Con.Close();
            }
        }

        public void Clear_Controls()
        {
            Dealer_ID_TB.Text = "";
            Dealer_Name_TB.Text = "";
            Address_TB.Text = "";
            Mob_No_TB.Text = "";
            Adhar_No_TB.Text = "";
            PAN_No_TB.Text = "";
            Email_ID_TB.Text = "";
        }

        public Frm_Update_Dealer()
        {
            InitializeComponent();
        }

        private void Btn_fetch_Click(object sender, EventArgs e)
        {
            Connection_Open();
            if (Dealer_ID_TB.Text != "")
            {
                Cmd.CommandText = "SELECT * FROM Dealer_Detail_Table WHERE Dealer_ID=" + Dealer_ID_TB.Text + "";
                Cmd.Connection = Con;
                dr = Cmd.ExecuteReader();
                if (dr.Read())
                {
                    Dealer_Name_TB.Text = dr["Dealer_Name"].ToString();
                    Address_TB.Text = dr["Dealer_Name"].ToString();
                    Mob_No_TB.Text = dr["Mob_No"].ToString();
                    Adhar_No_TB.Text = dr["Adhar_No"].ToString();
                    PAN_No_TB.Text = dr["Pancard_No"].ToString();
                    Email_ID_TB.Text = dr["Email_ID"].ToString();
                }
                else
                {
                    MessageBox.Show("There is error while retriving information!!");
                }
            }
            else
            {
                MessageBox.Show("Please first enter Dealer ID!!");
            }
            Connection_Close();
            Btn_delete.Enabled = true;
            Btn_update.Enabled = true;
            Btn_clear.Enabled = true;
        }

        private void Btn_delete_Click(object sender, EventArgs e)
        {
            Connection_Open();

            Cmd.CommandText = "DELETE FROM Dealer_Detail_Table WHERE Dealer_Id=" + Dealer_ID_TB.Text + "";
            Cmd.Connection = Con;
            str =Convert.ToString(Cmd.ExecuteNonQuery());
            if (str != null)
            {
                MessageBox.Show("Record Deleted Successfully!!");
                Clear_Controls();
            }
            else
            {
                MessageBox.Show("There is error while deleting record!!");
            }
            Connection_Close();
            Btn_delete.Enabled = false;
            Btn_update.Enabled = false;
            Btn_clear.Enabled = false;
            Btn_fetch.Enabled = false;
        }

        private void Btn_update_Click(object sender, EventArgs e)
        {
            Connection_Open();
            string date = System.DateTime.Now.ToString();
            if (Dealer_ID_TB.Text != "" && Dealer_Name_TB.Text != "" && Address_TB.Text != "" && Mob_No_TB.Text != "" && Adhar_No_TB.Text != "" && PAN_No_TB.Text != "" && Email_ID_TB.Text != "")
            {
                if (Dealer_Name_TB.Modified == true || Address_TB.Modified == true || Mob_No_TB.Modified == true || Email_ID_TB.Modified == true)
                {
                    Cmd.CommandText = "UPDATE Dealer_Detail_Table SET Dealer_Name='" + Dealer_Name_TB.Text + "',Address='" + Address_TB.Text + "',Mob_No=" + Mob_No_TB.Text + ",Email_ID='" + Email_ID_TB.Text + "',Update_Date='" + date + "' WHERE Dealer_ID="+ Dealer_ID_TB.Text +"";
                    Cmd.Connection = Con;
                    str = Convert.ToString(Cmd.ExecuteNonQuery());
                    if (str != null)
                    {
                        MessageBox.Show("Record updated successfully!!");
                        Clear_Controls();
                    }
                    else
                    {
                        MessageBox.Show("There is error while updating record!!");
                    }
                }
                else
                {
                    MessageBox.Show("Please update at least one field!!");
                }
            }
            else
            {
                MessageBox.Show("First fill all the fields!!");
            }
            Connection_Close();
            Btn_delete.Enabled = false;
            Btn_update.Enabled = false;
            Btn_clear.Enabled = false;
            Btn_fetch.Enabled = false;
        }

        private void Btn_clear_Click(object sender, EventArgs e)
        {
            Clear_Controls();
            Btn_delete.Enabled = false;
            Btn_clear.Enabled = false;
            Btn_update.Enabled = false;
            Btn_fetch.Enabled = false;
        }

        private void btn_exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Frm_Update_Dealer_Leave(object sender, EventArgs e)
        {
            Clear_Controls();
        }

        private void Dealer_ID_TB_TextChanged(object sender, EventArgs e)
        {
            Btn_fetch.Enabled = true;
        }

    }
}
