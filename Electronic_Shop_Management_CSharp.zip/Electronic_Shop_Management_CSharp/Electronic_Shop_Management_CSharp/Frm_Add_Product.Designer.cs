﻿namespace Electronic_Shop_Management_CSharp
{
    partial class Frm_Add_Product
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Product_Quantity_TB = new System.Windows.Forms.TextBox();
            this.Label10 = new System.Windows.Forms.Label();
            this.Brand_CMB = new System.Windows.Forms.ComboBox();
            this.Description_TB = new System.Windows.Forms.TextBox();
            this.Label8 = new System.Windows.Forms.Label();
            this.Sale_Rate_TB = new System.Windows.Forms.TextBox();
            this.Dealer_Rate_TB = new System.Windows.Forms.TextBox();
            this.Label1 = new System.Windows.Forms.Label();
            this.Label7 = new System.Windows.Forms.Label();
            this.Btn_clear = new System.Windows.Forms.Button();
            this.CGST_TB = new System.Windows.Forms.TextBox();
            this.Label9 = new System.Windows.Forms.Label();
            this.Product_Name_TB = new System.Windows.Forms.TextBox();
            this.Label5 = new System.Windows.Forms.Label();
            this.Label4 = new System.Windows.Forms.Label();
            this.Label3 = new System.Windows.Forms.Label();
            this.GroupBox1 = new System.Windows.Forms.GroupBox();
            this.Dealer_Name_CMB = new System.Windows.Forms.ComboBox();
            this.DateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.Label11 = new System.Windows.Forms.Label();
            this.btn_exit = new System.Windows.Forms.Button();
            this.Panel1 = new System.Windows.Forms.Panel();
            this.Lable1 = new System.Windows.Forms.Label();
            this.Btn_save = new System.Windows.Forms.Button();
            this.Product_ID_TB = new System.Windows.Forms.TextBox();
            this.Label2 = new System.Windows.Forms.Label();
            this.SGST_TB = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.GroupBox1.SuspendLayout();
            this.Panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // Product_Quantity_TB
            // 
            this.Product_Quantity_TB.BackColor = System.Drawing.Color.White;
            this.Product_Quantity_TB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Product_Quantity_TB.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Product_Quantity_TB.Location = new System.Drawing.Point(854, 255);
            this.Product_Quantity_TB.Name = "Product_Quantity_TB";
            this.Product_Quantity_TB.Size = new System.Drawing.Size(217, 31);
            this.Product_Quantity_TB.TabIndex = 46;
            // 
            // Label10
            // 
            this.Label10.AutoSize = true;
            this.Label10.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label10.ForeColor = System.Drawing.Color.Black;
            this.Label10.Location = new System.Drawing.Point(600, 261);
            this.Label10.Name = "Label10";
            this.Label10.Size = new System.Drawing.Size(170, 23);
            this.Label10.TabIndex = 53;
            this.Label10.Text = "Product Quantity";
            // 
            // Brand_CMB
            // 
            this.Brand_CMB.BackColor = System.Drawing.Color.White;
            this.Brand_CMB.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.Brand_CMB.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Brand_CMB.ForeColor = System.Drawing.SystemColors.WindowText;
            this.Brand_CMB.FormattingEnabled = true;
            this.Brand_CMB.Items.AddRange(new object[] {
            "SAMSUNG",
            "SONY"});
            this.Brand_CMB.Location = new System.Drawing.Point(273, 142);
            this.Brand_CMB.Name = "Brand_CMB";
            this.Brand_CMB.Size = new System.Drawing.Size(217, 31);
            this.Brand_CMB.TabIndex = 39;
            this.Brand_CMB.Text = "Select Brand";
            // 
            // Description_TB
            // 
            this.Description_TB.BackColor = System.Drawing.Color.White;
            this.Description_TB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Description_TB.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Description_TB.ForeColor = System.Drawing.SystemColors.WindowText;
            this.Description_TB.Location = new System.Drawing.Point(273, 197);
            this.Description_TB.Name = "Description_TB";
            this.Description_TB.Size = new System.Drawing.Size(217, 31);
            this.Description_TB.TabIndex = 40;
            // 
            // Label8
            // 
            this.Label8.AutoSize = true;
            this.Label8.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label8.ForeColor = System.Drawing.Color.Black;
            this.Label8.Location = new System.Drawing.Point(22, 197);
            this.Label8.Name = "Label8";
            this.Label8.Size = new System.Drawing.Size(119, 23);
            this.Label8.TabIndex = 52;
            this.Label8.Text = "Description";
            // 
            // Sale_Rate_TB
            // 
            this.Sale_Rate_TB.BackColor = System.Drawing.Color.White;
            this.Sale_Rate_TB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Sale_Rate_TB.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Sale_Rate_TB.Location = new System.Drawing.Point(854, 199);
            this.Sale_Rate_TB.Name = "Sale_Rate_TB";
            this.Sale_Rate_TB.Size = new System.Drawing.Size(217, 31);
            this.Sale_Rate_TB.TabIndex = 45;
            // 
            // Dealer_Rate_TB
            // 
            this.Dealer_Rate_TB.BackColor = System.Drawing.Color.White;
            this.Dealer_Rate_TB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Dealer_Rate_TB.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Dealer_Rate_TB.Location = new System.Drawing.Point(854, 139);
            this.Dealer_Rate_TB.Name = "Dealer_Rate_TB";
            this.Dealer_Rate_TB.Size = new System.Drawing.Size(217, 31);
            this.Dealer_Rate_TB.TabIndex = 44;
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label1.ForeColor = System.Drawing.Color.Black;
            this.Label1.Location = new System.Drawing.Point(600, 138);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(121, 23);
            this.Label1.TabIndex = 43;
            this.Label1.Text = "Dealer Rate";
            // 
            // Label7
            // 
            this.Label7.AutoSize = true;
            this.Label7.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label7.ForeColor = System.Drawing.Color.Black;
            this.Label7.Location = new System.Drawing.Point(600, 199);
            this.Label7.Name = "Label7";
            this.Label7.Size = new System.Drawing.Size(100, 23);
            this.Label7.TabIndex = 51;
            this.Label7.Text = "Sale Rate";
            // 
            // Btn_clear
            // 
            this.Btn_clear.BackColor = System.Drawing.Color.DimGray;
            this.Btn_clear.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn_clear.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.Btn_clear.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_clear.ForeColor = System.Drawing.Color.LightGray;
            this.Btn_clear.Location = new System.Drawing.Point(546, 461);
            this.Btn_clear.Name = "Btn_clear";
            this.Btn_clear.Size = new System.Drawing.Size(115, 42);
            this.Btn_clear.TabIndex = 43;
            this.Btn_clear.Text = "Clear";
            this.Btn_clear.UseVisualStyleBackColor = false;
            this.Btn_clear.Click += new System.EventHandler(this.Btn_clear_Click);
            // 
            // CGST_TB
            // 
            this.CGST_TB.BackColor = System.Drawing.Color.White;
            this.CGST_TB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.CGST_TB.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CGST_TB.Location = new System.Drawing.Point(854, 23);
            this.CGST_TB.Name = "CGST_TB";
            this.CGST_TB.Size = new System.Drawing.Size(217, 31);
            this.CGST_TB.TabIndex = 42;
            // 
            // Label9
            // 
            this.Label9.AutoSize = true;
            this.Label9.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label9.ForeColor = System.Drawing.Color.Black;
            this.Label9.Location = new System.Drawing.Point(600, 25);
            this.Label9.Name = "Label9";
            this.Label9.Size = new System.Drawing.Size(90, 23);
            this.Label9.TabIndex = 50;
            this.Label9.Text = "CGST %";
            // 
            // Product_Name_TB
            // 
            this.Product_Name_TB.BackColor = System.Drawing.Color.White;
            this.Product_Name_TB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Product_Name_TB.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Product_Name_TB.ForeColor = System.Drawing.SystemColors.WindowText;
            this.Product_Name_TB.Location = new System.Drawing.Point(273, 82);
            this.Product_Name_TB.Name = "Product_Name_TB";
            this.Product_Name_TB.Size = new System.Drawing.Size(217, 31);
            this.Product_Name_TB.TabIndex = 38;
            // 
            // Label5
            // 
            this.Label5.AutoSize = true;
            this.Label5.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label5.ForeColor = System.Drawing.Color.Black;
            this.Label5.Location = new System.Drawing.Point(22, 82);
            this.Label5.Name = "Label5";
            this.Label5.Size = new System.Drawing.Size(143, 23);
            this.Label5.TabIndex = 49;
            this.Label5.Text = "Product Name";
            // 
            // Label4
            // 
            this.Label4.AutoSize = true;
            this.Label4.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label4.ForeColor = System.Drawing.Color.Black;
            this.Label4.Location = new System.Drawing.Point(22, 142);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(66, 23);
            this.Label4.TabIndex = 48;
            this.Label4.Text = "Brand";
            // 
            // Label3
            // 
            this.Label3.AutoSize = true;
            this.Label3.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label3.ForeColor = System.Drawing.Color.Black;
            this.Label3.Location = new System.Drawing.Point(22, 263);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(133, 23);
            this.Label3.TabIndex = 47;
            this.Label3.Text = "Dealer Name";
            // 
            // GroupBox1
            // 
            this.GroupBox1.BackColor = System.Drawing.Color.Transparent;
            this.GroupBox1.Controls.Add(this.SGST_TB);
            this.GroupBox1.Controls.Add(this.label6);
            this.GroupBox1.Controls.Add(this.Product_ID_TB);
            this.GroupBox1.Controls.Add(this.Label2);
            this.GroupBox1.Controls.Add(this.Dealer_Name_CMB);
            this.GroupBox1.Controls.Add(this.Product_Quantity_TB);
            this.GroupBox1.Controls.Add(this.Label10);
            this.GroupBox1.Controls.Add(this.Brand_CMB);
            this.GroupBox1.Controls.Add(this.Description_TB);
            this.GroupBox1.Controls.Add(this.Label8);
            this.GroupBox1.Controls.Add(this.Sale_Rate_TB);
            this.GroupBox1.Controls.Add(this.Dealer_Rate_TB);
            this.GroupBox1.Controls.Add(this.Label1);
            this.GroupBox1.Controls.Add(this.Label7);
            this.GroupBox1.Controls.Add(this.CGST_TB);
            this.GroupBox1.Controls.Add(this.Label9);
            this.GroupBox1.Controls.Add(this.Product_Name_TB);
            this.GroupBox1.Controls.Add(this.Label5);
            this.GroupBox1.Controls.Add(this.Label4);
            this.GroupBox1.Controls.Add(this.Label3);
            this.GroupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GroupBox1.Location = new System.Drawing.Point(-1, 118);
            this.GroupBox1.Name = "GroupBox1";
            this.GroupBox1.Size = new System.Drawing.Size(1196, 312);
            this.GroupBox1.TabIndex = 49;
            this.GroupBox1.TabStop = false;
            this.GroupBox1.Text = "Product Details";
            // 
            // Dealer_Name_CMB
            // 
            this.Dealer_Name_CMB.BackColor = System.Drawing.Color.White;
            this.Dealer_Name_CMB.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.Dealer_Name_CMB.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Dealer_Name_CMB.ForeColor = System.Drawing.SystemColors.WindowText;
            this.Dealer_Name_CMB.FormattingEnabled = true;
            this.Dealer_Name_CMB.Location = new System.Drawing.Point(273, 260);
            this.Dealer_Name_CMB.Name = "Dealer_Name_CMB";
            this.Dealer_Name_CMB.Size = new System.Drawing.Size(217, 31);
            this.Dealer_Name_CMB.TabIndex = 54;
            this.Dealer_Name_CMB.Text = "Select Dealer name";
            // 
            // DateTimePicker1
            // 
            this.DateTimePicker1.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.DateTimePicker1.Location = new System.Drawing.Point(1001, 85);
            this.DateTimePicker1.Name = "DateTimePicker1";
            this.DateTimePicker1.Size = new System.Drawing.Size(147, 27);
            this.DateTimePicker1.TabIndex = 48;
            // 
            // Label11
            // 
            this.Label11.AutoSize = true;
            this.Label11.BackColor = System.Drawing.Color.Transparent;
            this.Label11.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label11.ForeColor = System.Drawing.Color.Black;
            this.Label11.Location = new System.Drawing.Point(922, 85);
            this.Label11.Name = "Label11";
            this.Label11.Size = new System.Drawing.Size(54, 23);
            this.Label11.TabIndex = 47;
            this.Label11.Text = "Date";
            // 
            // btn_exit
            // 
            this.btn_exit.BackColor = System.Drawing.Color.DimGray;
            this.btn_exit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_exit.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btn_exit.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_exit.ForeColor = System.Drawing.Color.LightGray;
            this.btn_exit.Location = new System.Drawing.Point(721, 461);
            this.btn_exit.Name = "btn_exit";
            this.btn_exit.Size = new System.Drawing.Size(115, 42);
            this.btn_exit.TabIndex = 44;
            this.btn_exit.Text = "Exit";
            this.btn_exit.UseVisualStyleBackColor = false;
            this.btn_exit.Click += new System.EventHandler(this.btn_exit_Click);
            // 
            // Panel1
            // 
            this.Panel1.BackColor = System.Drawing.Color.Transparent;
            this.Panel1.Controls.Add(this.Lable1);
            this.Panel1.ForeColor = System.Drawing.Color.White;
            this.Panel1.Location = new System.Drawing.Point(0, 1);
            this.Panel1.Name = "Panel1";
            this.Panel1.Size = new System.Drawing.Size(1195, 78);
            this.Panel1.TabIndex = 46;
            // 
            // Lable1
            // 
            this.Lable1.AutoSize = true;
            this.Lable1.Font = new System.Drawing.Font("Verdana", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lable1.ForeColor = System.Drawing.Color.Black;
            this.Lable1.Location = new System.Drawing.Point(380, 15);
            this.Lable1.Name = "Lable1";
            this.Lable1.Size = new System.Drawing.Size(434, 45);
            this.Lable1.TabIndex = 16;
            this.Lable1.Text = "Add Product Details";
            // 
            // Btn_save
            // 
            this.Btn_save.BackColor = System.Drawing.Color.DimGray;
            this.Btn_save.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn_save.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.Btn_save.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_save.ForeColor = System.Drawing.Color.LightGray;
            this.Btn_save.Location = new System.Drawing.Point(357, 461);
            this.Btn_save.Name = "Btn_save";
            this.Btn_save.Size = new System.Drawing.Size(115, 42);
            this.Btn_save.TabIndex = 42;
            this.Btn_save.Text = "Save";
            this.Btn_save.UseVisualStyleBackColor = false;
            this.Btn_save.Click += new System.EventHandler(this.Btn_save_Click);
            // 
            // Product_ID_TB
            // 
            this.Product_ID_TB.BackColor = System.Drawing.Color.White;
            this.Product_ID_TB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Product_ID_TB.Enabled = false;
            this.Product_ID_TB.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Product_ID_TB.Location = new System.Drawing.Point(273, 25);
            this.Product_ID_TB.Name = "Product_ID_TB";
            this.Product_ID_TB.Size = new System.Drawing.Size(217, 31);
            this.Product_ID_TB.TabIndex = 57;
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.BackColor = System.Drawing.Color.Transparent;
            this.Label2.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label2.ForeColor = System.Drawing.Color.Black;
            this.Label2.Location = new System.Drawing.Point(29, 30);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(112, 23);
            this.Label2.TabIndex = 58;
            this.Label2.Text = "Product ID";
            // 
            // SGST_TB
            // 
            this.SGST_TB.BackColor = System.Drawing.Color.White;
            this.SGST_TB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.SGST_TB.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SGST_TB.Location = new System.Drawing.Point(854, 82);
            this.SGST_TB.Name = "SGST_TB";
            this.SGST_TB.Size = new System.Drawing.Size(217, 31);
            this.SGST_TB.TabIndex = 59;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(600, 84);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(90, 23);
            this.label6.TabIndex = 60;
            this.label6.Text = "SGST %";
            // 
            // Frm_Add_Product
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1192, 515);
            this.Controls.Add(this.Btn_clear);
            this.Controls.Add(this.GroupBox1);
            this.Controls.Add(this.DateTimePicker1);
            this.Controls.Add(this.Label11);
            this.Controls.Add(this.btn_exit);
            this.Controls.Add(this.Panel1);
            this.Controls.Add(this.Btn_save);
            this.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.Black;
            this.Name = "Frm_Add_Product";
            this.Text = "Add Product";
            this.Load += new System.EventHandler(this.Frm_Add_Product_Load);
            this.Leave += new System.EventHandler(this.Frm_Add_Product_Leave);
            this.GroupBox1.ResumeLayout(false);
            this.GroupBox1.PerformLayout();
            this.Panel1.ResumeLayout(false);
            this.Panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.TextBox Product_Quantity_TB;
        internal System.Windows.Forms.Label Label10;
        internal System.Windows.Forms.ComboBox Brand_CMB;
        internal System.Windows.Forms.TextBox Description_TB;
        internal System.Windows.Forms.Label Label8;
        internal System.Windows.Forms.TextBox Sale_Rate_TB;
        internal System.Windows.Forms.TextBox Dealer_Rate_TB;
        internal System.Windows.Forms.Label Label1;
        internal System.Windows.Forms.Label Label7;
        internal System.Windows.Forms.Button Btn_clear;
        internal System.Windows.Forms.TextBox CGST_TB;
        internal System.Windows.Forms.Label Label9;
        internal System.Windows.Forms.TextBox Product_Name_TB;
        internal System.Windows.Forms.Label Label5;
        internal System.Windows.Forms.Label Label4;
        internal System.Windows.Forms.Label Label3;
        internal System.Windows.Forms.GroupBox GroupBox1;
        internal System.Windows.Forms.DateTimePicker DateTimePicker1;
        internal System.Windows.Forms.Label Label11;
        internal System.Windows.Forms.Button btn_exit;
        internal System.Windows.Forms.Panel Panel1;
        internal System.Windows.Forms.Label Lable1;
        internal System.Windows.Forms.Button Btn_save;
        internal System.Windows.Forms.ComboBox Dealer_Name_CMB;
        internal System.Windows.Forms.TextBox SGST_TB;
        internal System.Windows.Forms.Label label6;
        internal System.Windows.Forms.TextBox Product_ID_TB;
        internal System.Windows.Forms.Label Label2;
    }
}

