﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;


namespace Electronic_Shop_Management_CSharp
{
    public partial class Frm_Add_New_Dealer : Form
    {
        SqlConnection Con = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=Electronic_Shop_Management_DB;Integrated Security=True");
        SqlCommand Cmd = new SqlCommand();
        String str;
        ConnectionCls cobj = new ConnectionCls();

        public void Connection_Open()
        {
            if (Con.State == ConnectionState.Closed)
            {
                Con.Open();
            }
        }

        public void Connection_Close()
        {
            if (Con.State == ConnectionState.Open)
            {
                Con.Close();
            }
        }

        public void Clear_Controls()
        {
            Dealer_Name_TB.Text = "";
            Address_TB.Text = "";
            Mob_No_TB.Text = "";
            Adhar_No_TB.Text = "";
            PAN_No_TB.Text = "";
            Email_ID_TB.Text = "";
        }
        public Frm_Add_New_Dealer()
        {
            InitializeComponent();
        }

        private void Frm_Add_New_Dealer_Load(object sender, EventArgs e)
        {
            Dealer_ID_TB.Text = Convert.ToString(cobj.Autoincreament("SELECT COUNT(Dealer_Id) FROM Dealer_Detail_Table"));
        }

        private void Btn_save_Click(object sender, EventArgs e)
        {
            string date = System.DateTime.Now.ToString();
            Connection_Open();
            if (Dealer_ID_TB.Text != "" && Dealer_Name_TB.Text != "" && Address_TB.Text != "" && Mob_No_TB.Text != "" && Adhar_No_TB.Text != "" && PAN_No_TB.Text != "" && Email_ID_TB.Text != "")
            {
                Cmd.CommandText = "INSERT INTO Dealer_Detail_Table VALUES (" + Dealer_ID_TB.Text + ",'" + Dealer_Name_TB.Text + "','" + Address_TB.Text + "'," + Mob_No_TB.Text + "," + Adhar_No_TB.Text + ",'" + PAN_No_TB.Text + "','" + Email_ID_TB.Text + "','" + date + "','" + date + "')";
                Cmd.Connection = Con;
                str = Convert.ToString(Cmd.ExecuteNonQuery());
                if (str != null)
                {
                    MessageBox.Show("Record saved successfully!!!");
                    Clear_Controls();
                    Dealer_ID_TB.Text = Convert.ToString(cobj.Autoincreament("SELECT COUNT(Dealer_Id) FROM Dealer_Detail_Table"));
                }
                else
                {
                    MessageBox.Show("Record not saved.");
                }
            }
            else
            {
                MessageBox.Show("Please first fill all the fields!!");
            }
            Connection_Close();
            
        }

        private void Btn_clear_Click(object sender, EventArgs e)
        {
            Clear_Controls();
        }

        private void Btn_exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Frm_Add_New_Dealer_Leave(object sender, EventArgs e)
        {
            Clear_Controls();
        }

        private void Mob_No_TB_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar >= '0' && e.KeyChar <= '9' || e.KeyChar == ' ')
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void Adhar_No_TB_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar >= '0' && e.KeyChar <= '9' || e.KeyChar == ' ')
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void PAN_No_TB_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar >= '0' && e.KeyChar <= '9' || e.KeyChar == ' ')
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

    }
}
