﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;

namespace Electronic_Shop_Management_CSharp
{
    public partial class Frm_Single_Stock_Availability : Form
    {
        SqlConnection Con = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=Electronic_Shop_Management_DB;Integrated Security=True");
        SqlCommand Cmd = new SqlCommand();
        SqlDataReader dr;

        public void Connection_Open()
        {
            if (Con.State == ConnectionState.Closed)
            {
                Con.Open();
            }
        }

        public void Connection_Close()
        {
            if (Con.State == ConnectionState.Open)
            {
                Con.Close();
            }
        }

        public void Clear_Controls()
        {
            Product_ID_TB.Text = "";
            Product_Name_TB.Text = "";
            Brand_TB.Text = "";
            Dealer_Name_TB.Text = "";
            Stock_Available_TB.Text = "";
        }

        public Frm_Single_Stock_Availability()
        {
            InitializeComponent();
        }

        private void Btn_fetch_Click(object sender, EventArgs e)
        {
            Connection_Open();
            if (Product_ID_TB.Text != "")
            {
                Cmd.CommandText = "SELECT * FROM Stock_Detail_Table WHERE Product_ID=" + Product_ID_TB.Text + "";
                Cmd.Connection = Con;
                dr = Cmd.ExecuteReader();
                if (dr.Read())
                {
                    Product_Name_TB.Text = dr["Product_Name"].ToString();
                    Brand_TB.Text = dr["Brand"].ToString();
                    Dealer_Name_TB.Text = dr["Dealer_Name"].ToString();
                    Stock_Available_TB.Text = dr["Stock_Available"].ToString();
                }
                else
                {
                    MessageBox.Show("There is error while retriving information!!");
                }
            }
            else
            {
                MessageBox.Show("First enter Product ID!!");
            }
            Btn_clear.Enabled = true;
        }

        private void Btn_clear_Click(object sender, EventArgs e)
        {
            Clear_Controls();
        }

        private void Btn_exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Product_ID_TB_TextChanged(object sender, EventArgs e)
        {
            Btn_fetch.Enabled = true;
        }
    }
}
