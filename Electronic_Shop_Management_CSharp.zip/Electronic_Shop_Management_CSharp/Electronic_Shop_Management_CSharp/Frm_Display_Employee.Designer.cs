﻿namespace Electronic_Shop_Management_CSharp
{
    partial class Frm_Display_Employee
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Btn_Refresh = new System.Windows.Forms.Button();
            this.Search_CMB = new System.Windows.Forms.ComboBox();
            this.Btn_search = new System.Windows.Forms.Button();
            this.Value_TB = new System.Windows.Forms.TextBox();
            this.Label2 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.Lable1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(0, 215);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(1063, 332);
            this.dataGridView1.TabIndex = 19;
            // 
            // Btn_Refresh
            // 
            this.Btn_Refresh.BackColor = System.Drawing.Color.DimGray;
            this.Btn_Refresh.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn_Refresh.Enabled = false;
            this.Btn_Refresh.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.Btn_Refresh.Font = new System.Drawing.Font("Verdana", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_Refresh.ForeColor = System.Drawing.Color.White;
            this.Btn_Refresh.Location = new System.Drawing.Point(872, 150);
            this.Btn_Refresh.Name = "Btn_Refresh";
            this.Btn_Refresh.Size = new System.Drawing.Size(154, 46);
            this.Btn_Refresh.TabIndex = 126;
            this.Btn_Refresh.Text = "Refresh";
            this.Btn_Refresh.UseVisualStyleBackColor = false;
            this.Btn_Refresh.Click += new System.EventHandler(this.Btn_Refresh_Click);
            // 
            // Search_CMB
            // 
            this.Search_CMB.BackColor = System.Drawing.Color.White;
            this.Search_CMB.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Search_CMB.FormattingEnabled = true;
            this.Search_CMB.Items.AddRange(new object[] {
            "Dealer ID",
            "Dealer Name"});
            this.Search_CMB.Location = new System.Drawing.Point(181, 161);
            this.Search_CMB.Name = "Search_CMB";
            this.Search_CMB.Size = new System.Drawing.Size(206, 32);
            this.Search_CMB.TabIndex = 125;
            this.Search_CMB.SelectedIndexChanged += new System.EventHandler(this.Search_CMB_SelectedIndexChanged);
            // 
            // Btn_search
            // 
            this.Btn_search.BackColor = System.Drawing.Color.DimGray;
            this.Btn_search.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn_search.Enabled = false;
            this.Btn_search.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.Btn_search.Font = new System.Drawing.Font("Verdana", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_search.ForeColor = System.Drawing.Color.White;
            this.Btn_search.Location = new System.Drawing.Point(683, 151);
            this.Btn_search.Name = "Btn_search";
            this.Btn_search.Size = new System.Drawing.Size(154, 46);
            this.Btn_search.TabIndex = 123;
            this.Btn_search.Text = "Search";
            this.Btn_search.UseVisualStyleBackColor = false;
            this.Btn_search.Click += new System.EventHandler(this.Btn_search_Click);
            // 
            // Value_TB
            // 
            this.Value_TB.BackColor = System.Drawing.Color.White;
            this.Value_TB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Value_TB.Enabled = false;
            this.Value_TB.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Value_TB.Location = new System.Drawing.Point(416, 160);
            this.Value_TB.Name = "Value_TB";
            this.Value_TB.Size = new System.Drawing.Size(190, 33);
            this.Value_TB.TabIndex = 122;
            this.Value_TB.TextChanged += new System.EventHandler(this.Value_TB_TextChanged);
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.BackColor = System.Drawing.Color.Transparent;
            this.Label2.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label2.ForeColor = System.Drawing.Color.Black;
            this.Label2.Location = new System.Drawing.Point(13, 161);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(118, 25);
            this.Label2.TabIndex = 124;
            this.Label2.Text = "Search By";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.Lable1);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1063, 100);
            this.panel1.TabIndex = 127;
            // 
            // Lable1
            // 
            this.Lable1.AutoSize = true;
            this.Lable1.Font = new System.Drawing.Font("Verdana", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lable1.Location = new System.Drawing.Point(303, 28);
            this.Lable1.Name = "Lable1";
            this.Lable1.Size = new System.Drawing.Size(457, 45);
            this.Lable1.TabIndex = 19;
            this.Lable1.Text = "Display All Employee";
            // 
            // Frm_Display_Employee
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1065, 549);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.Btn_Refresh);
            this.Controls.Add(this.Search_CMB);
            this.Controls.Add(this.Btn_search);
            this.Controls.Add(this.Value_TB);
            this.Controls.Add(this.Label2);
            this.Controls.Add(this.dataGridView1);
            this.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "Frm_Display_Employee";
            this.Text = "Frm_Display_Employee";
            this.Load += new System.EventHandler(this.Frm_Display_Employee_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        internal System.Windows.Forms.Button Btn_Refresh;
        internal System.Windows.Forms.ComboBox Search_CMB;
        internal System.Windows.Forms.Button Btn_search;
        internal System.Windows.Forms.TextBox Value_TB;
        internal System.Windows.Forms.Label Label2;
        private System.Windows.Forms.Panel panel1;
        internal System.Windows.Forms.Label Lable1;
    }
}