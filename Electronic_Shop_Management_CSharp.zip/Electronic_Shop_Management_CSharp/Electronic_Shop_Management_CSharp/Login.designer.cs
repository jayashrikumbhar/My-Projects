﻿namespace Banking_Application_in_CSharp
{
    partial class Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Login));
            this.Label1 = new System.Windows.Forms.Label();
            this.TB_UN_Name = new System.Windows.Forms.TextBox();
            this.Login_Btn = new System.Windows.Forms.Button();
            this.TB_Pass = new System.Windows.Forms.TextBox();
            this.Label5 = new System.Windows.Forms.Label();
            this.Label6 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Font = new System.Drawing.Font("Times New Roman", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.Label1.Location = new System.Drawing.Point(171, 65);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(95, 36);
            this.Label1.TabIndex = 29;
            this.Label1.Text = "Login";
            this.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // TB_UN_Name
            // 
            this.TB_UN_Name.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TB_UN_Name.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TB_UN_Name.Location = new System.Drawing.Point(253, 164);
            this.TB_UN_Name.MaxLength = 20;
            this.TB_UN_Name.Name = "TB_UN_Name";
            this.TB_UN_Name.Size = new System.Drawing.Size(189, 26);
            this.TB_UN_Name.TabIndex = 24;
            this.TB_UN_Name.TextChanged += new System.EventHandler(this.TB_UN_Name_TextChanged);
            // 
            // Login_Btn
            // 
            this.Login_Btn.BackColor = System.Drawing.Color.PapayaWhip;
            this.Login_Btn.Enabled = false;
            this.Login_Btn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.Login_Btn.FlatAppearance.BorderSize = 3;
            this.Login_Btn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Login_Btn.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Login_Btn.Location = new System.Drawing.Point(177, 332);
            this.Login_Btn.Name = "Login_Btn";
            this.Login_Btn.Size = new System.Drawing.Size(99, 38);
            this.Login_Btn.TabIndex = 26;
            this.Login_Btn.Text = "Login";
            this.Login_Btn.UseVisualStyleBackColor = false;
            this.Login_Btn.Click += new System.EventHandler(this.Login_Btn_Click);
            // 
            // TB_Pass
            // 
            this.TB_Pass.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TB_Pass.Enabled = false;
            this.TB_Pass.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TB_Pass.Location = new System.Drawing.Point(253, 242);
            this.TB_Pass.MaxLength = 8;
            this.TB_Pass.Name = "TB_Pass";
            this.TB_Pass.PasswordChar = '*';
            this.TB_Pass.Size = new System.Drawing.Size(189, 26);
            this.TB_Pass.TabIndex = 25;
            this.TB_Pass.UseSystemPasswordChar = true;
            this.TB_Pass.TextChanged += new System.EventHandler(this.TB_Pass_TextChanged);
            // 
            // Label5
            // 
            this.Label5.AutoSize = true;
            this.Label5.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label5.Location = new System.Drawing.Point(80, 239);
            this.Label5.Name = "Label5";
            this.Label5.Size = new System.Drawing.Size(104, 27);
            this.Label5.TabIndex = 28;
            this.Label5.Text = "Password";
            // 
            // Label6
            // 
            this.Label6.AutoSize = true;
            this.Label6.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label6.Location = new System.Drawing.Point(80, 160);
            this.Label6.Name = "Label6";
            this.Label6.Size = new System.Drawing.Size(108, 27);
            this.Label6.TabIndex = 27;
            this.Label6.Text = "Username";
            // 
            // Login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(491, 452);
            this.Controls.Add(this.Label1);
            this.Controls.Add(this.TB_UN_Name);
            this.Controls.Add(this.Login_Btn);
            this.Controls.Add(this.TB_Pass);
            this.Controls.Add(this.Label5);
            this.Controls.Add(this.Label6);
            this.Font = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Login";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Login";
            //this.Load += new System.EventHandler(this.Login_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.Label Label1;
        internal System.Windows.Forms.TextBox TB_UN_Name;
        internal System.Windows.Forms.Button Login_Btn;
        internal System.Windows.Forms.TextBox TB_Pass;
        internal System.Windows.Forms.Label Label5;
        internal System.Windows.Forms.Label Label6;
    }
}