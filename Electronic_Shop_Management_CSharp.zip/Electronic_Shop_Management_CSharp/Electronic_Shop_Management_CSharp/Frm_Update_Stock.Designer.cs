﻿namespace Electronic_Shop_Management_CSharp
{
    partial class Frm_Update_Stock
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Btn_exit = new System.Windows.Forms.Button();
            this.Btn_fetch = new System.Windows.Forms.Button();
            this.Product_ID_TB = new System.Windows.Forms.TextBox();
            this.Label2 = new System.Windows.Forms.Label();
            this.Panel1 = new System.Windows.Forms.Panel();
            this.Lable1 = new System.Windows.Forms.Label();
            this.Btn_clear = new System.Windows.Forms.Button();
            this.Btn_save = new System.Windows.Forms.Button();
            this.Add_Stock_TB = new System.Windows.Forms.TextBox();
            this.Label1 = new System.Windows.Forms.Label();
            this.Stock_Available_TB = new System.Windows.Forms.TextBox();
            this.Label6 = new System.Windows.Forms.Label();
            this.Brand_TB = new System.Windows.Forms.TextBox();
            this.Dealer_Name_TB = new System.Windows.Forms.TextBox();
            this.Label4 = new System.Windows.Forms.Label();
            this.Label3 = new System.Windows.Forms.Label();
            this.Product_Name_TB = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.Panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // Btn_exit
            // 
            this.Btn_exit.BackColor = System.Drawing.Color.DimGray;
            this.Btn_exit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn_exit.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.Btn_exit.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_exit.ForeColor = System.Drawing.Color.White;
            this.Btn_exit.Location = new System.Drawing.Point(802, 555);
            this.Btn_exit.Name = "Btn_exit";
            this.Btn_exit.Size = new System.Drawing.Size(143, 42);
            this.Btn_exit.TabIndex = 6;
            this.Btn_exit.Text = "Exit";
            this.Btn_exit.UseVisualStyleBackColor = false;
            this.Btn_exit.Click += new System.EventHandler(this.Btn_exit_Click);
            // 
            // Btn_fetch
            // 
            this.Btn_fetch.BackColor = System.Drawing.Color.DimGray;
            this.Btn_fetch.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn_fetch.Enabled = false;
            this.Btn_fetch.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.Btn_fetch.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_fetch.ForeColor = System.Drawing.Color.White;
            this.Btn_fetch.Location = new System.Drawing.Point(915, 133);
            this.Btn_fetch.Name = "Btn_fetch";
            this.Btn_fetch.Size = new System.Drawing.Size(138, 39);
            this.Btn_fetch.TabIndex = 2;
            this.Btn_fetch.Text = "Fetch";
            this.Btn_fetch.UseVisualStyleBackColor = false;
            this.Btn_fetch.Click += new System.EventHandler(this.Btn_fetch_Click);
            // 
            // Product_ID_TB
            // 
            this.Product_ID_TB.BackColor = System.Drawing.Color.White;
            this.Product_ID_TB.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Product_ID_TB.Location = new System.Drawing.Point(529, 137);
            this.Product_ID_TB.Name = "Product_ID_TB";
            this.Product_ID_TB.Size = new System.Drawing.Size(350, 33);
            this.Product_ID_TB.TabIndex = 1;
            this.Product_ID_TB.TextChanged += new System.EventHandler(this.Product_ID_TB_TextChanged);
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.BackColor = System.Drawing.Color.Transparent;
            this.Label2.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label2.Location = new System.Drawing.Point(180, 140);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(120, 25);
            this.Label2.TabIndex = 132;
            this.Label2.Text = "Product Id";
            // 
            // Panel1
            // 
            this.Panel1.BackColor = System.Drawing.Color.Transparent;
            this.Panel1.Controls.Add(this.Lable1);
            this.Panel1.Location = new System.Drawing.Point(-3, 1);
            this.Panel1.Name = "Panel1";
            this.Panel1.Size = new System.Drawing.Size(1126, 100);
            this.Panel1.TabIndex = 131;
            // 
            // Lable1
            // 
            this.Lable1.AutoSize = true;
            this.Lable1.BackColor = System.Drawing.Color.Transparent;
            this.Lable1.Font = new System.Drawing.Font("Verdana", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lable1.ForeColor = System.Drawing.Color.Black;
            this.Lable1.Location = new System.Drawing.Point(408, 28);
            this.Lable1.Name = "Lable1";
            this.Lable1.Size = new System.Drawing.Size(310, 45);
            this.Lable1.TabIndex = 40;
            this.Lable1.Text = " Update Stock";
            // 
            // Btn_clear
            // 
            this.Btn_clear.BackColor = System.Drawing.Color.DimGray;
            this.Btn_clear.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn_clear.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.Btn_clear.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_clear.ForeColor = System.Drawing.Color.White;
            this.Btn_clear.Location = new System.Drawing.Point(542, 555);
            this.Btn_clear.Name = "Btn_clear";
            this.Btn_clear.Size = new System.Drawing.Size(157, 41);
            this.Btn_clear.TabIndex = 5;
            this.Btn_clear.Text = "Clear";
            this.Btn_clear.UseVisualStyleBackColor = false;
            this.Btn_clear.Click += new System.EventHandler(this.Btn_clear_Click);
            // 
            // Btn_save
            // 
            this.Btn_save.BackColor = System.Drawing.Color.DimGray;
            this.Btn_save.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn_save.Enabled = false;
            this.Btn_save.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.Btn_save.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_save.ForeColor = System.Drawing.Color.White;
            this.Btn_save.Location = new System.Drawing.Point(272, 554);
            this.Btn_save.Name = "Btn_save";
            this.Btn_save.Size = new System.Drawing.Size(143, 42);
            this.Btn_save.TabIndex = 4;
            this.Btn_save.Text = "Save";
            this.Btn_save.UseVisualStyleBackColor = false;
            this.Btn_save.Click += new System.EventHandler(this.Btn_save_Click);
            // 
            // Add_Stock_TB
            // 
            this.Add_Stock_TB.BackColor = System.Drawing.Color.White;
            this.Add_Stock_TB.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Add_Stock_TB.Location = new System.Drawing.Point(529, 486);
            this.Add_Stock_TB.Name = "Add_Stock_TB";
            this.Add_Stock_TB.Size = new System.Drawing.Size(350, 33);
            this.Add_Stock_TB.TabIndex = 3;
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.BackColor = System.Drawing.Color.Transparent;
            this.Label1.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label1.ForeColor = System.Drawing.Color.Maroon;
            this.Label1.Location = new System.Drawing.Point(180, 486);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(214, 25);
            this.Label1.TabIndex = 130;
            this.Label1.Text = "Add Stock Quantity";
            // 
            // Stock_Available_TB
            // 
            this.Stock_Available_TB.BackColor = System.Drawing.Color.White;
            this.Stock_Available_TB.Enabled = false;
            this.Stock_Available_TB.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Stock_Available_TB.Location = new System.Drawing.Point(529, 417);
            this.Stock_Available_TB.Name = "Stock_Available_TB";
            this.Stock_Available_TB.Size = new System.Drawing.Size(350, 33);
            this.Stock_Available_TB.TabIndex = 123;
            // 
            // Label6
            // 
            this.Label6.AutoSize = true;
            this.Label6.BackColor = System.Drawing.Color.Transparent;
            this.Label6.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label6.Location = new System.Drawing.Point(180, 417);
            this.Label6.Name = "Label6";
            this.Label6.Size = new System.Drawing.Size(172, 25);
            this.Label6.TabIndex = 129;
            this.Label6.Text = "Stock Available";
            // 
            // Brand_TB
            // 
            this.Brand_TB.BackColor = System.Drawing.Color.White;
            this.Brand_TB.Enabled = false;
            this.Brand_TB.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Brand_TB.Location = new System.Drawing.Point(529, 276);
            this.Brand_TB.Name = "Brand_TB";
            this.Brand_TB.Size = new System.Drawing.Size(350, 33);
            this.Brand_TB.TabIndex = 121;
            // 
            // Dealer_Name_TB
            // 
            this.Dealer_Name_TB.BackColor = System.Drawing.Color.White;
            this.Dealer_Name_TB.Enabled = false;
            this.Dealer_Name_TB.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Dealer_Name_TB.Location = new System.Drawing.Point(529, 344);
            this.Dealer_Name_TB.Name = "Dealer_Name_TB";
            this.Dealer_Name_TB.Size = new System.Drawing.Size(350, 33);
            this.Dealer_Name_TB.TabIndex = 122;
            // 
            // Label4
            // 
            this.Label4.AutoSize = true;
            this.Label4.BackColor = System.Drawing.Color.Transparent;
            this.Label4.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label4.Location = new System.Drawing.Point(180, 276);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(74, 25);
            this.Label4.TabIndex = 128;
            this.Label4.Text = "Brand";
            // 
            // Label3
            // 
            this.Label3.AutoSize = true;
            this.Label3.BackColor = System.Drawing.Color.Transparent;
            this.Label3.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label3.Location = new System.Drawing.Point(180, 344);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(151, 25);
            this.Label3.TabIndex = 127;
            this.Label3.Text = "Dealer Name";
            // 
            // Product_Name_TB
            // 
            this.Product_Name_TB.BackColor = System.Drawing.Color.White;
            this.Product_Name_TB.Enabled = false;
            this.Product_Name_TB.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Product_Name_TB.Location = new System.Drawing.Point(529, 204);
            this.Product_Name_TB.Name = "Product_Name_TB";
            this.Product_Name_TB.Size = new System.Drawing.Size(350, 33);
            this.Product_Name_TB.TabIndex = 135;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(180, 204);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(161, 25);
            this.label5.TabIndex = 136;
            this.label5.Text = "Product Name";
            // 
            // Frm_Update_Stock
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1124, 627);
            this.Controls.Add(this.Product_Name_TB);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.Btn_exit);
            this.Controls.Add(this.Btn_fetch);
            this.Controls.Add(this.Product_ID_TB);
            this.Controls.Add(this.Label2);
            this.Controls.Add(this.Panel1);
            this.Controls.Add(this.Btn_clear);
            this.Controls.Add(this.Btn_save);
            this.Controls.Add(this.Add_Stock_TB);
            this.Controls.Add(this.Label1);
            this.Controls.Add(this.Stock_Available_TB);
            this.Controls.Add(this.Label6);
            this.Controls.Add(this.Brand_TB);
            this.Controls.Add(this.Dealer_Name_TB);
            this.Controls.Add(this.Label4);
            this.Controls.Add(this.Label3);
            this.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "Frm_Update_Stock";
            this.Text = "Frm_Update_Stock";
            this.Leave += new System.EventHandler(this.Frm_Update_Stock_Leave);
            this.Panel1.ResumeLayout(false);
            this.Panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.Button Btn_exit;
        internal System.Windows.Forms.Button Btn_fetch;
        internal System.Windows.Forms.TextBox Product_ID_TB;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.Panel Panel1;
        internal System.Windows.Forms.Label Lable1;
        internal System.Windows.Forms.Button Btn_clear;
        internal System.Windows.Forms.Button Btn_save;
        internal System.Windows.Forms.TextBox Add_Stock_TB;
        internal System.Windows.Forms.Label Label1;
        internal System.Windows.Forms.TextBox Stock_Available_TB;
        internal System.Windows.Forms.Label Label6;
        internal System.Windows.Forms.TextBox Brand_TB;
        internal System.Windows.Forms.TextBox Dealer_Name_TB;
        internal System.Windows.Forms.Label Label4;
        internal System.Windows.Forms.Label Label3;
        internal System.Windows.Forms.TextBox Product_Name_TB;
        internal System.Windows.Forms.Label label5;
    }
}