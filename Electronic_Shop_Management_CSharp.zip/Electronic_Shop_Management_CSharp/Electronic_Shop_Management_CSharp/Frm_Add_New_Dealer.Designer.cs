﻿namespace Electronic_Shop_Management_CSharp
{
    partial class Frm_Add_New_Dealer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Btn_exit = new System.Windows.Forms.Button();
            this.Lable1 = new System.Windows.Forms.Label();
            this.Panel1 = new System.Windows.Forms.Panel();
            this.Email_ID_TB = new System.Windows.Forms.TextBox();
            this.Label7 = new System.Windows.Forms.Label();
            this.PAN_No_TB = new System.Windows.Forms.TextBox();
            this.Label1 = new System.Windows.Forms.Label();
            this.Btn_clear = new System.Windows.Forms.Button();
            this.Btn_save = new System.Windows.Forms.Button();
            this.Adhar_No_TB = new System.Windows.Forms.TextBox();
            this.Label6 = new System.Windows.Forms.Label();
            this.Address_TB = new System.Windows.Forms.TextBox();
            this.Mob_No_TB = new System.Windows.Forms.TextBox();
            this.Dealer_Name_TB = new System.Windows.Forms.TextBox();
            this.Label5 = new System.Windows.Forms.Label();
            this.Label4 = new System.Windows.Forms.Label();
            this.Label3 = new System.Windows.Forms.Label();
            this.Dealer_ID_TB = new System.Windows.Forms.TextBox();
            this.Label2 = new System.Windows.Forms.Label();
            this.Panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // Btn_exit
            // 
            this.Btn_exit.BackColor = System.Drawing.Color.DimGray;
            this.Btn_exit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn_exit.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.Btn_exit.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_exit.ForeColor = System.Drawing.Color.White;
            this.Btn_exit.Location = new System.Drawing.Point(748, 509);
            this.Btn_exit.Name = "Btn_exit";
            this.Btn_exit.Size = new System.Drawing.Size(143, 42);
            this.Btn_exit.TabIndex = 56;
            this.Btn_exit.Text = "Exit";
            this.Btn_exit.UseVisualStyleBackColor = false;
            this.Btn_exit.Click += new System.EventHandler(this.Btn_exit_Click);
            // 
            // Lable1
            // 
            this.Lable1.AutoSize = true;
            this.Lable1.Font = new System.Drawing.Font("Verdana", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lable1.ForeColor = System.Drawing.Color.Black;
            this.Lable1.Location = new System.Drawing.Point(289, 25);
            this.Lable1.Name = "Lable1";
            this.Lable1.Size = new System.Drawing.Size(434, 45);
            this.Lable1.TabIndex = 29;
            this.Lable1.Text = " New Dealer Details";
            // 
            // Panel1
            // 
            this.Panel1.BackColor = System.Drawing.Color.Transparent;
            this.Panel1.Controls.Add(this.Lable1);
            this.Panel1.Location = new System.Drawing.Point(0, 1);
            this.Panel1.Name = "Panel1";
            this.Panel1.Size = new System.Drawing.Size(1085, 100);
            this.Panel1.TabIndex = 64;
            // 
            // Email_ID_TB
            // 
            this.Email_ID_TB.BackColor = System.Drawing.Color.White;
            this.Email_ID_TB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Email_ID_TB.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Email_ID_TB.Location = new System.Drawing.Point(513, 429);
            this.Email_ID_TB.MaxLength = 100;
            this.Email_ID_TB.Name = "Email_ID_TB";
            this.Email_ID_TB.Size = new System.Drawing.Size(345, 33);
            this.Email_ID_TB.TabIndex = 53;
            // 
            // Label7
            // 
            this.Label7.AutoSize = true;
            this.Label7.BackColor = System.Drawing.Color.Transparent;
            this.Label7.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label7.ForeColor = System.Drawing.Color.Black;
            this.Label7.Location = new System.Drawing.Point(229, 434);
            this.Label7.Name = "Label7";
            this.Label7.Size = new System.Drawing.Size(101, 25);
            this.Label7.TabIndex = 63;
            this.Label7.Text = "Email ID";
            // 
            // PAN_No_TB
            // 
            this.PAN_No_TB.BackColor = System.Drawing.Color.White;
            this.PAN_No_TB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PAN_No_TB.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PAN_No_TB.Location = new System.Drawing.Point(513, 381);
            this.PAN_No_TB.MaxLength = 10;
            this.PAN_No_TB.Name = "PAN_No_TB";
            this.PAN_No_TB.Size = new System.Drawing.Size(345, 33);
            this.PAN_No_TB.TabIndex = 52;
            this.PAN_No_TB.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.PAN_No_TB_KeyPress);
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.BackColor = System.Drawing.Color.Transparent;
            this.Label1.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label1.ForeColor = System.Drawing.Color.Black;
            this.Label1.Location = new System.Drawing.Point(228, 389);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(198, 25);
            this.Label1.TabIndex = 62;
            this.Label1.Text = "Pan Card Number";
            // 
            // Btn_clear
            // 
            this.Btn_clear.BackColor = System.Drawing.Color.DimGray;
            this.Btn_clear.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn_clear.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.Btn_clear.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_clear.ForeColor = System.Drawing.Color.White;
            this.Btn_clear.Location = new System.Drawing.Point(476, 509);
            this.Btn_clear.Name = "Btn_clear";
            this.Btn_clear.Size = new System.Drawing.Size(143, 42);
            this.Btn_clear.TabIndex = 55;
            this.Btn_clear.Text = "Clear";
            this.Btn_clear.UseVisualStyleBackColor = false;
            this.Btn_clear.Click += new System.EventHandler(this.Btn_clear_Click);
            // 
            // Btn_save
            // 
            this.Btn_save.BackColor = System.Drawing.Color.DimGray;
            this.Btn_save.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn_save.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.Btn_save.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_save.ForeColor = System.Drawing.Color.White;
            this.Btn_save.Location = new System.Drawing.Point(195, 509);
            this.Btn_save.Name = "Btn_save";
            this.Btn_save.Size = new System.Drawing.Size(143, 42);
            this.Btn_save.TabIndex = 54;
            this.Btn_save.Text = "Save";
            this.Btn_save.UseVisualStyleBackColor = false;
            this.Btn_save.Click += new System.EventHandler(this.Btn_save_Click);
            // 
            // Adhar_No_TB
            // 
            this.Adhar_No_TB.BackColor = System.Drawing.Color.White;
            this.Adhar_No_TB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Adhar_No_TB.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Adhar_No_TB.Location = new System.Drawing.Point(513, 335);
            this.Adhar_No_TB.MaxLength = 12;
            this.Adhar_No_TB.Name = "Adhar_No_TB";
            this.Adhar_No_TB.Size = new System.Drawing.Size(345, 33);
            this.Adhar_No_TB.TabIndex = 51;
            this.Adhar_No_TB.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Adhar_No_TB_KeyPress);
            // 
            // Label6
            // 
            this.Label6.AutoSize = true;
            this.Label6.BackColor = System.Drawing.Color.Transparent;
            this.Label6.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label6.ForeColor = System.Drawing.Color.Black;
            this.Label6.Location = new System.Drawing.Point(229, 343);
            this.Label6.Name = "Label6";
            this.Label6.Size = new System.Drawing.Size(165, 25);
            this.Label6.TabIndex = 61;
            this.Label6.Text = "Adhar Number";
            // 
            // Address_TB
            // 
            this.Address_TB.BackColor = System.Drawing.Color.White;
            this.Address_TB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Address_TB.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Address_TB.Location = new System.Drawing.Point(513, 241);
            this.Address_TB.Name = "Address_TB";
            this.Address_TB.Size = new System.Drawing.Size(345, 33);
            this.Address_TB.TabIndex = 49;
            // 
            // Mob_No_TB
            // 
            this.Mob_No_TB.BackColor = System.Drawing.Color.White;
            this.Mob_No_TB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Mob_No_TB.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Mob_No_TB.Location = new System.Drawing.Point(513, 287);
            this.Mob_No_TB.MaxLength = 10;
            this.Mob_No_TB.Name = "Mob_No_TB";
            this.Mob_No_TB.Size = new System.Drawing.Size(345, 33);
            this.Mob_No_TB.TabIndex = 50;
            this.Mob_No_TB.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Mob_No_TB_KeyPress);
            // 
            // Dealer_Name_TB
            // 
            this.Dealer_Name_TB.BackColor = System.Drawing.Color.White;
            this.Dealer_Name_TB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Dealer_Name_TB.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Dealer_Name_TB.Location = new System.Drawing.Point(513, 193);
            this.Dealer_Name_TB.Name = "Dealer_Name_TB";
            this.Dealer_Name_TB.Size = new System.Drawing.Size(345, 33);
            this.Dealer_Name_TB.TabIndex = 48;
            // 
            // Label5
            // 
            this.Label5.AutoSize = true;
            this.Label5.BackColor = System.Drawing.Color.Transparent;
            this.Label5.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label5.ForeColor = System.Drawing.Color.Black;
            this.Label5.Location = new System.Drawing.Point(228, 201);
            this.Label5.Name = "Label5";
            this.Label5.Size = new System.Drawing.Size(151, 25);
            this.Label5.TabIndex = 60;
            this.Label5.Text = "Dealer Name";
            // 
            // Label4
            // 
            this.Label4.AutoSize = true;
            this.Label4.BackColor = System.Drawing.Color.Transparent;
            this.Label4.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label4.ForeColor = System.Drawing.Color.Black;
            this.Label4.Location = new System.Drawing.Point(229, 246);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(96, 25);
            this.Label4.TabIndex = 59;
            this.Label4.Text = "Address";
            // 
            // Label3
            // 
            this.Label3.AutoSize = true;
            this.Label3.BackColor = System.Drawing.Color.Transparent;
            this.Label3.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label3.ForeColor = System.Drawing.Color.Black;
            this.Label3.Location = new System.Drawing.Point(228, 295);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(172, 25);
            this.Label3.TabIndex = 58;
            this.Label3.Text = "Mobile Number";
            // 
            // Dealer_ID_TB
            // 
            this.Dealer_ID_TB.BackColor = System.Drawing.Color.White;
            this.Dealer_ID_TB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Dealer_ID_TB.Enabled = false;
            this.Dealer_ID_TB.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Dealer_ID_TB.Location = new System.Drawing.Point(513, 146);
            this.Dealer_ID_TB.Name = "Dealer_ID_TB";
            this.Dealer_ID_TB.Size = new System.Drawing.Size(345, 33);
            this.Dealer_ID_TB.TabIndex = 47;
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.BackColor = System.Drawing.Color.Transparent;
            this.Label2.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label2.ForeColor = System.Drawing.Color.Black;
            this.Label2.Location = new System.Drawing.Point(228, 148);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(113, 25);
            this.Label2.TabIndex = 57;
            this.Label2.Text = "Dealer ID";
            // 
            // Frm_Add_New_Dealer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1086, 587);
            this.Controls.Add(this.Btn_exit);
            this.Controls.Add(this.Panel1);
            this.Controls.Add(this.Email_ID_TB);
            this.Controls.Add(this.Label7);
            this.Controls.Add(this.PAN_No_TB);
            this.Controls.Add(this.Label1);
            this.Controls.Add(this.Btn_clear);
            this.Controls.Add(this.Btn_save);
            this.Controls.Add(this.Adhar_No_TB);
            this.Controls.Add(this.Label6);
            this.Controls.Add(this.Address_TB);
            this.Controls.Add(this.Mob_No_TB);
            this.Controls.Add(this.Dealer_Name_TB);
            this.Controls.Add(this.Label5);
            this.Controls.Add(this.Label4);
            this.Controls.Add(this.Label3);
            this.Controls.Add(this.Dealer_ID_TB);
            this.Controls.Add(this.Label2);
            this.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "Frm_Add_New_Dealer";
            this.Text = "Frm_Add_New_Dealer";
            this.Load += new System.EventHandler(this.Frm_Add_New_Dealer_Load);
            this.Leave += new System.EventHandler(this.Frm_Add_New_Dealer_Leave);
            this.Panel1.ResumeLayout(false);
            this.Panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.Button Btn_exit;
        internal System.Windows.Forms.Label Lable1;
        internal System.Windows.Forms.Panel Panel1;
        internal System.Windows.Forms.TextBox Email_ID_TB;
        internal System.Windows.Forms.Label Label7;
        internal System.Windows.Forms.TextBox PAN_No_TB;
        internal System.Windows.Forms.Label Label1;
        internal System.Windows.Forms.Button Btn_clear;
        internal System.Windows.Forms.Button Btn_save;
        internal System.Windows.Forms.TextBox Adhar_No_TB;
        internal System.Windows.Forms.Label Label6;
        internal System.Windows.Forms.TextBox Address_TB;
        internal System.Windows.Forms.TextBox Mob_No_TB;
        internal System.Windows.Forms.TextBox Dealer_Name_TB;
        internal System.Windows.Forms.Label Label5;
        internal System.Windows.Forms.Label Label4;
        internal System.Windows.Forms.Label Label3;
        internal System.Windows.Forms.TextBox Dealer_ID_TB;
        internal System.Windows.Forms.Label Label2;
    }
}