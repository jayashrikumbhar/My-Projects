﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Electronic_Shop_Management_CSharp
{
    public partial class Frm_Add_New_Customer : Form
    {
        SqlConnection Con = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=Electronic_Shop_Management_DB;Integrated Security=True");
        SqlCommand Cmd = new SqlCommand();
        String str,str1;
        DataTable table = new DataTable();
        SqlDataReader dr;

        public void Connection_Open()
        {
            if (Con.State == ConnectionState.Closed)
            {
                Con.Open();
            }
        }

        public void Connection_Close()
        {
            if (Con.State == ConnectionState.Open)
            {
                Con.Close();
            }
        }

        public void Clear_Controls()
        {
            Cust_Name_TB.Text = "";
            Address_TB.Text = "";
            Mob_No_TB.Text = "";
            Brand_CMB.Text = "Select Brand";
            Product_Name_CMB.Text = "Select Product";
            CGST_TB.Text = "";
            Quantity_TB.Text = "";
            Price_TB.Text = "";
            Discount_TB.Text = "";
            Total_Amount_TB.Text = "";
        }

        public int Autoincreament(string str)
        {
            Connection_Open();
            Cmd.CommandText = str;
            Cmd.Connection = Con;
            int a = Convert.ToInt32(Cmd.ExecuteScalar());

            if (a > 0)
            {
                a = a + 1;
            }
            else
            {
                a = 1;
            }

            Connection_Close();
            return a;
        }

        public Frm_Add_New_Customer()
        {
            InitializeComponent();
        }

        private void Frm_Add_New_Customer_Load(object sender, EventArgs e)
        {
            Cust_ID_TB.Text = Convert.ToString(Autoincreament("SELECT COUNT(Customer_ID) FROM Customer_Detail"));

            Connection_Open();
            Cmd.CommandText = "SELECT DISTINCT(Product_Brand) FROM Product_Detail_Table";
            Cmd.Connection = Con;
            dr = Cmd.ExecuteReader();
            while (dr.Read())
            {
                Brand_CMB.Items.Add(dr["Product_Brand"].ToString());
            }
            dr.Close();

            table.Columns.Add("Product_Name");
            table.Columns.Add("Product_Brand");
            table.Columns.Add("Quantity");
            table.Columns.Add("Sale_Rate");
            table.Columns.Add("SGST");
            table.Columns.Add("CGST");
            table.Columns.Add("Price");

            product_grid.DataSource = table;
            Connection_Close();
        }

        private void Brand_CMB_SelectedIndexChanged(object sender, EventArgs e)
        {
            Product_Name_CMB.Items.Clear();
            Connection_Open();
            Cmd.CommandText = "SELECT DISTINCT(Product_Name) FROM Product_Detail_Table WHERE Product_Brand='" + Brand_CMB.Text + "'";
            Cmd.Connection = Con;
            dr = Cmd.ExecuteReader();
            while (dr.Read())
            {
                Product_Name_CMB.Items.Add(dr["Product_Name"].ToString());
            }
            dr.Close();
            Connection_Close();
        }

        private void Product_Name_CMB_SelectedIndexChanged(object sender, EventArgs e)
        {
            Connection_Open();
            Cmd.CommandText = "SELECT * FROM Product_Detail_Table WHERE Product_Name='" + Product_Name_CMB.Text + "'";
            Cmd.Connection = Con;
            dr = Cmd.ExecuteReader();
            if (dr.Read())
            {
                Sale_Rate_TB.Text = dr["Sale_Rate"].ToString();
                CGST_TB.Text = dr["CGST"].ToString();
                SGST_TB.Text = dr["SGST"].ToString();
            }
            else
            {
                MessageBox.Show("There is error while retriving information!");
            }
            Connection_Close();
        }

        private void Quantity_TB_TextChanged(object sender, EventArgs e)
        {
            int b =Convert.ToInt32(Quantity_TB.Text);
            double cgst = Convert.ToDouble(CGST_TB.Text);
            double sgst = Convert.ToDouble(SGST_TB.Text);
            double Sale_Rate = Convert.ToDouble(Sale_Rate_TB.Text);
            cgst = (cgst * Sale_Rate) / 100;
            sgst = (sgst * Sale_Rate) / 100;
            double total = Convert.ToDouble(cgst + sgst + Sale_Rate);

            Price_TB.Text = (total*b).ToString();

            Btn_Add.Enabled = true;
            Btn_Confirm.Enabled = true;
            Btn_Remove.Enabled = true;
        }

        private void Btn_Add_Click(object sender, EventArgs e)
        {
            if (Brand_CMB.Text != "" && Product_Name_CMB.Text != "" && Sale_Rate_TB.Text != "" && CGST_TB.Text != "" && SGST_TB.Text != "" && Price_TB.Text != "")
            {
                table.Rows.Add(Product_Name_CMB.Text, Brand_CMB.Text, Quantity_TB.Text, Sale_Rate_TB.Text, SGST_TB.Text, CGST_TB.Text, Price_TB.Text);
                product_grid.DataSource = "";
                product_grid.DataSource = table;
            }
            else
            {
                MessageBox.Show("Please Fill all the fields!!");    
            }

            Brand_CMB.Text = "Select Brand";
            Product_Name_CMB.Text = "Select Product";
            Product_Name_CMB.Items.Clear();
            CGST_TB.Text = "";
            SGST_TB.Text = "";
            Price_TB.Text = "";
            Sale_Rate_TB.Text = ""; 
            Quantity_TB.Text = "";

        }

        private void product_grid_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = new DataGridViewRow();
                row = this.product_grid.Rows[e.RowIndex];
                Product_Name_CMB.Text = row.Cells["Product_Name"].Value.ToString();
                Brand_CMB.Text = row.Cells["Product_Brand"].Value.ToString();
                CGST_TB.Text = row.Cells["CGST"].Value.ToString();
                SGST_TB.Text = row.Cells["SGST"].Value.ToString();
                Sale_Rate_TB.Text = row.Cells["Sale_Rate"].Value.ToString();
                Quantity_TB.Text = row.Cells["Quantity"].Value.ToString();
               // Price_TB.Text = row.Cells[Price_TB.Text].Value.ToString();
            }
        }

        private void Btn_Remove_Click(object sender, EventArgs e)
        {
            //DataGridViewRow row = new DataGridViewRow();
            foreach (DataGridViewRow row in product_grid.SelectedRows)
            {
                product_grid.Rows.Remove(row);
            }
        }

        private void Btn_Confirm_Click(object sender, EventArgs e)
        {
            int Total = 0;
            int i;
            //double Price = Convert.ToDouble(Price_TB.Text); 
            for (i = 0; i<= product_grid.RowCount-1;i++)
            {
                Total += Convert.ToInt32(product_grid.Rows[i].Cells[6].Value);
   
            }
            Total_Amount_TB.Text =Convert.ToString(Total);
            Btn_save.Enabled = true;
        }

        private void Btn_save_Click(object sender, EventArgs e)
        {
            Connection_Open();
            //DataGridViewRow rw = new DataGridViewRow();
            Cmd.CommandText = "INSERT INTO Customer_Detail VALUES(" + Cust_ID_TB.Text + ",'" + Cust_Name_TB.Text + "','" + Address_TB.Text + "'," + Mob_No_TB.Text + "," + Total_Amount_TB.Text + ",'" + System_Date_DTP.Text + "')";
            Cmd.Connection = Con;
            str =Convert.ToString(Cmd.ExecuteNonQuery());
            Cmd.Dispose();
            foreach(DataGridViewRow rw in product_grid.Rows)
            {
                Cmd.CommandText = "INSERT INTO Customer_Bill_Detail_Table VALUES(" + Cust_ID_TB.Text + ",'" + rw.Cells[1].Value + "','" + rw.Cells[0].Value + "'," + rw.Cells[3].Value + "," + rw.Cells[6].Value + "," + rw.Cells[4].Value + "," + rw.Cells[2].Value + "," + rw.Cells[6].Value + ",'" + System_Date_DTP.Text + "')";
                Cmd.Connection = Con;
                str1 = Convert.ToString(Cmd.ExecuteNonQuery());
            }
               
            if (str != null && str1 != null)
            {
                MessageBox.Show("Record saved successfully!!");
                Clear_Controls();
                Cust_ID_TB.Text = Convert.ToString(Autoincreament("SELECT COUNT(Customer_ID) FROM Customer_Detail"));
            }
            else
            {
                MessageBox.Show("There is error while saving record!!");
            }
            Connection_Close();
            product_grid.Columns.Clear();
            Btn_Add.Enabled = false;
            Btn_Remove.Enabled = false;
            Btn_Confirm.Enabled = false;
            Btn_save.Enabled = false;
        }

        private void Mob_No_TB_TextChanged(object sender, EventArgs e)
        {
            Electronic_Product_GrpBox.Enabled = true;
        }

        private void Discount_TB_Leave(object sender, EventArgs e)
        {
            if (Total_Amount_TB.Text != "")
            {
                double a = Convert.ToDouble(Discount_TB.Text);
                double b = Convert.ToDouble(Total_Amount_TB.Text);
                Total_Amount_TB.Text = (b - a).ToString();
            }
            else
            {
                MessageBox.Show("No total claculted yet!!!");
            }
        }

        private void Quantity_TB_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar >= '0' && e.KeyChar <= '9' || e.KeyChar == ' ')
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void Mob_No_TB_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar >= '0' && e.KeyChar <= '9' || e.KeyChar == ' ')
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

       
    }
}
