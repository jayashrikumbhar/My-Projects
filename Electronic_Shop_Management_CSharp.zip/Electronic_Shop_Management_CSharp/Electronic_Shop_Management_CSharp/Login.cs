﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Common;
using System.Data.SqlClient;
using Electronic_Shop_Management_CSharp;

namespace Banking_Application_in_CSharp
{
    public partial class Login : Form
    {
        SqlConnection Con = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=Electronic_Shop_Management_DB;Integrated Security=True");
        SqlCommand Cmd = new SqlCommand();
        String str;

        public void Connection_Open()
        {
            if (Con.State == ConnectionState.Closed)
            {
                Con.Open();
            }
        }

        public void Connection_Close()
        {
            if (Con.State == ConnectionState.Open)
            {
                Con.Close();
            }
        }

        public void Clear_Controls()
        {
            TB_UN_Name.Text = "";
            TB_Pass.Text = "";
        }

        public Login()
        {
            InitializeComponent();
        }

        private void Login_Btn_Click(object sender, EventArgs e)
        {
            Connection_Open();
            Cmd.CommandText = "SELECT * FROM User_Detail_Table WHERE Username='" + TB_UN_Name.Text + "' AND Password='" + TB_Pass.Text + "'";
            Cmd.Connection = Con;
            str = Convert.ToString(Cmd.ExecuteScalar());
            //str = Cmd.ExecuteScalar()
            if (!(String.IsNullOrEmpty(str)))
            {
                if (TB_UN_Name.Text == "a")
                {
                    MessageBox.Show("Welcome Admin!!!!");
                    ConnectionCls.User_Mgt = 1;
                    this.Hide();
                    Frm_MdiParent_Electronic_Shop_Management n = new Frm_MdiParent_Electronic_Shop_Management();
                   n.Show();
                    Clear_Controls();
                }
                else
                {
                    MessageBox.Show("Welcome User!!!!");
                    this.Hide();
                    Frm_MdiParent_Electronic_Shop_Management n = new Frm_MdiParent_Electronic_Shop_Management();
                    n.Show();
                    Clear_Controls();
                }
            }
            else
            {
                MessageBox.Show("Please enter correct username or password!!!!");
                Clear_Controls();
                TB_Pass.Enabled = false;
                Login_Btn.Enabled = false;
            }
        }

        private void TB_UN_Name_TextChanged(object sender, EventArgs e)
        {
            TB_Pass.Enabled = true;
        }

        private void TB_Pass_TextChanged(object sender, EventArgs e)
        {
            Login_Btn.Enabled = true;
        }

     
    }
}
