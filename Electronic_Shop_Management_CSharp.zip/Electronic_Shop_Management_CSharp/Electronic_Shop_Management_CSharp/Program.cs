﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using Banking_Application_in_CSharp;

namespace Electronic_Shop_Management_CSharp
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Login());
        }
    }
}
