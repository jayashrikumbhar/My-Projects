﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;

namespace Electronic_Shop_Management_CSharp
{
    public partial class Frm_Display_Employee : Form
    {
        SqlConnection Con = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=Electronic_Shop_Management_DB;Integrated Security=True");
        SqlCommand Cmd = new SqlCommand();

        public void Connection_Open()
        {
            if (Con.State == ConnectionState.Closed)
            {
                Con.Open();
            }
        }

        public void Connection_Close()
        {
            if (Con.State == ConnectionState.Open)
            {
                Con.Close();
            }
        }

        public Frm_Display_Employee()
        {
            InitializeComponent();
        }

        private void Frm_Display_Employee_Load(object sender, EventArgs e)
        {
            Search_CMB.Text = "Select for Search";
            Search_CMB.Focus();
            Connection_Open();
            Cmd.Connection = Con;

            Cmd.CommandText = "SELECT * FROM Employee_Detail_Table";

            SqlDataAdapter da = new SqlDataAdapter(Cmd);
            DataTable dt = new DataTable();

            da.Fill(dt);

            dataGridView1.DataSource = dt;
            Connection_Close();
        }

        private void Btn_search_Click(object sender, EventArgs e)
        {
            Connection_Open();
            if (Value_TB.Text != "")
            {
                if (Search_CMB.Text == "Dealer ID")
                {
                    Cmd.CommandText = "SELECT * FROM Employee_Detail_Table WHERE Emp_Id LIKE '%" + Value_TB.Text + "%'";
                }
                else if (Search_CMB.Text == "Dealer Name")
                {
                    Cmd.CommandText = "SELECT * FROM Employee_Detail_Table WHERE Emp_Name LIKE '%" + Value_TB.Text + "%'";
                }
            }
            SqlDataAdapter da = new SqlDataAdapter(Cmd);
            DataTable dt = new DataTable();

            da.Fill(dt);
            dataGridView1.DataSource = dt;
            Connection_Close();
        }

        private void Btn_Refresh_Click(object sender, EventArgs e)
        {
            Search_CMB.Text = "Select for Search";
            Search_CMB.Focus();
            Connection_Open();
            Cmd.Connection = Con;

            Cmd.CommandText = "SELECT * FROM Employee_Detail_Table";

            SqlDataAdapter da = new SqlDataAdapter(Cmd);
            DataTable dt = new DataTable();

            da.Fill(dt);

            dataGridView1.DataSource = dt;
            Connection_Close();
            Value_TB.Text = "";

            Value_TB.Enabled = false;
            Btn_search.Enabled = false;
            Btn_Refresh.Enabled = false;
        }

        private void Value_TB_TextChanged(object sender, EventArgs e)
        {
            Btn_search.Enabled = true;
            Btn_Refresh.Enabled = true;
        }

        private void Search_CMB_SelectedIndexChanged(object sender, EventArgs e)
        {
            Value_TB.Enabled = true;
        }

    }
}
