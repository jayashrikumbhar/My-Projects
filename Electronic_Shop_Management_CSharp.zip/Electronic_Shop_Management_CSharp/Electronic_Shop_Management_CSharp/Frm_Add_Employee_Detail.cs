﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;

namespace Electronic_Shop_Management_CSharp
{
    public partial class Frm_Add_Employee_Detail : Form
    {
        SqlConnection Con = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=Electronic_Shop_Management_DB;Integrated Security=True");
        SqlCommand Cmd = new SqlCommand();
        String str;
        ConnectionCls cobj = new ConnectionCls();

        public void Connection_Open()
        {
            if (Con.State == ConnectionState.Closed)
            {
                Con.Open();
            }
        }

        public void Connection_Close()
        {
            if (Con.State == ConnectionState.Open)
            {
                Con.Close();
            }
        }

        public void Clear_Controls()
        {
            Emp_Name_TB.Text = "";
            Emp_Add_TB.Text = "";
            Emp_Salary_TB.Text = "";
            Mob_No_TB.Text = "";
            Adhar_TB.Text = "";
            PAN_No_TB.Text = "";
            Email_ID_TB.Text = "";
        }

        
        public Frm_Add_Employee_Detail()
        {
            InitializeComponent();
        }

        private void Btn_save_Click(object sender, EventArgs e)
        {
            string date= System.DateTime.Now.ToString();
            Connection_Open();
            if (Emp_Id_TB.Text != "" && Emp_Name_TB.Text != "" && Emp_Add_TB.Text != "" && Mob_No_TB.Text != "" && Adhar_TB.Text != "" && PAN_No_TB.Text != "" && Email_ID_TB.Text != "" && Emp_Salary_TB.Text != "")
            {
                Cmd.CommandText = "INSERT INTO Employee_Detail_Table VALUES(" + Emp_Id_TB.Text + ",'" + Emp_Name_TB.Text + "','" + Emp_Add_TB.Text + "'," + Mob_No_TB.Text + "," + Adhar_TB.Text + ",'" + PAN_No_TB.Text + "','" + Email_ID_TB.Text + "'," + Emp_Salary_TB.Text + ",'" + date + "')";
                Cmd.Connection = Con;
                str = Convert.ToString(Cmd.ExecuteNonQuery());
                if (str != null)
                {
                    MessageBox.Show("Record Saved Successfully!!");
                    Clear_Controls();
                    Emp_Id_TB.Text = Convert.ToString(cobj.Autoincreament("SELECT COUNT(Emp_ID) FROM Employee_Detail_Table"));
                }

            }
            else
            {
                MessageBox.Show("Please first fill all the fields!!");
            }
            Connection_Close();
            Btn_save.Enabled = false;
            Btn_clear.Enabled = false;
        }

        private void Frm_Add_Employee_Detail_Load(object sender, EventArgs e)
        {
            Emp_Id_TB.Text = Convert.ToString(cobj.Autoincreament("SELECT COUNT(Emp_ID) FROM Employee_Detail_Table"));
        }

        private void Btn_clear_Click(object sender, EventArgs e)
        {
            Clear_Controls();
        }

        private void Btn_exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Frm_Add_Employee_Detail_Leave(object sender, EventArgs e)
        {
            Clear_Controls();
        }

        private void Emp_Salary_TB_TextChanged(object sender, EventArgs e)
        {
            Btn_save.Enabled = true;
            Btn_clear.Enabled = true;
        }
         
        private void Mob_No_TB_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar >= '0' && e.KeyChar <= '9' || e.KeyChar == ' ')
            {
                e.Handled = false;
            }
            else
            {
                e.Handled=true;
            }
        }

        private void Adhar_TB_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar >= '0' && e.KeyChar <= '9' || e.KeyChar == ' ')
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void PAN_No_TB_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar >= '0' && e.KeyChar <= '9' || e.KeyChar == ' ')
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }
        
    }
}
