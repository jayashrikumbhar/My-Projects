﻿namespace Electronic_Shop_Management_CSharp
{
    partial class Frm_Update_Product_Detail
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Brand_TB = new System.Windows.Forms.TextBox();
            this.Btn_exit = new System.Windows.Forms.Button();
            this.Btn_fetch = new System.Windows.Forms.Button();
            this.Description_TB = new System.Windows.Forms.TextBox();
            this.Lable1 = new System.Windows.Forms.Label();
            this.Label8 = new System.Windows.Forms.Label();
            this.Label2 = new System.Windows.Forms.Label();
            this.Product_ID_TB = new System.Windows.Forms.TextBox();
            this.Sale_Rate_TB = new System.Windows.Forms.TextBox();
            this.Dealer_Rate_TB = new System.Windows.Forms.TextBox();
            this.Label1 = new System.Windows.Forms.Label();
            this.Label5 = new System.Windows.Forms.Label();
            this.Label7 = new System.Windows.Forms.Label();
            this.Product_Name_TB = new System.Windows.Forms.TextBox();
            this.SGST_TB = new System.Windows.Forms.TextBox();
            this.Label9 = new System.Windows.Forms.Label();
            this.Panel1 = new System.Windows.Forms.Panel();
            this.Btn_clear = new System.Windows.Forms.Button();
            this.Btn_update = new System.Windows.Forms.Button();
            this.Label4 = new System.Windows.Forms.Label();
            this.Btn_delete = new System.Windows.Forms.Button();
            this.Dealer_Name_TB = new System.Windows.Forms.TextBox();
            this.Label3 = new System.Windows.Forms.Label();
            this.CGST_TB = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.Panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // Brand_TB
            // 
            this.Brand_TB.BackColor = System.Drawing.Color.White;
            this.Brand_TB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Brand_TB.Enabled = false;
            this.Brand_TB.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Brand_TB.Location = new System.Drawing.Point(230, 313);
            this.Brand_TB.Name = "Brand_TB";
            this.Brand_TB.Size = new System.Drawing.Size(259, 31);
            this.Brand_TB.TabIndex = 85;
            // 
            // Btn_exit
            // 
            this.Btn_exit.BackColor = System.Drawing.Color.DimGray;
            this.Btn_exit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn_exit.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.Btn_exit.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_exit.ForeColor = System.Drawing.Color.White;
            this.Btn_exit.Location = new System.Drawing.Point(1022, 500);
            this.Btn_exit.Name = "Btn_exit";
            this.Btn_exit.Size = new System.Drawing.Size(143, 42);
            this.Btn_exit.TabIndex = 9;
            this.Btn_exit.Text = "Exit";
            this.Btn_exit.UseVisualStyleBackColor = false;
            this.Btn_exit.Click += new System.EventHandler(this.Btn_exit_Click);
            // 
            // Btn_fetch
            // 
            this.Btn_fetch.BackColor = System.Drawing.Color.DimGray;
            this.Btn_fetch.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn_fetch.Enabled = false;
            this.Btn_fetch.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.Btn_fetch.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_fetch.ForeColor = System.Drawing.Color.White;
            this.Btn_fetch.Location = new System.Drawing.Point(547, 185);
            this.Btn_fetch.Name = "Btn_fetch";
            this.Btn_fetch.Size = new System.Drawing.Size(143, 42);
            this.Btn_fetch.TabIndex = 2;
            this.Btn_fetch.Text = "Fetch";
            this.Btn_fetch.UseVisualStyleBackColor = false;
            this.Btn_fetch.Click += new System.EventHandler(this.Btn_fetch_Click);
            // 
            // Description_TB
            // 
            this.Description_TB.BackColor = System.Drawing.Color.White;
            this.Description_TB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Description_TB.Enabled = false;
            this.Description_TB.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Description_TB.Location = new System.Drawing.Point(230, 369);
            this.Description_TB.Name = "Description_TB";
            this.Description_TB.Size = new System.Drawing.Size(259, 31);
            this.Description_TB.TabIndex = 86;
            // 
            // Lable1
            // 
            this.Lable1.AutoSize = true;
            this.Lable1.Font = new System.Drawing.Font("Verdana", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lable1.ForeColor = System.Drawing.Color.Black;
            this.Lable1.Location = new System.Drawing.Point(378, 30);
            this.Lable1.Name = "Lable1";
            this.Lable1.Size = new System.Drawing.Size(502, 45);
            this.Lable1.TabIndex = 15;
            this.Lable1.Text = "Update Product Details";
            // 
            // Label8
            // 
            this.Label8.AutoSize = true;
            this.Label8.BackColor = System.Drawing.Color.Transparent;
            this.Label8.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label8.ForeColor = System.Drawing.Color.Black;
            this.Label8.Location = new System.Drawing.Point(23, 372);
            this.Label8.Name = "Label8";
            this.Label8.Size = new System.Drawing.Size(131, 25);
            this.Label8.TabIndex = 101;
            this.Label8.Text = "Description";
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.BackColor = System.Drawing.Color.Transparent;
            this.Label2.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label2.ForeColor = System.Drawing.Color.Black;
            this.Label2.Location = new System.Drawing.Point(23, 198);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(123, 25);
            this.Label2.TabIndex = 96;
            this.Label2.Text = "Product ID";
            // 
            // Product_ID_TB
            // 
            this.Product_ID_TB.BackColor = System.Drawing.Color.White;
            this.Product_ID_TB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Product_ID_TB.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Product_ID_TB.Location = new System.Drawing.Point(230, 193);
            this.Product_ID_TB.Name = "Product_ID_TB";
            this.Product_ID_TB.Size = new System.Drawing.Size(259, 31);
            this.Product_ID_TB.TabIndex = 1;
            this.Product_ID_TB.TextChanged += new System.EventHandler(this.Product_ID_TB_TextChanged);
            // 
            // Sale_Rate_TB
            // 
            this.Sale_Rate_TB.BackColor = System.Drawing.Color.White;
            this.Sale_Rate_TB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Sale_Rate_TB.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Sale_Rate_TB.Location = new System.Drawing.Point(938, 369);
            this.Sale_Rate_TB.Name = "Sale_Rate_TB";
            this.Sale_Rate_TB.Size = new System.Drawing.Size(263, 31);
            this.Sale_Rate_TB.TabIndex = 5;
            // 
            // Dealer_Rate_TB
            // 
            this.Dealer_Rate_TB.BackColor = System.Drawing.Color.White;
            this.Dealer_Rate_TB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Dealer_Rate_TB.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Dealer_Rate_TB.Location = new System.Drawing.Point(938, 313);
            this.Dealer_Rate_TB.Name = "Dealer_Rate_TB";
            this.Dealer_Rate_TB.Size = new System.Drawing.Size(263, 31);
            this.Dealer_Rate_TB.TabIndex = 4;
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.BackColor = System.Drawing.Color.Transparent;
            this.Label1.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label1.ForeColor = System.Drawing.Color.Black;
            this.Label1.Location = new System.Drawing.Point(731, 311);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(138, 25);
            this.Label1.TabIndex = 92;
            this.Label1.Text = "Dealer Rate";
            // 
            // Label5
            // 
            this.Label5.AutoSize = true;
            this.Label5.BackColor = System.Drawing.Color.Transparent;
            this.Label5.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label5.ForeColor = System.Drawing.Color.Black;
            this.Label5.Location = new System.Drawing.Point(23, 253);
            this.Label5.Name = "Label5";
            this.Label5.Size = new System.Drawing.Size(161, 25);
            this.Label5.TabIndex = 98;
            this.Label5.Text = "Product Name";
            // 
            // Label7
            // 
            this.Label7.AutoSize = true;
            this.Label7.BackColor = System.Drawing.Color.Transparent;
            this.Label7.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label7.ForeColor = System.Drawing.Color.Black;
            this.Label7.Location = new System.Drawing.Point(731, 369);
            this.Label7.Name = "Label7";
            this.Label7.Size = new System.Drawing.Size(114, 25);
            this.Label7.TabIndex = 100;
            this.Label7.Text = "Sale Rate";
            // 
            // Product_Name_TB
            // 
            this.Product_Name_TB.BackColor = System.Drawing.Color.White;
            this.Product_Name_TB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Product_Name_TB.Enabled = false;
            this.Product_Name_TB.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Product_Name_TB.Location = new System.Drawing.Point(230, 250);
            this.Product_Name_TB.Name = "Product_Name_TB";
            this.Product_Name_TB.Size = new System.Drawing.Size(259, 31);
            this.Product_Name_TB.TabIndex = 84;
            // 
            // SGST_TB
            // 
            this.SGST_TB.BackColor = System.Drawing.Color.White;
            this.SGST_TB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.SGST_TB.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SGST_TB.Location = new System.Drawing.Point(938, 250);
            this.SGST_TB.Name = "SGST_TB";
            this.SGST_TB.Size = new System.Drawing.Size(263, 31);
            this.SGST_TB.TabIndex = 3;
            // 
            // Label9
            // 
            this.Label9.AutoSize = true;
            this.Label9.BackColor = System.Drawing.Color.Transparent;
            this.Label9.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label9.ForeColor = System.Drawing.Color.Black;
            this.Label9.Location = new System.Drawing.Point(731, 250);
            this.Label9.Name = "Label9";
            this.Label9.Size = new System.Drawing.Size(99, 25);
            this.Label9.TabIndex = 99;
            this.Label9.Text = "SGST %";
            // 
            // Panel1
            // 
            this.Panel1.BackColor = System.Drawing.Color.Transparent;
            this.Panel1.Controls.Add(this.Lable1);
            this.Panel1.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.Panel1.Location = new System.Drawing.Point(1, 1);
            this.Panel1.Name = "Panel1";
            this.Panel1.Size = new System.Drawing.Size(1259, 104);
            this.Panel1.TabIndex = 90;
            // 
            // Btn_clear
            // 
            this.Btn_clear.BackColor = System.Drawing.Color.DimGray;
            this.Btn_clear.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn_clear.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.Btn_clear.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_clear.ForeColor = System.Drawing.Color.White;
            this.Btn_clear.Location = new System.Drawing.Point(730, 500);
            this.Btn_clear.Name = "Btn_clear";
            this.Btn_clear.Size = new System.Drawing.Size(143, 42);
            this.Btn_clear.TabIndex = 8;
            this.Btn_clear.Text = "Clear";
            this.Btn_clear.UseVisualStyleBackColor = false;
            this.Btn_clear.Click += new System.EventHandler(this.Btn_clear_Click);
            // 
            // Btn_update
            // 
            this.Btn_update.BackColor = System.Drawing.Color.DimGray;
            this.Btn_update.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn_update.Enabled = false;
            this.Btn_update.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.Btn_update.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_update.ForeColor = System.Drawing.Color.White;
            this.Btn_update.Location = new System.Drawing.Point(461, 500);
            this.Btn_update.Name = "Btn_update";
            this.Btn_update.Size = new System.Drawing.Size(143, 42);
            this.Btn_update.TabIndex = 7;
            this.Btn_update.Text = "Update";
            this.Btn_update.UseVisualStyleBackColor = false;
            this.Btn_update.Click += new System.EventHandler(this.Btn_update_Click);
            // 
            // Label4
            // 
            this.Label4.AutoSize = true;
            this.Label4.BackColor = System.Drawing.Color.Transparent;
            this.Label4.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label4.ForeColor = System.Drawing.Color.Black;
            this.Label4.Location = new System.Drawing.Point(23, 313);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(74, 25);
            this.Label4.TabIndex = 91;
            this.Label4.Text = "Brand";
            // 
            // Btn_delete
            // 
            this.Btn_delete.Enabled = false;
            this.Btn_delete.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_delete.Location = new System.Drawing.Point(206, 500);
            this.Btn_delete.Name = "Btn_delete";
            this.Btn_delete.Size = new System.Drawing.Size(111, 42);
            this.Btn_delete.TabIndex = 6;
            this.Btn_delete.Text = "Delete";
            this.Btn_delete.UseVisualStyleBackColor = true;
            this.Btn_delete.Click += new System.EventHandler(this.Btn_delete_Click);
            // 
            // Dealer_Name_TB
            // 
            this.Dealer_Name_TB.BackColor = System.Drawing.Color.White;
            this.Dealer_Name_TB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Dealer_Name_TB.Enabled = false;
            this.Dealer_Name_TB.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Dealer_Name_TB.Location = new System.Drawing.Point(230, 430);
            this.Dealer_Name_TB.Name = "Dealer_Name_TB";
            this.Dealer_Name_TB.Size = new System.Drawing.Size(259, 31);
            this.Dealer_Name_TB.TabIndex = 102;
            // 
            // Label3
            // 
            this.Label3.AutoSize = true;
            this.Label3.BackColor = System.Drawing.Color.Transparent;
            this.Label3.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label3.ForeColor = System.Drawing.Color.Black;
            this.Label3.Location = new System.Drawing.Point(23, 430);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(151, 25);
            this.Label3.TabIndex = 103;
            this.Label3.Text = "Dealer Name";
            // 
            // CGST_TB
            // 
            this.CGST_TB.BackColor = System.Drawing.Color.White;
            this.CGST_TB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.CGST_TB.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CGST_TB.Location = new System.Drawing.Point(938, 192);
            this.CGST_TB.Name = "CGST_TB";
            this.CGST_TB.Size = new System.Drawing.Size(263, 31);
            this.CGST_TB.TabIndex = 104;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(731, 193);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(100, 25);
            this.label6.TabIndex = 105;
            this.label6.Text = "CGST %";
            // 
            // Frm_Update_Product_Detail
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1260, 591);
            this.Controls.Add(this.CGST_TB);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.Dealer_Name_TB);
            this.Controls.Add(this.Label3);
            this.Controls.Add(this.Btn_delete);
            this.Controls.Add(this.Brand_TB);
            this.Controls.Add(this.Btn_exit);
            this.Controls.Add(this.Btn_fetch);
            this.Controls.Add(this.Description_TB);
            this.Controls.Add(this.Label8);
            this.Controls.Add(this.Label2);
            this.Controls.Add(this.Product_ID_TB);
            this.Controls.Add(this.Sale_Rate_TB);
            this.Controls.Add(this.Dealer_Rate_TB);
            this.Controls.Add(this.Label1);
            this.Controls.Add(this.Label5);
            this.Controls.Add(this.Label7);
            this.Controls.Add(this.Product_Name_TB);
            this.Controls.Add(this.SGST_TB);
            this.Controls.Add(this.Label9);
            this.Controls.Add(this.Panel1);
            this.Controls.Add(this.Btn_clear);
            this.Controls.Add(this.Btn_update);
            this.Controls.Add(this.Label4);
            this.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "Frm_Update_Product_Detail";
            this.Text = "Frm_Update_Product_Detail";
            this.Leave += new System.EventHandler(this.Frm_Update_Product_Detail_Leave);
            this.Panel1.ResumeLayout(false);
            this.Panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.TextBox Brand_TB;
        internal System.Windows.Forms.Button Btn_exit;
        internal System.Windows.Forms.Button Btn_fetch;
        internal System.Windows.Forms.TextBox Description_TB;
        internal System.Windows.Forms.Label Lable1;
        internal System.Windows.Forms.Label Label8;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.TextBox Product_ID_TB;
        internal System.Windows.Forms.TextBox Sale_Rate_TB;
        internal System.Windows.Forms.TextBox Dealer_Rate_TB;
        internal System.Windows.Forms.Label Label1;
        internal System.Windows.Forms.Label Label5;
        internal System.Windows.Forms.Label Label7;
        internal System.Windows.Forms.TextBox Product_Name_TB;
        internal System.Windows.Forms.TextBox SGST_TB;
        internal System.Windows.Forms.Label Label9;
        internal System.Windows.Forms.Panel Panel1;
        internal System.Windows.Forms.Button Btn_clear;
        internal System.Windows.Forms.Button Btn_update;
        internal System.Windows.Forms.Label Label4;
        private System.Windows.Forms.Button Btn_delete;
        internal System.Windows.Forms.TextBox Dealer_Name_TB;
        internal System.Windows.Forms.Label Label3;
        internal System.Windows.Forms.TextBox CGST_TB;
        internal System.Windows.Forms.Label label6;
    }
}