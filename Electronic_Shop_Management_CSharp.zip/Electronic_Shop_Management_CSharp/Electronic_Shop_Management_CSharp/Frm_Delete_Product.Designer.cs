﻿namespace Electronic_Shop_Management_CSharp
{
    partial class Frm_Delete_Product
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Btn_exit = new System.Windows.Forms.Button();
            this.Sale_Rate_TB = new System.Windows.Forms.TextBox();
            this.Panel1 = new System.Windows.Forms.Panel();
            this.Lable1 = new System.Windows.Forms.Label();
            this.Dealer_Rate_TB = new System.Windows.Forms.TextBox();
            this.Label1 = new System.Windows.Forms.Label();
            this.Btn_fetch = new System.Windows.Forms.Button();
            this.Label7 = new System.Windows.Forms.Label();
            this.Btn_delete = new System.Windows.Forms.Button();
            this.GST_TB = new System.Windows.Forms.TextBox();
            this.Label2 = new System.Windows.Forms.Label();
            this.Label9 = new System.Windows.Forms.Label();
            this.Product_ID_TB = new System.Windows.Forms.TextBox();
            this.Description_TB = new System.Windows.Forms.TextBox();
            this.Label3 = new System.Windows.Forms.Label();
            this.Label6 = new System.Windows.Forms.Label();
            this.Label4 = new System.Windows.Forms.Label();
            this.Brand_CMB = new System.Windows.Forms.TextBox();
            this.Label5 = new System.Windows.Forms.Label();
            this.Dealer_Name_CMB = new System.Windows.Forms.TextBox();
            this.Product_Name_TB = new System.Windows.Forms.TextBox();
            this.Panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // Btn_exit
            // 
            this.Btn_exit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn_exit.Font = new System.Drawing.Font("Verdana", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_exit.Location = new System.Drawing.Point(569, 446);
            this.Btn_exit.Name = "Btn_exit";
            this.Btn_exit.Size = new System.Drawing.Size(97, 51);
            this.Btn_exit.TabIndex = 69;
            this.Btn_exit.Text = "Exit";
            this.Btn_exit.UseVisualStyleBackColor = true;
            // 
            // Sale_Rate_TB
            // 
            this.Sale_Rate_TB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Sale_Rate_TB.Enabled = false;
            this.Sale_Rate_TB.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Sale_Rate_TB.Location = new System.Drawing.Point(780, 354);
            this.Sale_Rate_TB.Name = "Sale_Rate_TB";
            this.Sale_Rate_TB.Size = new System.Drawing.Size(196, 33);
            this.Sale_Rate_TB.TabIndex = 59;
            // 
            // Panel1
            // 
            this.Panel1.BackColor = System.Drawing.Color.White;
            this.Panel1.Controls.Add(this.Lable1);
            this.Panel1.Location = new System.Drawing.Point(2, 0);
            this.Panel1.Name = "Panel1";
            this.Panel1.Size = new System.Drawing.Size(1018, 100);
            this.Panel1.TabIndex = 63;
            // 
            // Lable1
            // 
            this.Lable1.AutoSize = true;
            this.Lable1.Font = new System.Drawing.Font("Verdana", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lable1.Location = new System.Drawing.Point(299, 30);
            this.Lable1.Name = "Lable1";
            this.Lable1.Size = new System.Drawing.Size(420, 38);
            this.Lable1.TabIndex = 29;
            this.Lable1.Text = "Delete Product Details";
            // 
            // Dealer_Rate_TB
            // 
            this.Dealer_Rate_TB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Dealer_Rate_TB.Enabled = false;
            this.Dealer_Rate_TB.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Dealer_Rate_TB.Location = new System.Drawing.Point(780, 286);
            this.Dealer_Rate_TB.Name = "Dealer_Rate_TB";
            this.Dealer_Rate_TB.Size = new System.Drawing.Size(196, 33);
            this.Dealer_Rate_TB.TabIndex = 58;
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label1.Location = new System.Drawing.Point(590, 288);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(138, 25);
            this.Label1.TabIndex = 57;
            this.Label1.Text = "Dealer Rate";
            // 
            // Btn_fetch
            // 
            this.Btn_fetch.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn_fetch.Font = new System.Drawing.Font("Verdana", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_fetch.Location = new System.Drawing.Point(445, 151);
            this.Btn_fetch.Name = "Btn_fetch";
            this.Btn_fetch.Size = new System.Drawing.Size(118, 39);
            this.Btn_fetch.TabIndex = 51;
            this.Btn_fetch.Text = "Fetch";
            this.Btn_fetch.UseVisualStyleBackColor = true;
            this.Btn_fetch.Click += new System.EventHandler(this.Btn_fetch_Click);
            // 
            // Label7
            // 
            this.Label7.AutoSize = true;
            this.Label7.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label7.Location = new System.Drawing.Point(590, 356);
            this.Label7.Name = "Label7";
            this.Label7.Size = new System.Drawing.Size(114, 25);
            this.Label7.TabIndex = 68;
            this.Label7.Text = "Sale Rate";
            // 
            // Btn_delete
            // 
            this.Btn_delete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn_delete.Enabled = false;
            this.Btn_delete.Font = new System.Drawing.Font("Verdana", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_delete.Location = new System.Drawing.Point(354, 446);
            this.Btn_delete.Name = "Btn_delete";
            this.Btn_delete.Size = new System.Drawing.Size(112, 51);
            this.Btn_delete.TabIndex = 53;
            this.Btn_delete.Text = "Delete";
            this.Btn_delete.UseVisualStyleBackColor = true;
            this.Btn_delete.Click += new System.EventHandler(this.Btn_delete_Click);
            // 
            // GST_TB
            // 
            this.GST_TB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.GST_TB.Enabled = false;
            this.GST_TB.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GST_TB.Location = new System.Drawing.Point(780, 219);
            this.GST_TB.Name = "GST_TB";
            this.GST_TB.Size = new System.Drawing.Size(196, 33);
            this.GST_TB.TabIndex = 67;
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label2.Location = new System.Drawing.Point(17, 158);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(123, 25);
            this.Label2.TabIndex = 60;
            this.Label2.Text = "Product ID";
            // 
            // Label9
            // 
            this.Label9.AutoSize = true;
            this.Label9.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label9.Location = new System.Drawing.Point(590, 221);
            this.Label9.Name = "Label9";
            this.Label9.Size = new System.Drawing.Size(85, 25);
            this.Label9.TabIndex = 66;
            this.Label9.Text = "GST %";
            // 
            // Product_ID_TB
            // 
            this.Product_ID_TB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Product_ID_TB.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Product_ID_TB.Location = new System.Drawing.Point(206, 156);
            this.Product_ID_TB.Name = "Product_ID_TB";
            this.Product_ID_TB.Size = new System.Drawing.Size(210, 33);
            this.Product_ID_TB.TabIndex = 50;
            this.Product_ID_TB.TextChanged += new System.EventHandler(this.Product_ID_TB_TextChanged);
            // 
            // Description_TB
            // 
            this.Description_TB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Description_TB.Enabled = false;
            this.Description_TB.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Description_TB.Location = new System.Drawing.Point(780, 157);
            this.Description_TB.Name = "Description_TB";
            this.Description_TB.Size = new System.Drawing.Size(196, 33);
            this.Description_TB.TabIndex = 56;
            // 
            // Label3
            // 
            this.Label3.AutoSize = true;
            this.Label3.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label3.Location = new System.Drawing.Point(17, 356);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(151, 25);
            this.Label3.TabIndex = 61;
            this.Label3.Text = "Dealer Name";
            // 
            // Label6
            // 
            this.Label6.AutoSize = true;
            this.Label6.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label6.Location = new System.Drawing.Point(590, 159);
            this.Label6.Name = "Label6";
            this.Label6.Size = new System.Drawing.Size(131, 25);
            this.Label6.TabIndex = 65;
            this.Label6.Text = "Description";
            // 
            // Label4
            // 
            this.Label4.AutoSize = true;
            this.Label4.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label4.Location = new System.Drawing.Point(17, 288);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(74, 25);
            this.Label4.TabIndex = 62;
            this.Label4.Text = "Brand";
            // 
            // Brand_CMB
            // 
            this.Brand_CMB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Brand_CMB.Enabled = false;
            this.Brand_CMB.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Brand_CMB.Location = new System.Drawing.Point(206, 288);
            this.Brand_CMB.Name = "Brand_CMB";
            this.Brand_CMB.Size = new System.Drawing.Size(210, 33);
            this.Brand_CMB.TabIndex = 54;
            // 
            // Label5
            // 
            this.Label5.AutoSize = true;
            this.Label5.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label5.Location = new System.Drawing.Point(17, 221);
            this.Label5.Name = "Label5";
            this.Label5.Size = new System.Drawing.Size(161, 25);
            this.Label5.TabIndex = 64;
            this.Label5.Text = "Product Name";
            // 
            // Dealer_Name_CMB
            // 
            this.Dealer_Name_CMB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Dealer_Name_CMB.Enabled = false;
            this.Dealer_Name_CMB.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Dealer_Name_CMB.Location = new System.Drawing.Point(206, 350);
            this.Dealer_Name_CMB.Name = "Dealer_Name_CMB";
            this.Dealer_Name_CMB.Size = new System.Drawing.Size(210, 33);
            this.Dealer_Name_CMB.TabIndex = 55;
            // 
            // Product_Name_TB
            // 
            this.Product_Name_TB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Product_Name_TB.Enabled = false;
            this.Product_Name_TB.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Product_Name_TB.Location = new System.Drawing.Point(206, 223);
            this.Product_Name_TB.Name = "Product_Name_TB";
            this.Product_Name_TB.Size = new System.Drawing.Size(210, 33);
            this.Product_Name_TB.TabIndex = 52;
            // 
            // Frm_Delete_Product
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1020, 527);
            this.Controls.Add(this.Btn_exit);
            this.Controls.Add(this.Sale_Rate_TB);
            this.Controls.Add(this.Panel1);
            this.Controls.Add(this.Dealer_Rate_TB);
            this.Controls.Add(this.Label1);
            this.Controls.Add(this.Btn_fetch);
            this.Controls.Add(this.Label7);
            this.Controls.Add(this.Btn_delete);
            this.Controls.Add(this.GST_TB);
            this.Controls.Add(this.Label2);
            this.Controls.Add(this.Label9);
            this.Controls.Add(this.Product_ID_TB);
            this.Controls.Add(this.Description_TB);
            this.Controls.Add(this.Label3);
            this.Controls.Add(this.Label6);
            this.Controls.Add(this.Label4);
            this.Controls.Add(this.Brand_CMB);
            this.Controls.Add(this.Label5);
            this.Controls.Add(this.Dealer_Name_CMB);
            this.Controls.Add(this.Product_Name_TB);
            this.Name = "Frm_Delete_Product";
            this.Text = "Frm_Delete_Product";
            this.Panel1.ResumeLayout(false);
            this.Panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.Button Btn_exit;
        internal System.Windows.Forms.TextBox Sale_Rate_TB;
        internal System.Windows.Forms.Panel Panel1;
        internal System.Windows.Forms.Label Lable1;
        internal System.Windows.Forms.TextBox Dealer_Rate_TB;
        internal System.Windows.Forms.Label Label1;
        internal System.Windows.Forms.Button Btn_fetch;
        internal System.Windows.Forms.Label Label7;
        internal System.Windows.Forms.Button Btn_delete;
        internal System.Windows.Forms.TextBox GST_TB;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.Label Label9;
        internal System.Windows.Forms.TextBox Product_ID_TB;
        internal System.Windows.Forms.TextBox Description_TB;
        internal System.Windows.Forms.Label Label3;
        internal System.Windows.Forms.Label Label6;
        internal System.Windows.Forms.Label Label4;
        internal System.Windows.Forms.TextBox Brand_CMB;
        internal System.Windows.Forms.Label Label5;
        internal System.Windows.Forms.TextBox Dealer_Name_CMB;
        internal System.Windows.Forms.TextBox Product_Name_TB;
    }
}