﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Electronic_Shop_Management_CSharp
{
    public partial class Frm_MdiParent_Electronic_Shop_Management : Form
    {

        public Frm_MdiParent_Electronic_Shop_Management()
        {
            InitializeComponent();
        }

        private void Frm_MdiParent_Electronic_Shop_Management_Load(object sender, EventArgs e)
        {
            if (ConnectionCls.User_Mgt == 1)
            {
                productDetailToolStripMenuItem.Visible = true;
                stockDetailToolStripMenuItem.Visible = true;
                reportToolStripMenuItem.Visible = true;
                userManagementToolStripMenuItem.Visible = true;
            }
        }

        private void customerSaleDetailToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Frm_Add_New_Customer n = new Frm_Add_New_Customer();
            n.MdiParent = this;
            n.WindowState = FormWindowState.Maximized;
            n.Show();
        }

        private void allCustomerDetailToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Frm_Display_All_Customer n = new Frm_Display_All_Customer();
            n.MdiParent = this;
            n.WindowState = FormWindowState.Maximized;
            n.Show();
        }

        private void addProductToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Frm_Add_Product n = new Frm_Add_Product();
            n.MdiParent = this;
            n.WindowState = FormWindowState.Maximized;
            n.Show();
        }

        private void updateProductToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Frm_Update_Product_Detail n = new Frm_Update_Product_Detail();
            n.MdiParent = this;
            n.WindowState = FormWindowState.Maximized;
            n.Show();
        }

        private void viewAllProductToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Frm_Display_All_Product n = new Frm_Display_All_Product();
            n.MdiParent = this;
            n.WindowState = FormWindowState.Maximized;
            n.Show();
        }

        private void addDealerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Frm_Add_New_Dealer n = new Frm_Add_New_Dealer();
            n.MdiParent = this;
            n.WindowState = FormWindowState.Maximized;
            n.Show();
        }

        private void updateDealerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Frm_Update_Dealer n = new Frm_Update_Dealer();
            n.MdiParent = this;
            n.WindowState = FormWindowState.Maximized;
            n.Show();
        }

        private void viewAllDealerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Frm_Display_Dealer n = new Frm_Display_Dealer();
            n.MdiParent = this;
            n.WindowState = FormWindowState.Maximized;
            n.Show();
        }

        private void addEmployeeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Frm_Add_Employee_Detail n = new Frm_Add_Employee_Detail();
            n.MdiParent = this;
            n.WindowState = FormWindowState.Maximized;
            n.Show();
        }

        private void updateEmployeeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Frm_Delete_Employee n = new Frm_Delete_Employee();
            n.MdiParent = this;
            n.WindowState = FormWindowState.Maximized;
            n.Show();
        }

        private void viewAllEmployeeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Frm_Display_Employee n = new Frm_Display_Employee();
            n.MdiParent = this;
            n.WindowState = FormWindowState.Maximized;
            n.Show();
        }

        private void updateStockToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Frm_Update_Stock n = new Frm_Update_Stock();
            n.MdiParent = this;
            n.WindowState = FormWindowState.Maximized;
            n.Show();
        }

        private void searchToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Frm_Search_Stock_Availability n = new Frm_Search_Stock_Availability();
            n.MdiParent = this;
            n.WindowState = FormWindowState.Maximized;
            n.Show();
        }

        private void stockAddedDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Frm_Stock_Added_Detail n = new Frm_Stock_Added_Detail();
            n.MdiParent = this;
            n.WindowState = FormWindowState.Maximized;
            n.Show();
        }

        private void customerDetailToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Frm_Update_Dealer n = new Frm_Update_Dealer();
            n.WindowState = FormWindowState.Maximized;
            n.Show();
        }

        private void productDetailReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Frm_Update_Dealer n = new Frm_Update_Dealer();
            n.WindowState = FormWindowState.Maximized;
            n.Show();
        }

        private void stockDetailReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Frm_Update_Dealer n = new Frm_Update_Dealer();
            n.WindowState = FormWindowState.Maximized;
            n.Show();
        }

        private void singleCustomerDetailReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Frm_Update_Dealer n = new Frm_Update_Dealer();
            n.WindowState = FormWindowState.Maximized;
            n.Show();
        }

        private void singleStockAvailabilityToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Frm_Single_Stock_Availability n = new Frm_Single_Stock_Availability();
            n.MdiParent = this;
            n.WindowState = FormWindowState.Maximized;
            n.Show();
        }

        private void userManagementToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Frm_User_Account n = new Frm_User_Account();
            n.MdiParent = this;
            n.WindowState = FormWindowState.Maximized;
            n.Show();
        }

        private void Logout_Btn_Click(object sender, EventArgs e)
        {
            productDetailToolStripMenuItem.Visible = false;
            stockDetailToolStripMenuItem.Visible = false;
            reportToolStripMenuItem.Visible = false;
            userManagementToolStripMenuItem.Visible = false;
            ConnectionCls.User_Mgt = 0;
            this.Close();
            //Login n = new Login();
            //n.Show();
        }

       
    }
}
