﻿namespace Electronic_Shop_Management_CSharp
{
    partial class Frm_Display_All_Customer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Btn_Refreash = new System.Windows.Forms.Button();
            this.Search_CMB = new System.Windows.Forms.ComboBox();
            this.Btn_search = new System.Windows.Forms.Button();
            this.Value_TB = new System.Windows.Forms.TextBox();
            this.Label2 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.panel1 = new System.Windows.Forms.Panel();
            this.Lable1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // Btn_Refreash
            // 
            this.Btn_Refreash.BackColor = System.Drawing.Color.DimGray;
            this.Btn_Refreash.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn_Refreash.Enabled = false;
            this.Btn_Refreash.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.Btn_Refreash.Font = new System.Drawing.Font("Verdana", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_Refreash.ForeColor = System.Drawing.Color.White;
            this.Btn_Refreash.Location = new System.Drawing.Point(915, 111);
            this.Btn_Refreash.Name = "Btn_Refreash";
            this.Btn_Refreash.Size = new System.Drawing.Size(154, 46);
            this.Btn_Refreash.TabIndex = 109;
            this.Btn_Refreash.Text = "Refresh";
            this.Btn_Refreash.UseVisualStyleBackColor = false;
            this.Btn_Refreash.Click += new System.EventHandler(this.Btn_Refreash_Click);
            // 
            // Search_CMB
            // 
            this.Search_CMB.BackColor = System.Drawing.Color.White;
            this.Search_CMB.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Search_CMB.FormattingEnabled = true;
            this.Search_CMB.Items.AddRange(new object[] {
            "Customer_ID",
            "Customer_Name"});
            this.Search_CMB.Location = new System.Drawing.Point(189, 125);
            this.Search_CMB.Name = "Search_CMB";
            this.Search_CMB.Size = new System.Drawing.Size(215, 33);
            this.Search_CMB.TabIndex = 108;
            this.Search_CMB.SelectedIndexChanged += new System.EventHandler(this.Search_CMB_SelectedIndexChanged);
            // 
            // Btn_search
            // 
            this.Btn_search.BackColor = System.Drawing.Color.DimGray;
            this.Btn_search.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn_search.Enabled = false;
            this.Btn_search.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.Btn_search.Font = new System.Drawing.Font("Verdana", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_search.ForeColor = System.Drawing.Color.White;
            this.Btn_search.Location = new System.Drawing.Point(726, 112);
            this.Btn_search.Name = "Btn_search";
            this.Btn_search.Size = new System.Drawing.Size(154, 46);
            this.Btn_search.TabIndex = 106;
            this.Btn_search.Text = "Search";
            this.Btn_search.UseVisualStyleBackColor = false;
            this.Btn_search.Click += new System.EventHandler(this.Btn_search_Click);
            // 
            // Value_TB
            // 
            this.Value_TB.BackColor = System.Drawing.Color.White;
            this.Value_TB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Value_TB.Enabled = false;
            this.Value_TB.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Value_TB.Location = new System.Drawing.Point(458, 125);
            this.Value_TB.Name = "Value_TB";
            this.Value_TB.Size = new System.Drawing.Size(154, 33);
            this.Value_TB.TabIndex = 105;
            this.Value_TB.TextChanged += new System.EventHandler(this.Value_TB_TextChanged);
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.BackColor = System.Drawing.Color.Transparent;
            this.Label2.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label2.ForeColor = System.Drawing.Color.Black;
            this.Label2.Location = new System.Drawing.Point(21, 125);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(118, 25);
            this.Label2.TabIndex = 107;
            this.Label2.Text = "Search By";
            // 
            // dataGridView1
            // 
            this.dataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(0, 175);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(1148, 312);
            this.dataGridView1.TabIndex = 111;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.Lable1);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1148, 88);
            this.panel1.TabIndex = 112;
            // 
            // Lable1
            // 
            this.Lable1.AutoSize = true;
            this.Lable1.BackColor = System.Drawing.Color.Transparent;
            this.Lable1.Font = new System.Drawing.Font("Verdana", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lable1.ForeColor = System.Drawing.Color.Black;
            this.Lable1.Location = new System.Drawing.Point(351, 22);
            this.Lable1.Name = "Lable1";
            this.Lable1.Size = new System.Drawing.Size(446, 45);
            this.Lable1.TabIndex = 113;
            this.Lable1.Text = "All Customer Details";
            // 
            // Frm_Display_All_Customer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1148, 489);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.Btn_Refreash);
            this.Controls.Add(this.Search_CMB);
            this.Controls.Add(this.Btn_search);
            this.Controls.Add(this.Value_TB);
            this.Controls.Add(this.Label2);
            this.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "Frm_Display_All_Customer";
            this.Text = "Frm_Display_All_Product";
            this.Load += new System.EventHandler(this.Frm_Display_All_Customer_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.Button Btn_Refreash;
        internal System.Windows.Forms.ComboBox Search_CMB;
        internal System.Windows.Forms.Button Btn_search;
        internal System.Windows.Forms.TextBox Value_TB;
        internal System.Windows.Forms.Label Label2;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Panel panel1;
        internal System.Windows.Forms.Label Lable1;
    }
}