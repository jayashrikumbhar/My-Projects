﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Electronic_Shop_Management_CSharp
{
    public partial class Frm_User_Account : Form
    {
        SqlConnection Con = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=Electronic_Shop_Management_DB;Integrated Security=True");
        SqlCommand Cmd = new SqlCommand();
        String str;
        ConnectionCls cobj = new ConnectionCls();

        public void Connection_Open()
        {
            if (Con.State == ConnectionState.Closed)
            {
                Con.Open();
            }
        }

        public void Connection_Close()
        {
            if (Con.State == ConnectionState.Open)
            {
                Con.Close();
            }
        }

        public void Clear_Controls()
        {
            Username_TB.Text = "";
            Password_TB.Text = "";
            ConfirmPass_TB.Text = "";
            UserNm_TB.Text = "";
            New_Pass_TB.Text = "";
            Confirm_Pass_TB.Text = "";
            UN_TB.Text = "";
            Pass_TB.Text = "";
        }

        public Frm_User_Account()
        {
            InitializeComponent();
        }

        private void AddUser_Btn_Click(object sender, EventArgs e)
        {
            Connection_Open();

            if (Username_TB.Text != "" && Password_TB.Text != "" && ConfirmPass_TB.Text != "")
            {
                Cmd.CommandText = "INSERT INTO User_Detail_Table VALUES('" + Username_TB.Text + "','" + ConfirmPass_TB.Text + "')";
                Cmd.Connection = Con;
                if (Password_TB.Text == ConfirmPass_TB.Text)
                {
                    str = Convert.ToString(Cmd.ExecuteNonQuery());
                    if (str != null)
                    {
                        MessageBox.Show("Record saved successfully!!");
                        Clear_Controls();
                    }
                    else
                    {
                        MessageBox.Show("There is error while saving record!");
                        Clear_Controls();
                    }
                }
                else
                {
                    MessageBox.Show("Please check password!");
                }
            }
            else
            {
                MessageBox.Show("First fill all the fields!");
            }
            Connection_Close();
            AddUser_Btn.Enabled = false;
        }

        private void ConfirmPass_TB_TextChanged(object sender, EventArgs e)
        {
            AddUser_Btn.Enabled = true;
        }

        private void Change_Btn_Click(object sender, EventArgs e)
        {
            Connection_Open();

            if (UN_TB.Text != "" && New_Pass_TB.Text != "" && Confirm_Pass_TB.Text != "")
            {
                Cmd.CommandText = "UPDATE User_Detail_Table SET Username='" + Username_TB.Text + "',Password='" + Confirm_Pass_TB.Text + "' WHERE Username='" + Username_TB.Text + "'";
                Cmd.Connection = Con;
                if (New_Pass_TB.Text == Confirm_Pass_TB.Text)
                {
                    str = Convert.ToString(Cmd.ExecuteNonQuery());
                    if (str != null)
                    {
                        MessageBox.Show("Record saved successfully!!");
                        Clear_Controls();
                    }
                    else
                    {
                        MessageBox.Show("There is error while saving record!");
                        Clear_Controls();
                    }
                }
                else
                {
                    MessageBox.Show("Please check password!");
                }
            }
            else
            {
                MessageBox.Show("First fill all the fields!");
            }
            Connection_Close();
            Change_Btn.Enabled = false;
        }

        private void Confirm_Pass_TB_TextChanged(object sender, EventArgs e)
        {
            Change_Btn.Enabled = true;
        }

        private void Delete_Btn_Click(object sender, EventArgs e)
        {
            Connection_Open();

            if (UserNm_TB.Text != "" && Pass_TB.Text != "")
            {
                Cmd.CommandText = "DELETE FROM User_Detail_Table WHERE Username='" + UserNm_TB.Text + "'";
                Cmd.Connection = Con;
                str = Convert.ToString(Cmd.ExecuteNonQuery());
                if (str != null)
                {
                     MessageBox.Show("Record deleted successfully!!");
                     Clear_Controls();
                }
                else
                {
                     MessageBox.Show("There is error while deleting record!");
                     Clear_Controls();
                }
            }
            else
            {
                MessageBox.Show("First fill all the fields!");
            }
            Connection_Close();
            Delete_Btn.Enabled = false;
        }

        private void Pass_TB_TextChanged(object sender, EventArgs e)
        {
            Delete_Btn.Enabled = true;
        }
    }
}
