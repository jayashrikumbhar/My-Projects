﻿namespace Electronic_Shop_Management_CSharp
{
    partial class Frm_Single_Stock_Availability
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Frm_Single_Stock_Availability));
            this.Product_ID_TB = new System.Windows.Forms.TextBox();
            this.GroupBox1 = new System.Windows.Forms.GroupBox();
            this.Btn_fetch = new System.Windows.Forms.Button();
            this.Label2 = new System.Windows.Forms.Label();
            this.Btn_exit = new System.Windows.Forms.Button();
            this.Btn_clear = new System.Windows.Forms.Button();
            this.Panel1 = new System.Windows.Forms.Panel();
            this.Lable1 = new System.Windows.Forms.Label();
            this.Stock_Available_TB = new System.Windows.Forms.TextBox();
            this.Label6 = new System.Windows.Forms.Label();
            this.Brand_TB = new System.Windows.Forms.TextBox();
            this.Dealer_Name_TB = new System.Windows.Forms.TextBox();
            this.Product_Name_TB = new System.Windows.Forms.TextBox();
            this.Label5 = new System.Windows.Forms.Label();
            this.Label4 = new System.Windows.Forms.Label();
            this.Label3 = new System.Windows.Forms.Label();
            this.GroupBox1.SuspendLayout();
            this.Panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // Product_ID_TB
            // 
            this.Product_ID_TB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Product_ID_TB.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Product_ID_TB.Location = new System.Drawing.Point(641, 36);
            this.Product_ID_TB.Name = "Product_ID_TB";
            this.Product_ID_TB.Size = new System.Drawing.Size(231, 33);
            this.Product_ID_TB.TabIndex = 30;
            this.Product_ID_TB.TextChanged += new System.EventHandler(this.Product_ID_TB_TextChanged);
            // 
            // GroupBox1
            // 
            this.GroupBox1.BackColor = System.Drawing.Color.White;
            this.GroupBox1.Controls.Add(this.Btn_fetch);
            this.GroupBox1.Controls.Add(this.Product_ID_TB);
            this.GroupBox1.Controls.Add(this.Label2);
            this.GroupBox1.Location = new System.Drawing.Point(0, 109);
            this.GroupBox1.Name = "GroupBox1";
            this.GroupBox1.Size = new System.Drawing.Size(1216, 100);
            this.GroupBox1.TabIndex = 97;
            this.GroupBox1.TabStop = false;
            // 
            // Btn_fetch
            // 
            this.Btn_fetch.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn_fetch.Enabled = false;
            this.Btn_fetch.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.Btn_fetch.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_fetch.Location = new System.Drawing.Point(900, 31);
            this.Btn_fetch.Name = "Btn_fetch";
            this.Btn_fetch.Size = new System.Drawing.Size(111, 38);
            this.Btn_fetch.TabIndex = 31;
            this.Btn_fetch.Text = "Fetch";
            this.Btn_fetch.UseVisualStyleBackColor = true;
            this.Btn_fetch.Click += new System.EventHandler(this.Btn_fetch_Click);
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label2.Location = new System.Drawing.Point(262, 38);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(123, 25);
            this.Label2.TabIndex = 32;
            this.Label2.Text = "Product ID";
            // 
            // Btn_exit
            // 
            this.Btn_exit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn_exit.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.Btn_exit.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_exit.Location = new System.Drawing.Point(677, 567);
            this.Btn_exit.Name = "Btn_exit";
            this.Btn_exit.Size = new System.Drawing.Size(129, 51);
            this.Btn_exit.TabIndex = 96;
            this.Btn_exit.Text = "Exit";
            this.Btn_exit.UseVisualStyleBackColor = true;
            this.Btn_exit.Click += new System.EventHandler(this.Btn_exit_Click);
            // 
            // Btn_clear
            // 
            this.Btn_clear.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn_clear.Enabled = false;
            this.Btn_clear.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.Btn_clear.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_clear.Location = new System.Drawing.Point(407, 567);
            this.Btn_clear.Name = "Btn_clear";
            this.Btn_clear.Size = new System.Drawing.Size(147, 51);
            this.Btn_clear.TabIndex = 95;
            this.Btn_clear.Text = "Clear";
            this.Btn_clear.UseVisualStyleBackColor = true;
            this.Btn_clear.Click += new System.EventHandler(this.Btn_clear_Click);
            // 
            // Panel1
            // 
            this.Panel1.BackColor = System.Drawing.Color.White;
            this.Panel1.Controls.Add(this.Lable1);
            this.Panel1.Location = new System.Drawing.Point(0, 0);
            this.Panel1.Name = "Panel1";
            this.Panel1.Size = new System.Drawing.Size(1216, 103);
            this.Panel1.TabIndex = 94;
            // 
            // Lable1
            // 
            this.Lable1.AutoSize = true;
            this.Lable1.Font = new System.Drawing.Font("Verdana", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lable1.ForeColor = System.Drawing.Color.Gold;
            this.Lable1.Location = new System.Drawing.Point(449, 32);
            this.Lable1.Name = "Lable1";
            this.Lable1.Size = new System.Drawing.Size(319, 38);
            this.Lable1.TabIndex = 28;
            this.Lable1.Text = "Stock Availibility";
            // 
            // Stock_Available_TB
            // 
            this.Stock_Available_TB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Stock_Available_TB.Enabled = false;
            this.Stock_Available_TB.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Stock_Available_TB.Location = new System.Drawing.Point(641, 487);
            this.Stock_Available_TB.Name = "Stock_Available_TB";
            this.Stock_Available_TB.Size = new System.Drawing.Size(310, 33);
            this.Stock_Available_TB.TabIndex = 89;
            // 
            // Label6
            // 
            this.Label6.AutoSize = true;
            this.Label6.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label6.ForeColor = System.Drawing.Color.DarkRed;
            this.Label6.Location = new System.Drawing.Point(262, 493);
            this.Label6.Name = "Label6";
            this.Label6.Size = new System.Drawing.Size(172, 25);
            this.Label6.TabIndex = 93;
            this.Label6.Text = "Stock Available";
            // 
            // Brand_TB
            // 
            this.Brand_TB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Brand_TB.Enabled = false;
            this.Brand_TB.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Brand_TB.Location = new System.Drawing.Point(641, 309);
            this.Brand_TB.Name = "Brand_TB";
            this.Brand_TB.Size = new System.Drawing.Size(310, 33);
            this.Brand_TB.TabIndex = 87;
            // 
            // Dealer_Name_TB
            // 
            this.Dealer_Name_TB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Dealer_Name_TB.Enabled = false;
            this.Dealer_Name_TB.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Dealer_Name_TB.Location = new System.Drawing.Point(641, 396);
            this.Dealer_Name_TB.Name = "Dealer_Name_TB";
            this.Dealer_Name_TB.Size = new System.Drawing.Size(310, 33);
            this.Dealer_Name_TB.TabIndex = 88;
            // 
            // Product_Name_TB
            // 
            this.Product_Name_TB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Product_Name_TB.Enabled = false;
            this.Product_Name_TB.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Product_Name_TB.Location = new System.Drawing.Point(641, 229);
            this.Product_Name_TB.Name = "Product_Name_TB";
            this.Product_Name_TB.Size = new System.Drawing.Size(310, 33);
            this.Product_Name_TB.TabIndex = 86;
            // 
            // Label5
            // 
            this.Label5.AutoSize = true;
            this.Label5.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label5.Location = new System.Drawing.Point(262, 235);
            this.Label5.Name = "Label5";
            this.Label5.Size = new System.Drawing.Size(161, 25);
            this.Label5.TabIndex = 92;
            this.Label5.Text = "Product Name";
            // 
            // Label4
            // 
            this.Label4.AutoSize = true;
            this.Label4.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label4.Location = new System.Drawing.Point(262, 315);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(74, 25);
            this.Label4.TabIndex = 91;
            this.Label4.Text = "Brand";
            // 
            // Label3
            // 
            this.Label3.AutoSize = true;
            this.Label3.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label3.Location = new System.Drawing.Point(262, 402);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(151, 25);
            this.Label3.TabIndex = 90;
            this.Label3.Text = "Dealer Name";
            // 
            // Frm_Single_Stock_Availability
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1213, 664);
            this.Controls.Add(this.GroupBox1);
            this.Controls.Add(this.Btn_exit);
            this.Controls.Add(this.Btn_clear);
            this.Controls.Add(this.Panel1);
            this.Controls.Add(this.Stock_Available_TB);
            this.Controls.Add(this.Label6);
            this.Controls.Add(this.Brand_TB);
            this.Controls.Add(this.Dealer_Name_TB);
            this.Controls.Add(this.Product_Name_TB);
            this.Controls.Add(this.Label5);
            this.Controls.Add(this.Label4);
            this.Controls.Add(this.Label3);
            this.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "Frm_Single_Stock_Availability";
            this.Text = resources.GetString("$this.Text");
            this.GroupBox1.ResumeLayout(false);
            this.GroupBox1.PerformLayout();
            this.Panel1.ResumeLayout(false);
            this.Panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.TextBox Product_ID_TB;
        internal System.Windows.Forms.GroupBox GroupBox1;
        internal System.Windows.Forms.Button Btn_fetch;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.Button Btn_exit;
        internal System.Windows.Forms.Button Btn_clear;
        internal System.Windows.Forms.Panel Panel1;
        internal System.Windows.Forms.Label Lable1;
        internal System.Windows.Forms.TextBox Stock_Available_TB;
        internal System.Windows.Forms.Label Label6;
        internal System.Windows.Forms.TextBox Brand_TB;
        internal System.Windows.Forms.TextBox Dealer_Name_TB;
        internal System.Windows.Forms.TextBox Product_Name_TB;
        internal System.Windows.Forms.Label Label5;
        internal System.Windows.Forms.Label Label4;
        internal System.Windows.Forms.Label Label3;
    }
}