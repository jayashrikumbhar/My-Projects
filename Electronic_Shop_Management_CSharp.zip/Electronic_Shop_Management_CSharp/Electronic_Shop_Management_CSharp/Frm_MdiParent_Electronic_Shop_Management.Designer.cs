﻿namespace Electronic_Shop_Management_CSharp
{
    partial class Frm_MdiParent_Electronic_Shop_Management
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.menuStrip = new System.Windows.Forms.MenuStrip();
            this.customerDetailToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.customerSaleDetailToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.allCustomerDetailToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.productDetailToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addProductToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.updateProductToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewAllProductToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dealerDetailToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addDealerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.updateDealerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewAllDealerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.employeeDeatilToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addEmployeeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.updateEmployeeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewAllEmployeeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.stockDetailToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.updateStockToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.searchToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.stockAddedDetailsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.singleStockAvailabilityToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.customerDetailToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.productDetailReportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.stockDetailReportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.singleCustomerDetailReportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.userManagementToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolTip = new System.Windows.Forms.ToolTip(this.components);
            this.Logout_Btn = new System.Windows.Forms.Button();
            this.menuStrip.SuspendLayout();
            this.statusStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip
            // 
            this.menuStrip.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.customerDetailToolStripMenuItem,
            this.productDetailToolStripMenuItem,
            this.dealerDetailToolStripMenuItem,
            this.employeeDeatilToolStripMenuItem,
            this.stockDetailToolStripMenuItem,
            this.reportToolStripMenuItem,
            this.userManagementToolStripMenuItem});
            this.menuStrip.Location = new System.Drawing.Point(0, 0);
            this.menuStrip.Name = "menuStrip";
            this.menuStrip.Padding = new System.Windows.Forms.Padding(7, 2, 0, 2);
            this.menuStrip.Size = new System.Drawing.Size(1176, 26);
            this.menuStrip.TabIndex = 0;
            this.menuStrip.Text = "MenuStrip";
            // 
            // customerDetailToolStripMenuItem
            // 
            this.customerDetailToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.customerSaleDetailToolStripMenuItem,
            this.allCustomerDetailToolStripMenuItem});
            this.customerDetailToolStripMenuItem.Name = "customerDetailToolStripMenuItem";
            this.customerDetailToolStripMenuItem.Size = new System.Drawing.Size(153, 22);
            this.customerDetailToolStripMenuItem.Text = "Customer Detail";
            // 
            // customerSaleDetailToolStripMenuItem
            // 
            this.customerSaleDetailToolStripMenuItem.Name = "customerSaleDetailToolStripMenuItem";
            this.customerSaleDetailToolStripMenuItem.Size = new System.Drawing.Size(250, 22);
            this.customerSaleDetailToolStripMenuItem.Text = "Customer Sale Detail";
            this.customerSaleDetailToolStripMenuItem.Click += new System.EventHandler(this.customerSaleDetailToolStripMenuItem_Click);
            // 
            // allCustomerDetailToolStripMenuItem
            // 
            this.allCustomerDetailToolStripMenuItem.Name = "allCustomerDetailToolStripMenuItem";
            this.allCustomerDetailToolStripMenuItem.Size = new System.Drawing.Size(250, 22);
            this.allCustomerDetailToolStripMenuItem.Text = "All Customer Detail";
            this.allCustomerDetailToolStripMenuItem.Click += new System.EventHandler(this.allCustomerDetailToolStripMenuItem_Click);
            // 
            // productDetailToolStripMenuItem
            // 
            this.productDetailToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addProductToolStripMenuItem,
            this.updateProductToolStripMenuItem,
            this.viewAllProductToolStripMenuItem});
            this.productDetailToolStripMenuItem.Name = "productDetailToolStripMenuItem";
            this.productDetailToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.productDetailToolStripMenuItem.Text = "Product Detail";
            this.productDetailToolStripMenuItem.Visible = false;
            // 
            // addProductToolStripMenuItem
            // 
            this.addProductToolStripMenuItem.Name = "addProductToolStripMenuItem";
            this.addProductToolStripMenuItem.Size = new System.Drawing.Size(209, 22);
            this.addProductToolStripMenuItem.Text = "Add Product";
            this.addProductToolStripMenuItem.Click += new System.EventHandler(this.addProductToolStripMenuItem_Click);
            // 
            // updateProductToolStripMenuItem
            // 
            this.updateProductToolStripMenuItem.Name = "updateProductToolStripMenuItem";
            this.updateProductToolStripMenuItem.Size = new System.Drawing.Size(209, 22);
            this.updateProductToolStripMenuItem.Text = "Update Product";
            this.updateProductToolStripMenuItem.Click += new System.EventHandler(this.updateProductToolStripMenuItem_Click);
            // 
            // viewAllProductToolStripMenuItem
            // 
            this.viewAllProductToolStripMenuItem.Name = "viewAllProductToolStripMenuItem";
            this.viewAllProductToolStripMenuItem.Size = new System.Drawing.Size(209, 22);
            this.viewAllProductToolStripMenuItem.Text = "View All Product";
            this.viewAllProductToolStripMenuItem.Click += new System.EventHandler(this.viewAllProductToolStripMenuItem_Click);
            // 
            // dealerDetailToolStripMenuItem
            // 
            this.dealerDetailToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addDealerToolStripMenuItem,
            this.updateDealerToolStripMenuItem,
            this.viewAllDealerToolStripMenuItem});
            this.dealerDetailToolStripMenuItem.Name = "dealerDetailToolStripMenuItem";
            this.dealerDetailToolStripMenuItem.Size = new System.Drawing.Size(128, 22);
            this.dealerDetailToolStripMenuItem.Text = "Dealer Detail";
            // 
            // addDealerToolStripMenuItem
            // 
            this.addDealerToolStripMenuItem.Name = "addDealerToolStripMenuItem";
            this.addDealerToolStripMenuItem.Size = new System.Drawing.Size(201, 22);
            this.addDealerToolStripMenuItem.Text = "New Dealer";
            this.addDealerToolStripMenuItem.Click += new System.EventHandler(this.addDealerToolStripMenuItem_Click);
            // 
            // updateDealerToolStripMenuItem
            // 
            this.updateDealerToolStripMenuItem.Name = "updateDealerToolStripMenuItem";
            this.updateDealerToolStripMenuItem.Size = new System.Drawing.Size(201, 22);
            this.updateDealerToolStripMenuItem.Text = "Update Dealer";
            this.updateDealerToolStripMenuItem.Click += new System.EventHandler(this.updateDealerToolStripMenuItem_Click);
            // 
            // viewAllDealerToolStripMenuItem
            // 
            this.viewAllDealerToolStripMenuItem.Name = "viewAllDealerToolStripMenuItem";
            this.viewAllDealerToolStripMenuItem.Size = new System.Drawing.Size(201, 22);
            this.viewAllDealerToolStripMenuItem.Text = "View All Dealer";
            this.viewAllDealerToolStripMenuItem.Click += new System.EventHandler(this.viewAllDealerToolStripMenuItem_Click);
            // 
            // employeeDeatilToolStripMenuItem
            // 
            this.employeeDeatilToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addEmployeeToolStripMenuItem,
            this.updateEmployeeToolStripMenuItem,
            this.viewAllEmployeeToolStripMenuItem});
            this.employeeDeatilToolStripMenuItem.Name = "employeeDeatilToolStripMenuItem";
            this.employeeDeatilToolStripMenuItem.Size = new System.Drawing.Size(154, 22);
            this.employeeDeatilToolStripMenuItem.Text = "Employee Detail";
            // 
            // addEmployeeToolStripMenuItem
            // 
            this.addEmployeeToolStripMenuItem.Name = "addEmployeeToolStripMenuItem";
            this.addEmployeeToolStripMenuItem.Size = new System.Drawing.Size(227, 22);
            this.addEmployeeToolStripMenuItem.Text = "Add Employee";
            this.addEmployeeToolStripMenuItem.Click += new System.EventHandler(this.addEmployeeToolStripMenuItem_Click);
            // 
            // updateEmployeeToolStripMenuItem
            // 
            this.updateEmployeeToolStripMenuItem.Name = "updateEmployeeToolStripMenuItem";
            this.updateEmployeeToolStripMenuItem.Size = new System.Drawing.Size(227, 22);
            this.updateEmployeeToolStripMenuItem.Text = "Update Employee";
            this.updateEmployeeToolStripMenuItem.Click += new System.EventHandler(this.updateEmployeeToolStripMenuItem_Click);
            // 
            // viewAllEmployeeToolStripMenuItem
            // 
            this.viewAllEmployeeToolStripMenuItem.Name = "viewAllEmployeeToolStripMenuItem";
            this.viewAllEmployeeToolStripMenuItem.Size = new System.Drawing.Size(227, 22);
            this.viewAllEmployeeToolStripMenuItem.Text = "View All Employee";
            this.viewAllEmployeeToolStripMenuItem.Click += new System.EventHandler(this.viewAllEmployeeToolStripMenuItem_Click);
            // 
            // stockDetailToolStripMenuItem
            // 
            this.stockDetailToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.updateStockToolStripMenuItem,
            this.searchToolStripMenuItem,
            this.stockAddedDetailsToolStripMenuItem,
            this.singleStockAvailabilityToolStripMenuItem});
            this.stockDetailToolStripMenuItem.Name = "stockDetailToolStripMenuItem";
            this.stockDetailToolStripMenuItem.Size = new System.Drawing.Size(119, 22);
            this.stockDetailToolStripMenuItem.Text = "Stock Detail";
            this.stockDetailToolStripMenuItem.Visible = false;
            // 
            // updateStockToolStripMenuItem
            // 
            this.updateStockToolStripMenuItem.Name = "updateStockToolStripMenuItem";
            this.updateStockToolStripMenuItem.Size = new System.Drawing.Size(273, 22);
            this.updateStockToolStripMenuItem.Text = "Update Stock";
            this.updateStockToolStripMenuItem.Click += new System.EventHandler(this.updateStockToolStripMenuItem_Click);
            // 
            // searchToolStripMenuItem
            // 
            this.searchToolStripMenuItem.Name = "searchToolStripMenuItem";
            this.searchToolStripMenuItem.Size = new System.Drawing.Size(273, 22);
            this.searchToolStripMenuItem.Text = "Search Stock";
            this.searchToolStripMenuItem.Click += new System.EventHandler(this.searchToolStripMenuItem_Click);
            // 
            // stockAddedDetailsToolStripMenuItem
            // 
            this.stockAddedDetailsToolStripMenuItem.Name = "stockAddedDetailsToolStripMenuItem";
            this.stockAddedDetailsToolStripMenuItem.Size = new System.Drawing.Size(273, 22);
            this.stockAddedDetailsToolStripMenuItem.Text = "Stock Added Details";
            this.stockAddedDetailsToolStripMenuItem.Click += new System.EventHandler(this.stockAddedDetailsToolStripMenuItem_Click);
            // 
            // singleStockAvailabilityToolStripMenuItem
            // 
            this.singleStockAvailabilityToolStripMenuItem.Name = "singleStockAvailabilityToolStripMenuItem";
            this.singleStockAvailabilityToolStripMenuItem.Size = new System.Drawing.Size(273, 22);
            this.singleStockAvailabilityToolStripMenuItem.Text = "Single Stock Availability";
            this.singleStockAvailabilityToolStripMenuItem.Click += new System.EventHandler(this.singleStockAvailabilityToolStripMenuItem_Click);
            // 
            // reportToolStripMenuItem
            // 
            this.reportToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.customerDetailToolStripMenuItem1,
            this.productDetailReportToolStripMenuItem,
            this.stockDetailReportToolStripMenuItem,
            this.singleCustomerDetailReportToolStripMenuItem});
            this.reportToolStripMenuItem.Name = "reportToolStripMenuItem";
            this.reportToolStripMenuItem.Size = new System.Drawing.Size(74, 22);
            this.reportToolStripMenuItem.Text = "Report";
            this.reportToolStripMenuItem.Visible = false;
            // 
            // customerDetailToolStripMenuItem1
            // 
            this.customerDetailToolStripMenuItem1.Name = "customerDetailToolStripMenuItem1";
            this.customerDetailToolStripMenuItem1.Size = new System.Drawing.Size(325, 22);
            this.customerDetailToolStripMenuItem1.Text = "Customer Detail Report";
            this.customerDetailToolStripMenuItem1.Click += new System.EventHandler(this.customerDetailToolStripMenuItem1_Click);
            // 
            // productDetailReportToolStripMenuItem
            // 
            this.productDetailReportToolStripMenuItem.Name = "productDetailReportToolStripMenuItem";
            this.productDetailReportToolStripMenuItem.Size = new System.Drawing.Size(325, 22);
            this.productDetailReportToolStripMenuItem.Text = "Product Detail Report";
            this.productDetailReportToolStripMenuItem.Click += new System.EventHandler(this.productDetailReportToolStripMenuItem_Click);
            // 
            // stockDetailReportToolStripMenuItem
            // 
            this.stockDetailReportToolStripMenuItem.Name = "stockDetailReportToolStripMenuItem";
            this.stockDetailReportToolStripMenuItem.Size = new System.Drawing.Size(325, 22);
            this.stockDetailReportToolStripMenuItem.Text = "Stock Detail Report";
            this.stockDetailReportToolStripMenuItem.Click += new System.EventHandler(this.stockDetailReportToolStripMenuItem_Click);
            // 
            // singleCustomerDetailReportToolStripMenuItem
            // 
            this.singleCustomerDetailReportToolStripMenuItem.Name = "singleCustomerDetailReportToolStripMenuItem";
            this.singleCustomerDetailReportToolStripMenuItem.Size = new System.Drawing.Size(325, 22);
            this.singleCustomerDetailReportToolStripMenuItem.Text = "Single Customer Detail Report";
            this.singleCustomerDetailReportToolStripMenuItem.Click += new System.EventHandler(this.singleCustomerDetailReportToolStripMenuItem_Click);
            // 
            // userManagementToolStripMenuItem
            // 
            this.userManagementToolStripMenuItem.Name = "userManagementToolStripMenuItem";
            this.userManagementToolStripMenuItem.Size = new System.Drawing.Size(168, 22);
            this.userManagementToolStripMenuItem.Text = "User Management";
            this.userManagementToolStripMenuItem.Visible = false;
            this.userManagementToolStripMenuItem.Click += new System.EventHandler(this.userManagementToolStripMenuItem_Click);
            // 
            // statusStrip
            // 
            this.statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel});
            this.statusStrip.Location = new System.Drawing.Point(0, 454);
            this.statusStrip.Name = "statusStrip";
            this.statusStrip.Padding = new System.Windows.Forms.Padding(1, 0, 16, 0);
            this.statusStrip.Size = new System.Drawing.Size(1176, 22);
            this.statusStrip.TabIndex = 2;
            this.statusStrip.Text = "StatusStrip";
            // 
            // toolStripStatusLabel
            // 
            this.toolStripStatusLabel.Name = "toolStripStatusLabel";
            this.toolStripStatusLabel.Size = new System.Drawing.Size(39, 17);
            this.toolStripStatusLabel.Text = "Status";
            // 
            // Logout_Btn
            // 
            this.Logout_Btn.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Logout_Btn.Location = new System.Drawing.Point(1050, 2);
            this.Logout_Btn.Name = "Logout_Btn";
            this.Logout_Btn.Size = new System.Drawing.Size(87, 24);
            this.Logout_Btn.TabIndex = 4;
            this.Logout_Btn.Text = "Logout";
            this.Logout_Btn.UseVisualStyleBackColor = true;
            this.Logout_Btn.Click += new System.EventHandler(this.Logout_Btn_Click);
            // 
            // Frm_MdiParent_Electronic_Shop_Management
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1176, 476);
            this.Controls.Add(this.Logout_Btn);
            this.Controls.Add(this.statusStrip);
            this.Controls.Add(this.menuStrip);
            this.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip;
            this.Name = "Frm_MdiParent_Electronic_Shop_Management";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Frm_MdiParent_Electronic_Shop_Management";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Frm_MdiParent_Electronic_Shop_Management_Load);
            this.menuStrip.ResumeLayout(false);
            this.menuStrip.PerformLayout();
            this.statusStrip.ResumeLayout(false);
            this.statusStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion


        private System.Windows.Forms.MenuStrip menuStrip;
        private System.Windows.Forms.StatusStrip statusStrip;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel;
        private System.Windows.Forms.ToolTip toolTip;
        private System.Windows.Forms.ToolStripMenuItem customerDetailToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem customerSaleDetailToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem allCustomerDetailToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem productDetailToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addProductToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem updateProductToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewAllProductToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dealerDetailToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addDealerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem updateDealerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewAllDealerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem employeeDeatilToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addEmployeeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem updateEmployeeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewAllEmployeeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem stockDetailToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem updateStockToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem searchToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem stockAddedDetailsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem customerDetailToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem productDetailReportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem stockDetailReportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem singleCustomerDetailReportToolStripMenuItem;
        private System.Windows.Forms.Button Logout_Btn;
        private System.Windows.Forms.ToolStripMenuItem singleStockAvailabilityToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem userManagementToolStripMenuItem;
    }
}



