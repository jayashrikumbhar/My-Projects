﻿namespace Electronic_Shop_Management_CSharp
{
    partial class Frm_Update_Dealer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Lable1 = new System.Windows.Forms.Label();
            this.Btn_delete = new System.Windows.Forms.Button();
            this.btn_exit = new System.Windows.Forms.Button();
            this.Panel1 = new System.Windows.Forms.Panel();
            this.Label7 = new System.Windows.Forms.Label();
            this.Email_ID_TB = new System.Windows.Forms.TextBox();
            this.PAN_No_TB = new System.Windows.Forms.TextBox();
            this.Label1 = new System.Windows.Forms.Label();
            this.Btn_fetch = new System.Windows.Forms.Button();
            this.Btn_clear = new System.Windows.Forms.Button();
            this.Btn_update = new System.Windows.Forms.Button();
            this.Adhar_No_TB = new System.Windows.Forms.TextBox();
            this.Label6 = new System.Windows.Forms.Label();
            this.Address_TB = new System.Windows.Forms.TextBox();
            this.Mob_No_TB = new System.Windows.Forms.TextBox();
            this.Dealer_Name_TB = new System.Windows.Forms.TextBox();
            this.Label5 = new System.Windows.Forms.Label();
            this.Label4 = new System.Windows.Forms.Label();
            this.Label3 = new System.Windows.Forms.Label();
            this.Dealer_ID_TB = new System.Windows.Forms.TextBox();
            this.Label2 = new System.Windows.Forms.Label();
            this.Panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // Lable1
            // 
            this.Lable1.AutoSize = true;
            this.Lable1.Font = new System.Drawing.Font("Verdana", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lable1.ForeColor = System.Drawing.Color.Black;
            this.Lable1.Location = new System.Drawing.Point(287, 28);
            this.Lable1.Name = "Lable1";
            this.Lable1.Size = new System.Drawing.Size(491, 45);
            this.Lable1.TabIndex = 53;
            this.Lable1.Text = " Update Dealer Details";
            // 
            // Btn_delete
            // 
            this.Btn_delete.BackColor = System.Drawing.Color.DimGray;
            this.Btn_delete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn_delete.Enabled = false;
            this.Btn_delete.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.Btn_delete.Font = new System.Drawing.Font("Verdana", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_delete.ForeColor = System.Drawing.Color.White;
            this.Btn_delete.Location = new System.Drawing.Point(114, 533);
            this.Btn_delete.Name = "Btn_delete";
            this.Btn_delete.Size = new System.Drawing.Size(147, 42);
            this.Btn_delete.TabIndex = 103;
            this.Btn_delete.Text = "Delete";
            this.Btn_delete.UseVisualStyleBackColor = false;
            this.Btn_delete.Click += new System.EventHandler(this.Btn_delete_Click);
            // 
            // btn_exit
            // 
            this.btn_exit.BackColor = System.Drawing.Color.DimGray;
            this.btn_exit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_exit.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btn_exit.Font = new System.Drawing.Font("Verdana", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_exit.ForeColor = System.Drawing.Color.White;
            this.btn_exit.Location = new System.Drawing.Point(887, 533);
            this.btn_exit.Name = "btn_exit";
            this.btn_exit.Size = new System.Drawing.Size(147, 42);
            this.btn_exit.TabIndex = 102;
            this.btn_exit.Text = "Exit";
            this.btn_exit.UseVisualStyleBackColor = false;
            this.btn_exit.Click += new System.EventHandler(this.btn_exit_Click);
            // 
            // Panel1
            // 
            this.Panel1.BackColor = System.Drawing.Color.Transparent;
            this.Panel1.Controls.Add(this.Lable1);
            this.Panel1.Location = new System.Drawing.Point(1, 1);
            this.Panel1.Name = "Panel1";
            this.Panel1.Size = new System.Drawing.Size(1146, 100);
            this.Panel1.TabIndex = 101;
            // 
            // Label7
            // 
            this.Label7.AutoSize = true;
            this.Label7.BackColor = System.Drawing.Color.Transparent;
            this.Label7.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label7.ForeColor = System.Drawing.Color.Black;
            this.Label7.Location = new System.Drawing.Point(203, 467);
            this.Label7.Name = "Label7";
            this.Label7.Size = new System.Drawing.Size(101, 25);
            this.Label7.TabIndex = 100;
            this.Label7.Text = "Email ID";
            // 
            // Email_ID_TB
            // 
            this.Email_ID_TB.BackColor = System.Drawing.Color.White;
            this.Email_ID_TB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Email_ID_TB.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Email_ID_TB.Location = new System.Drawing.Point(490, 462);
            this.Email_ID_TB.MaxLength = 10;
            this.Email_ID_TB.Name = "Email_ID_TB";
            this.Email_ID_TB.Size = new System.Drawing.Size(320, 33);
            this.Email_ID_TB.TabIndex = 91;
            // 
            // PAN_No_TB
            // 
            this.PAN_No_TB.BackColor = System.Drawing.Color.White;
            this.PAN_No_TB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PAN_No_TB.Enabled = false;
            this.PAN_No_TB.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PAN_No_TB.Location = new System.Drawing.Point(490, 408);
            this.PAN_No_TB.MaxLength = 10;
            this.PAN_No_TB.Name = "PAN_No_TB";
            this.PAN_No_TB.Size = new System.Drawing.Size(320, 33);
            this.PAN_No_TB.TabIndex = 90;
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.BackColor = System.Drawing.Color.Transparent;
            this.Label1.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label1.ForeColor = System.Drawing.Color.Black;
            this.Label1.Location = new System.Drawing.Point(202, 416);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(198, 25);
            this.Label1.TabIndex = 99;
            this.Label1.Text = "Pan Card Number";
            // 
            // Btn_fetch
            // 
            this.Btn_fetch.BackColor = System.Drawing.Color.DimGray;
            this.Btn_fetch.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn_fetch.Enabled = false;
            this.Btn_fetch.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.Btn_fetch.Font = new System.Drawing.Font("Verdana", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_fetch.ForeColor = System.Drawing.Color.White;
            this.Btn_fetch.Location = new System.Drawing.Point(869, 127);
            this.Btn_fetch.Name = "Btn_fetch";
            this.Btn_fetch.Size = new System.Drawing.Size(124, 42);
            this.Btn_fetch.TabIndex = 85;
            this.Btn_fetch.Text = "Fetch";
            this.Btn_fetch.UseVisualStyleBackColor = false;
            this.Btn_fetch.Click += new System.EventHandler(this.Btn_fetch_Click);
            // 
            // Btn_clear
            // 
            this.Btn_clear.BackColor = System.Drawing.Color.DimGray;
            this.Btn_clear.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn_clear.Enabled = false;
            this.Btn_clear.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.Btn_clear.Font = new System.Drawing.Font("Verdana", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_clear.ForeColor = System.Drawing.Color.White;
            this.Btn_clear.Location = new System.Drawing.Point(610, 533);
            this.Btn_clear.Name = "Btn_clear";
            this.Btn_clear.Size = new System.Drawing.Size(147, 42);
            this.Btn_clear.TabIndex = 93;
            this.Btn_clear.Text = "Clear";
            this.Btn_clear.UseVisualStyleBackColor = false;
            this.Btn_clear.Click += new System.EventHandler(this.Btn_clear_Click);
            // 
            // Btn_update
            // 
            this.Btn_update.BackColor = System.Drawing.Color.DimGray;
            this.Btn_update.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn_update.Enabled = false;
            this.Btn_update.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.Btn_update.Font = new System.Drawing.Font("Verdana", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_update.ForeColor = System.Drawing.Color.White;
            this.Btn_update.Location = new System.Drawing.Point(353, 533);
            this.Btn_update.Name = "Btn_update";
            this.Btn_update.Size = new System.Drawing.Size(147, 42);
            this.Btn_update.TabIndex = 92;
            this.Btn_update.Text = "Update";
            this.Btn_update.UseVisualStyleBackColor = false;
            this.Btn_update.Click += new System.EventHandler(this.Btn_update_Click);
            // 
            // Adhar_No_TB
            // 
            this.Adhar_No_TB.BackColor = System.Drawing.Color.White;
            this.Adhar_No_TB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Adhar_No_TB.Enabled = false;
            this.Adhar_No_TB.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Adhar_No_TB.Location = new System.Drawing.Point(490, 351);
            this.Adhar_No_TB.MaxLength = 12;
            this.Adhar_No_TB.Name = "Adhar_No_TB";
            this.Adhar_No_TB.Size = new System.Drawing.Size(320, 33);
            this.Adhar_No_TB.TabIndex = 89;
            // 
            // Label6
            // 
            this.Label6.AutoSize = true;
            this.Label6.BackColor = System.Drawing.Color.Transparent;
            this.Label6.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label6.ForeColor = System.Drawing.Color.Black;
            this.Label6.Location = new System.Drawing.Point(203, 359);
            this.Label6.Name = "Label6";
            this.Label6.Size = new System.Drawing.Size(165, 25);
            this.Label6.TabIndex = 98;
            this.Label6.Text = "Adhar Number";
            // 
            // Address_TB
            // 
            this.Address_TB.BackColor = System.Drawing.Color.White;
            this.Address_TB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Address_TB.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Address_TB.Location = new System.Drawing.Point(490, 242);
            this.Address_TB.Name = "Address_TB";
            this.Address_TB.Size = new System.Drawing.Size(320, 33);
            this.Address_TB.TabIndex = 87;
            // 
            // Mob_No_TB
            // 
            this.Mob_No_TB.BackColor = System.Drawing.Color.White;
            this.Mob_No_TB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Mob_No_TB.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Mob_No_TB.Location = new System.Drawing.Point(490, 295);
            this.Mob_No_TB.MaxLength = 10;
            this.Mob_No_TB.Name = "Mob_No_TB";
            this.Mob_No_TB.Size = new System.Drawing.Size(320, 33);
            this.Mob_No_TB.TabIndex = 88;
            // 
            // Dealer_Name_TB
            // 
            this.Dealer_Name_TB.BackColor = System.Drawing.Color.White;
            this.Dealer_Name_TB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Dealer_Name_TB.Enabled = false;
            this.Dealer_Name_TB.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Dealer_Name_TB.Location = new System.Drawing.Point(490, 192);
            this.Dealer_Name_TB.Name = "Dealer_Name_TB";
            this.Dealer_Name_TB.Size = new System.Drawing.Size(320, 33);
            this.Dealer_Name_TB.TabIndex = 86;
            // 
            // Label5
            // 
            this.Label5.AutoSize = true;
            this.Label5.BackColor = System.Drawing.Color.Transparent;
            this.Label5.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label5.ForeColor = System.Drawing.Color.Black;
            this.Label5.Location = new System.Drawing.Point(202, 200);
            this.Label5.Name = "Label5";
            this.Label5.Size = new System.Drawing.Size(151, 25);
            this.Label5.TabIndex = 97;
            this.Label5.Text = "Dealer Name";
            // 
            // Label4
            // 
            this.Label4.AutoSize = true;
            this.Label4.BackColor = System.Drawing.Color.Transparent;
            this.Label4.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label4.ForeColor = System.Drawing.Color.Black;
            this.Label4.Location = new System.Drawing.Point(202, 250);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(96, 25);
            this.Label4.TabIndex = 96;
            this.Label4.Text = "Address";
            // 
            // Label3
            // 
            this.Label3.AutoSize = true;
            this.Label3.BackColor = System.Drawing.Color.Transparent;
            this.Label3.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label3.ForeColor = System.Drawing.Color.Black;
            this.Label3.Location = new System.Drawing.Point(202, 303);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(172, 25);
            this.Label3.TabIndex = 95;
            this.Label3.Text = "Mobile Number";
            // 
            // Dealer_ID_TB
            // 
            this.Dealer_ID_TB.BackColor = System.Drawing.Color.White;
            this.Dealer_ID_TB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Dealer_ID_TB.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Dealer_ID_TB.Location = new System.Drawing.Point(490, 136);
            this.Dealer_ID_TB.Name = "Dealer_ID_TB";
            this.Dealer_ID_TB.Size = new System.Drawing.Size(320, 33);
            this.Dealer_ID_TB.TabIndex = 84;
            this.Dealer_ID_TB.TextChanged += new System.EventHandler(this.Dealer_ID_TB_TextChanged);
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.BackColor = System.Drawing.Color.Transparent;
            this.Label2.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label2.ForeColor = System.Drawing.Color.Black;
            this.Label2.Location = new System.Drawing.Point(202, 138);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(113, 25);
            this.Label2.TabIndex = 94;
            this.Label2.Text = "Dealer ID";
            // 
            // Frm_Update_Dealer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1148, 600);
            this.Controls.Add(this.Btn_delete);
            this.Controls.Add(this.btn_exit);
            this.Controls.Add(this.Panel1);
            this.Controls.Add(this.Label7);
            this.Controls.Add(this.Email_ID_TB);
            this.Controls.Add(this.PAN_No_TB);
            this.Controls.Add(this.Label1);
            this.Controls.Add(this.Btn_fetch);
            this.Controls.Add(this.Btn_clear);
            this.Controls.Add(this.Btn_update);
            this.Controls.Add(this.Adhar_No_TB);
            this.Controls.Add(this.Label6);
            this.Controls.Add(this.Address_TB);
            this.Controls.Add(this.Mob_No_TB);
            this.Controls.Add(this.Dealer_Name_TB);
            this.Controls.Add(this.Label5);
            this.Controls.Add(this.Label4);
            this.Controls.Add(this.Label3);
            this.Controls.Add(this.Dealer_ID_TB);
            this.Controls.Add(this.Label2);
            this.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "Frm_Update_Dealer";
            this.Text = "Frm_Update_Dealer";
            this.Leave += new System.EventHandler(this.Frm_Update_Dealer_Leave);
            this.Panel1.ResumeLayout(false);
            this.Panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.Label Lable1;
        internal System.Windows.Forms.Button Btn_delete;
        internal System.Windows.Forms.Button btn_exit;
        internal System.Windows.Forms.Panel Panel1;
        internal System.Windows.Forms.Label Label7;
        internal System.Windows.Forms.TextBox Email_ID_TB;
        internal System.Windows.Forms.TextBox PAN_No_TB;
        internal System.Windows.Forms.Label Label1;
        internal System.Windows.Forms.Button Btn_fetch;
        internal System.Windows.Forms.Button Btn_clear;
        internal System.Windows.Forms.Button Btn_update;
        internal System.Windows.Forms.TextBox Adhar_No_TB;
        internal System.Windows.Forms.Label Label6;
        internal System.Windows.Forms.TextBox Address_TB;
        internal System.Windows.Forms.TextBox Mob_No_TB;
        internal System.Windows.Forms.TextBox Dealer_Name_TB;
        internal System.Windows.Forms.Label Label5;
        internal System.Windows.Forms.Label Label4;
        internal System.Windows.Forms.Label Label3;
        internal System.Windows.Forms.TextBox Dealer_ID_TB;
        internal System.Windows.Forms.Label Label2;
    }
}