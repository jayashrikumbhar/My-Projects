﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Electronic_Shop_Management_CSharp
{
    public partial class Frm_Update_Product_Detail : Form
    {
        SqlConnection Con = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=Electronic_Shop_Management_DB;Integrated Security=True");
        SqlCommand Cmd = new SqlCommand();
        SqlCommand Cmd1 = new SqlCommand();
        SqlDataReader dr;
        string str,str1;

        public void Connection_Open()
        {
            if (Con.State == ConnectionState.Closed)
            {
                Con.Open();
            }
        }

        public void Connection_Close()
        {
            if (Con.State == ConnectionState.Open)
            {
                Con.Close();
            }
        }

        public void Clear_Controls()
        {
            Product_ID_TB.Text = "";
            Product_Name_TB.Text = "";
            Brand_TB.Text = "";
            Dealer_Name_TB.Text = "";
            Description_TB.Text = "";
            SGST_TB.Text = "";
            CGST_TB.Text = "";
            Dealer_Rate_TB.Text = "";
            Sale_Rate_TB.Text = "";
        }
        public Frm_Update_Product_Detail()
        {
            InitializeComponent();
        }

        private void Btn_fetch_Click(object sender, EventArgs e)
        {
            Connection_Open();
            if (Product_ID_TB.Text != null)
            {
                Cmd1.CommandText = "SELECT * FROM Product_Detail_Table WHERE Product_Id=" + Product_ID_TB.Text + "";
                Cmd1.Connection = Con;
                dr = Cmd1.ExecuteReader();
                if (dr.Read())
                {
                    Product_Name_TB.Text = dr["Product_Name"].ToString();
                    Brand_TB.Text = dr["Product_Brand"].ToString();
                    Description_TB.Text = dr["Description"].ToString();
                    Dealer_Name_TB.Text = dr["Dealer_Name"].ToString();
                    SGST_TB.Text = dr["SGST"].ToString();
                    CGST_TB.Text = dr["CGST"].ToString();
                    Dealer_Rate_TB.Text = dr["Dealer_Rate"].ToString();
                    Sale_Rate_TB.Text = dr["Sale_Rate"].ToString();
                }
                else
                {
                    MessageBox.Show("There is error while retriving informarion!!");
                }
            }
            else
            {
                MessageBox.Show("Please first enter Product ID!");
            }
            Connection_Close();
            Btn_delete.Enabled = true;
            Btn_update.Enabled = true;
        }

        private void Product_ID_TB_TextChanged(object sender, EventArgs e)
        {
            Btn_fetch.Enabled = true;
        }

   
        private void Btn_update_Click(object sender, EventArgs e)
        {
            Connection_Open();

            if (Product_ID_TB.Text != "" && Dealer_Name_TB.Text != "" && Product_Name_TB.Text != "" && Brand_TB.Text != "" && Description_TB.Text != "" && SGST_TB.Text != "" && CGST_TB.Text != "" && Dealer_Rate_TB.Text != "" && Sale_Rate_TB.Text != "")
            {
                if (SGST_TB.Modified == true || CGST_TB.Modified == true || Dealer_Rate_TB.Modified == true || Sale_Rate_TB.Modified == true)
                {
                    Cmd1.CommandText = "UPDATE Product_Detail_Table SET SGST=" + SGST_TB.Text + "CGST=" + CGST_TB.Text + ",Dealer_Rate=" + Dealer_Rate_TB.Text + ",Sale_Rate=" + Sale_Rate_TB.Text + " WHERE Product_Id=" + Product_ID_TB.Text + "";
                    Cmd1.Connection = Con;
                    str = Convert.ToString(Cmd1.ExecuteNonQuery());
                    if (str != null)
                    {
                        MessageBox.Show("Record updated successfully!!");
                        Clear_Controls();
                        Btn_fetch.Enabled = false;
                        Btn_delete.Enabled = false;
                        Btn_update.Enabled = false;
                    }
                    else
                    {
                        MessageBox.Show("There is error while updating record!!");
                    }
                }
                else
                {
                    MessageBox.Show("Please update at least one field!!");
                }
            }
            else
            {
                MessageBox.Show("First fill all the fields!!");
            }
            Connection_Close();
            
        }

        private void Btn_clear_Click(object sender, EventArgs e)
        {
            Clear_Controls();
            Btn_delete.Enabled = false;
            Btn_fetch.Enabled = false;
            Btn_update.Enabled = false;
        }

        private void Btn_exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Frm_Update_Product_Detail_Leave(object sender, EventArgs e)
        {
            Clear_Controls();
        }

        private void Btn_delete_Click(object sender, EventArgs e)
        {
            Connection_Open();
            if (Product_ID_TB.Text != "" && Dealer_Name_TB.Text != "" && Product_Name_TB.Text != "" && Brand_TB.Text != "" && Description_TB.Text != "" && SGST_TB.Text != "" && Dealer_Rate_TB.Text != "" && Sale_Rate_TB.Text != "")
            {

                Cmd.CommandText = "DELETE FROM Stock_Detail_Table WHERE Product_ID=" + Product_ID_TB.Text + "";
                Cmd.Connection = Con;

                Cmd1.CommandText = "DELETE FROM Product_Detail_Table WHERE Product_Id=" + Product_ID_TB.Text + "";
                Cmd1.Connection = Con;

                str = Convert.ToString(Cmd.ExecuteNonQuery());
                str1 = Convert.ToString(Cmd1.ExecuteNonQuery());
                if (str != null && str1 != null)
                {
                    MessageBox.Show("Record Deleted Successfully!!");
                    Clear_Controls();
                }
                else
                {
                    MessageBox.Show("There is error while deleting record!!");
                }
                
            }
            else
            {
                MessageBox.Show("First fill all the fields!!");
            }
            Connection_Close();
            Btn_fetch.Enabled = false;
            Btn_delete.Enabled = false;
            Btn_update.Enabled = false;
        }
    }
}
