import java.awt.*;
import javax.swing.*;

public class Unpacker_Portal 
{
	private JFrame frame;
	private JTextField File_Name_TF;

	public Unpacker_Portal() 
	{
		frame = new JFrame();
		frame.setBounds(100, 100, 500, 500);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(0, 0, 139));
		frame.getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		Panel panel_1 = new Panel();
		panel_1.setBackground(Color.WHITE);
		panel_1.setBounds(0, 0, 484, 106);
		panel.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Unpacking Portal");
		lblNewLabel.setBounds(20, 55, 123, 22);
		panel_1.add(lblNewLabel);
		
		JLabel Date_Lbl = new JLabel("");
		Date_Lbl.setBounds(345, 0, 129, 27);
		panel_1.add(Date_Lbl);
		
		JLabel Time_Lbl = new JLabel("");
		Time_Lbl.setBounds(345, 38, 129, 27);
		panel_1.add(Time_Lbl);
		
		JLabel Day_Lbl = new JLabel("");
		Day_Lbl.setBounds(345, 68, 129, 27);
		panel_1.add(Day_Lbl);
		
		JLabel lblFileName = new JLabel("File Name");
		lblFileName.setForeground(Color.WHITE);
		lblFileName.setBounds(57, 204, 133, 35);
		panel.add(lblFileName);
		
		File_Name_TF = new JTextField();
		File_Name_TF.setColumns(10);
		File_Name_TF.setBounds(220, 210, 201, 26);
		panel.add(File_Name_TF);
		
		JButton btnExtractHere = new JButton("Extract Here");
		btnExtractHere.setBackground(Color.WHITE);
		btnExtractHere.setBounds(76, 342, 145, 38);
		panel.add(btnExtractHere);
		
		JButton Btn_Prev = new JButton("Previous");
		Btn_Prev.setBackground(Color.WHITE);
		Btn_Prev.setBounds(279, 342, 115, 38);
		panel.add(Btn_Prev);
	}
	
	public static void main(String[] args) 
	{
		try 
		{
			Unpacker_Portal window = new Unpacker_Portal();
			window.frame.setVisible(true);
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
	

}
