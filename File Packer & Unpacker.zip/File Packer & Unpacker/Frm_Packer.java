import java.awt.*;
import javax.swing.*;

public class Frm_Packer 
{
	private JFrame frame;
	
	public Frm_Packer() 
	{
		frame = new JFrame();
		frame.setBounds(100, 100, 500, 500);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(0, 0, 139));
		frame.getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		Panel panel_1 = new Panel();
		panel_1.setBackground(Color.WHITE);
		panel_1.setBounds(0, 0, 484, 106);
		panel.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Welcome : ");
		lblNewLabel.setBounds(10, 36, 75, 27);
		panel_1.add(lblNewLabel);
		
		JLabel UserNmLbl = new JLabel("");
		UserNmLbl.setBounds(82, 36, 129, 27);
		panel_1.add(UserNmLbl);
		
		JLabel Date_Lbl = new JLabel("");
		Date_Lbl.setBounds(345, 11, 129, 27);
		panel_1.add(Date_Lbl);
		
		JLabel Time_Lbl = new JLabel("");
		Time_Lbl.setBounds(345, 36, 129, 27);
		panel_1.add(Time_Lbl);
		
		JLabel Day_Lbl = new JLabel("");
		Day_Lbl.setBounds(345, 74, 129, 27);
		panel_1.add(Day_Lbl);
		
		JButton Pack_Btn = new JButton("Pack");
		Pack_Btn.setBackground(Color.WHITE);
		Pack_Btn.setBounds(63, 263, 106, 37);
		panel.add(Pack_Btn);
		
		JButton btnUnpack = new JButton("Unpack");
		btnUnpack.setBackground(Color.WHITE);
		btnUnpack.setBounds(280, 263, 106, 37);
		panel.add(btnUnpack);
	}
	
	public static void main(String[] args) 
	{
		try
		{
			Frm_Packer window = new Frm_Packer();
			window.frame.setVisible(true);
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}

}
