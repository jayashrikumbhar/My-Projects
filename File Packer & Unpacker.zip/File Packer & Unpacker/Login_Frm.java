import java.awt.*;
import javax.swing.*;

public class Login_Frm 
{
	private JFrame frame;
	
	public Login_Frm() 
	{	
		frame = new JFrame();
		frame.setBounds(100, 100, 500, 500);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(0, 0, 139));
		frame.getContentPane().add(panel_1, BorderLayout.CENTER);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Username");
		lblNewLabel.setBounds(61, 206, 97, 37);
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setForeground(Color.WHITE);
		panel_1.add(lblNewLabel);
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setHorizontalAlignment(SwingConstants.CENTER);
		lblPassword.setForeground(Color.WHITE);
		lblPassword.setBounds(61, 265, 97, 37);
		panel_1.add(lblPassword);
		
		JTextArea textArea = new JTextArea();
		textArea.setBounds(230, 214, 179, 22);
		panel_1.add(textArea);
		
		JTextArea textArea_1 = new JTextArea();
		textArea_1.setToolTipText("Insert Password");
		textArea_1.setBounds(230, 273, 179, 22);
		//textArea_1.setEchoChar('*');
		panel_1.add(textArea_1);
		
		JButton btnNewButton = new JButton("Submit");
		btnNewButton.setBackground(Color.WHITE);
		btnNewButton.setBounds(166, 360, 120, 37);
		panel_1.add(btnNewButton);
		
		Panel panel = new Panel();
		panel.setBackground(Color.WHITE);
		panel.setBounds(0, 0, 484, 106);
		panel_1.add(panel);
		panel.setLayout(null);
		
		JLabel lblWelcome = new JLabel("Marvellous Packer Unpacker : Login");
		lblWelcome.setBounds(10, 39, 276, 20);
		lblWelcome.setHorizontalAlignment(SwingConstants.CENTER);
		lblWelcome.setForeground(Color.BLACK);
		lblWelcome.setFont(new Font("Tahoma", Font.PLAIN, 16));
		panel.add(lblWelcome);
		
	}
	
	public static void main(String[] args) 
	{
		try 
		{
			Login_Frm window = new Login_Frm();
			window.frame.setVisible(true);
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
}