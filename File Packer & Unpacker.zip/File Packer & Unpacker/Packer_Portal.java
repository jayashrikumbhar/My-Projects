import java.awt.*;
import javax.swing.*;

public class Packer_Portal 
{
	private JFrame frame;
	private JTextField Dir_Name_TF;
	private JTextField textField;
	
	public Packer_Portal() 
	{
		frame = new JFrame();
		frame.setBounds(100, 100, 500, 500);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(0, 0, 139));
		frame.getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		Panel panel_1 = new Panel();
		panel_1.setBackground(Color.WHITE);
		panel_1.setBounds(0, 0, 484, 106);
		panel.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Packing Poratal");
		lblNewLabel.setBounds(10, 56, 113, 19);
		panel_1.add(lblNewLabel);
		
		JLabel Date_Lbl = new JLabel("");
		Date_Lbl.setBounds(345, 0, 129, 27);
		panel_1.add(Date_Lbl);
		
		JLabel Time_Lbl = new JLabel("");
		Time_Lbl.setBounds(345, 38, 129, 27);
		panel_1.add(Time_Lbl);
		
		JLabel Day_Lbl = new JLabel("");
		Day_Lbl.setBounds(345, 76, 129, 27);
		panel_1.add(Day_Lbl);
		
		JLabel lblDirectoryName = new JLabel("Directory Name");
		lblDirectoryName.setForeground(Color.WHITE);
		lblDirectoryName.setBounds(83, 196, 133, 35);
		panel.add(lblDirectoryName);
		
		Dir_Name_TF = new JTextField();
		Dir_Name_TF.setBounds(246, 202, 201, 26);
		panel.add(Dir_Name_TF);
		Dir_Name_TF.setColumns(10);
		
		JLabel lblDestinamtionFileName = new JLabel("Destinamtion File Name");
		lblDestinamtionFileName.setForeground(Color.WHITE);
		lblDestinamtionFileName.setBounds(26, 256, 190, 35);
		panel.add(lblDestinamtionFileName);
		
		textField = new JTextField();
		textField.setColumns(10);
		textField.setBounds(246, 262, 201, 26);
		panel.add(textField);
		
		JButton Submit_Btn = new JButton("Submit");
		Submit_Btn.setBackground(Color.WHITE);
		Submit_Btn.setBounds(87, 377, 115, 38);
		panel.add(Submit_Btn);
		
		JButton Prev_Btn = new JButton("Previous");
		Prev_Btn.setBackground(Color.WHITE);
		Prev_Btn.setBounds(290, 377, 115, 38);
		panel.add(Prev_Btn);
	}

	public static void main(String[] args) 
	{
		try 
		{
			Packer_Portal window = new Packer_Portal();
			window.frame.setVisible(true);
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}				
	}
}
